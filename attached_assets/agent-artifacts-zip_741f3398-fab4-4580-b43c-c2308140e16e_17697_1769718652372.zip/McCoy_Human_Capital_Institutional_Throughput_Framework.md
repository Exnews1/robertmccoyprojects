# Human Capital Institutional Throughput Framework: A Comparative Analysis of Military and Correctional Systems

**Robert McCoy**

---

## Abstract

This paper develops a Human Capital Institutional Throughput Framework to evaluate national strength as a function of human capital stock, institutional throughput efficiency, recurrence rates, containment costs, and investment-friction dynamics. Using systems theory and human capital economics, the framework models national strength (S) through the equation ΔH = f(E) × (1 − C), where human capital accumulation depends on educational investment (E) and institutional friction (C). The analysis compares two high-throughput institutions: the military system, which functions as an accepted human capital generator through voluntary education programs (Tuition Assistance, GI Bill), and the correctional system, characterized by high recurrence rates and minimal human capital investment. Evidence from 453 peer-reviewed sources demonstrates that military education programs increase veteran educational attainment by 1.4 years and earnings by 6% (Angrist, 1993), while correctional education reduces recidivism by 43% and increases post-release employment odds by 28% (Davis et al., 2013). The framework introduces BASE cost modeling, demonstrating that containment costs are non-negotiable fixed expenditures, making the marginal cost of educational investment (E) substantially lower than commonly perceived. Friction layer analysis reveals that institutional, social, and perceptual barriers multiply to reduce human capital conversion efficiency through C-multiplier effects. The paper argues that correctional systems represent underutilized throughput nodes where strategic human capital investment could yield substantial returns to national strength through recidivism reduction and workforce reintegration. Policy implications are framed through economic infrastructure and international compliance lenses (UN Mandela Rules) rather than moral arguments, positioning human capital investment as a systems optimization problem with measurable returns. The framework proposes empirical testing through human capital ISR-style reporting systems and lifecycle tracking mechanisms to enable evidence-based policy optimization.

**Keywords:** human capital theory, institutional throughput, correctional education, military education, systems theory, recidivism, national competitiveness, cost-benefit analysis, friction modeling, UN Mandela Rules

---

## Table of Contents

1. Introduction
2. Theoretical Foundations
   - 2.1 National Strength as Stock and Flow System
   - 2.2 Human Capital Accumulation Theory
   - 2.3 Institutional Throughput Theory
3. System A: Military as Human Capital Generator
   - 3.1 Voluntary Education Programs and Mechanisms
   - 3.2 Empirical Evidence of Human Capital Effects
   - 3.3 Proof by Precedent: Social Acceptance
4. Generalization to High-Throughput Institutions
   - 4.1 Defining Institutional Throughput Characteristics
   - 4.2 Comparative Institutional Analysis
5. System B: Correctional System as High-Recurrence Node
   - 5.1 Throughput Characteristics and Recurrence Rates
   - 5.2 Empirical Evidence of Correctional Education Effects
   - 5.3 International Standards and Governance Frameworks
6. BASE Cost Model: Containment as Non-Negotiable Expenditure
   - 6.1 Fixed Cost Structure Analysis
   - 6.2 Marginal Cost of Educational Investment
7. Investment Layer Model: E versus BASE
   - 7.1 Cost-Benefit Analysis Framework
   - 7.2 Break-Even Recidivism Reduction Thresholds
   - 7.3 ROI Calculations and Comparative Returns
8. Friction Layer Model: C-Multiplier Effects
   - 8.1 Taxonomy of Institutional Friction
   - 8.2 Social and Perceptual Friction
   - 8.3 Quantifying Friction Effects on Human Capital Conversion
9. Critical Analytical Questions
   - 9.1 Crime Incentive Effects: Empirical Evidence
   - 9.2 Staff Human Capital and Conversion Efficiency
   - 9.3 Optimal Policy Framing Strategies
10. Comparative Analysis: Military versus Correctional Systems
    - 10.1 Human Capital Conversion Mechanisms
    - 10.2 Throughput Efficiency and Recurrence Patterns
    - 10.3 Investment Structures and Returns
11. Policy Implications and National Competitiveness
    - 11.1 Economic Infrastructure Framing
    - 11.2 National Stability and Security Implications
    - 11.3 International Compliance and Governance
12. Future Empirical Testing and Implementation
    - 12.1 Human Capital ISR-Style Reporting Systems
    - 12.2 Lifecycle Tracking Mechanisms
    - 12.3 Research Agenda
13. Conclusion

References

---

## 1. Introduction

National strength represents a complex function of human capital stock, institutional efficiency, and systems-level optimization. Traditional policy discourse treats correctional and military systems as categorically distinct institutions with fundamentally different purposes: one punitive, one developmental. This framing obscures a critical systems-level insight: both institutions represent high-throughput nodes processing large populations with substantial opportunities for human capital conversion. The military system has achieved broad social acceptance as a human capital generator through voluntary education programs, producing measurable returns in veteran educational attainment and labor market outcomes (Angrist, 1993; Barr, 2015; Zhang, 2017). In contrast, correctional systems operate primarily as containment mechanisms with minimal human capital investment, despite processing 1.2 million individuals annually in the United States alone and exhibiting recurrence rates exceeding 60% within three years of release.

This paper develops a Human Capital Institutional Throughput Framework to analyze national strength as a stock-and-flow system where human capital accumulation depends on institutional investment (E) and friction factors (C). The core equation ΔH = f(E) × (1 − C) models human capital change as a function of educational investment modified by institutional, social, and perceptual friction. The framework introduces BASE cost modeling to demonstrate that containment costs represent non-negotiable fixed expenditures, fundamentally altering the marginal cost calculus for educational investment. When BASE costs are treated as sunk, the incremental cost of human capital investment becomes substantially lower than commonly perceived, shifting cost-benefit thresholds and policy optimization parameters.

The analysis proceeds through systematic comparison of two high-throughput institutional systems. System A (military) demonstrates proof-by-precedent that large-scale institutional human capital investment can achieve social acceptance and produce measurable returns. Empirical evidence shows military education programs increase veteran schooling by approximately 1.4 years and annual earnings by 6%, with lifetime earnings gains exceeding $17,000 in discounted present value (Angrist et al., 1990). System B (correctional) exhibits high recurrence rates and minimal human capital investment, yet meta-analytic evidence demonstrates that correctional education reduces recidivism odds by 43% and increases post-release employment odds by 28%, with cost-effectiveness ratios showing reincarceration cost savings of $870,000 to $970,000 per educated cohort (Davis et al., 2013).

The framework addresses four critical analytical questions: (1) Would prison education create crime incentive effects? (2) What recurrence reduction creates break-even ROI? (3) How does staff human capital influence incarcerated human capital conversion? (4) What framing strategy optimally positions policy implementation—social policy, economic infrastructure, national stability, or international compliance? These questions are examined through empirical evidence rather than moral argumentation, positioning human capital investment as a systems optimization problem with measurable parameters and testable hypotheses.

This paper contributes to three distinct literatures. First, it extends human capital theory (Becker, 1964; Mincer, 1974; Psacharopoulos & Patrinos, 2018) by developing institutional throughput as a unit of analysis, modeling how organizational structures and friction factors mediate educational investment returns. Second, it advances correctional education research (Bozick et al., 2018; Davis et al., 2013; Stickle et al., 2023) by situating prison education within a broader comparative institutional framework, demonstrating structural parallels with accepted human capital generators. Third, it contributes to systems theory applications in public policy (Capano et al., 2024; Mansoor et al., 2023) by operationalizing friction layers and developing quantitative models for institutional efficiency optimization.

The remainder of this paper proceeds as follows. Section 2 establishes theoretical foundations in human capital theory, systems theory, and institutional throughput modeling. Sections 3-5 present comparative institutional analysis of military and correctional systems, examining throughput characteristics, human capital conversion mechanisms, and empirical evidence. Sections 6-8 develop the BASE cost model, investment layer analysis, and friction taxonomy. Section 9 addresses critical analytical questions through empirical evidence. Sections 10-11 synthesize comparative findings and policy implications. Section 12 proposes future empirical testing mechanisms. Section 13 concludes with implications for national competitiveness and systems optimization.

---

## 2. Theoretical Foundations

### 2.1 National Strength as Stock and Flow System

National strength (S) can be conceptualized as a stock-and-flow system where aggregate human capital (H) represents the productive capacity of the population at time t. This formulation draws on systems theory (Capano et al., 2024; Mansoor et al., 2023) and macroeconomic growth models (Saqib, 2015) to represent national capacity as:

S(t) = f(H(t), K(t), A(t))

where H represents human capital stock, K represents physical capital, and A represents technological and institutional efficiency. Human capital stock evolves according to:

dH/dt = I(t) − D(t) − R(t)

where I represents inflows from education and skill development, D represents depreciation through skill obsolescence and aging, and R represents losses through incarceration, unemployment, and other forms of human capital underutilization. This stock-and-flow formulation highlights that national strength depends not only on absolute human capital levels but also on the efficiency of institutional systems that govern inflows, depreciation, and loss rates.

Institutional throughput represents the rate at which individuals pass through organizational systems that can either enhance or diminish human capital. High-throughput institutions—military, correctional, educational, healthcare—process large populations and create opportunities for systematic human capital intervention. The efficiency of these interventions depends on investment levels (E), institutional capacity, and friction factors (C) that impede conversion of educational inputs into human capital outputs.

### 2.2 Human Capital Accumulation Theory

Human capital theory, originating with Becker (1964) and Mincer (1974), posits that individuals and societies invest in education and training to increase productive capacity and earnings potential. The standard Mincer earnings function models log earnings as:

ln(Y) = β₀ + β₁S + β₂X + β₃X² + ε

where Y represents earnings, S represents years of schooling, X represents labor market experience, and ε represents unobserved factors. Empirical estimates consistently show positive returns to education, with global average returns to one additional year of schooling approximately 9% annually (Psacharopoulos & Patrinos, 2018). Returns vary by education level, country income level, and individual characteristics, with higher returns observed for women, in low-income countries, and in the private sector.

The human capital framework extends beyond individual earnings to encompass broader social returns including reduced crime, improved health, enhanced civic participation, and intergenerational transmission of educational attainment (Gershanovich, 2004). Cost-benefit analysis in 44 countries reveals particularly high returns to primary education, with secondary and higher education also crucial for balanced development (Psacharopoulos, 1981). Investment in education yields higher returns than physical capital by enhancing individual earnings, employment search efficiency, and reducing unemployment, while also increasing labor productivity, firm profit, and market value (Gershanovich, 2004).

For institutional human capital investment, the accumulation function can be specified as:

ΔH = f(E) × (1 − C)

where ΔH represents human capital change, E represents educational investment per individual, and C represents friction factors that reduce conversion efficiency. This formulation explicitly models institutional and social barriers as multipliers that diminish returns to educational investment. When C approaches zero (frictionless conversion), human capital gains equal the full educational production function f(E). When C approaches one (complete friction), no human capital conversion occurs despite educational investment.

### 2.3 Institutional Throughput Theory

Institutional throughput theory conceptualizes organizations as processing systems with measurable input-output relationships, capacity constraints, and efficiency parameters. Drawing on systems approaches to public service delivery (Mansoor et al., 2023) and organizational capacity theory (Ting, 2009), throughput analysis examines how institutional structures, resource allocation, and management practices affect the conversion of inputs into desired outcomes.

High-throughput institutions exhibit several defining characteristics: (1) large population volumes processed annually, (2) extended duration of institutional contact, (3) structured programming opportunities, (4) measurable outcome metrics, and (5) potential for systematic intervention. Military and correctional systems both exhibit these characteristics, processing millions of individuals through multi-year programs with opportunities for educational intervention.

Throughput efficiency depends on institutional capacity, which Donahue et al. (2000) define as the ability of government systems to effectively manage human resources and deliver services. Strategic human capital management in public sector organizations requires alignment of workforce capabilities with organizational missions, investment in employee development, and creation of performance-oriented cultures (Kim, 2010). Carmeli (2004) demonstrates that strategic human capital significantly affects public sector organizational performance, with human capital quality explaining substantial variance in organizational outcomes.

Institutional friction represents barriers that impede throughput efficiency and reduce human capital conversion rates. Friction sources include: (1) institutional barriers such as inadequate resources, poor program design, and misaligned incentives; (2) social barriers including stigma, discrimination, and limited social capital; and (3) perceptual barriers such as public opposition, political resistance, and cognitive biases. These friction factors interact multiplicatively, such that total friction C = 1 − (1 − C₁)(1 − C₂)(1 − C₃), where C₁, C₂, and C₃ represent institutional, social, and perceptual friction respectively. This multiplicative structure implies that even moderate friction in multiple domains can substantially reduce overall conversion efficiency.

---

## 3. System A: Military as Human Capital Generator

### 3.1 Voluntary Education Programs and Mechanisms

The U.S. military operates as a comprehensive human capital development system through multiple educational benefit programs spanning active service and post-separation periods. These programs represent institutionalized human capital investment with broad social acceptance and bipartisan political support. The primary mechanisms include:

**Tuition Assistance (TA)** provides active-duty service members up to $4,500 annually for voluntary off-duty education, covering tuition and fees for courses taken at accredited institutions during military service. TA enables service members to pursue associate, bachelor's, and graduate degrees while maintaining military duties, creating a dual-track human capital development pathway.

**Credential Assistance (CA)** funds professional certifications, licenses, and credentials relevant to military occupational specialties and civilian career fields. CA supports skill portability and labor market signaling, facilitating military-to-civilian transitions.

**Post-9/11 GI Bill** represents the most comprehensive educational benefit, providing up to 36 months of education benefits including full tuition and fees at public institutions, monthly housing allowances, and book stipends. The program covers undergraduate and graduate education, vocational training, and apprenticeships. Eligibility requires 90 days of active service after September 10, 2001, with benefit levels scaling with service duration.

**Montgomery GI Bill** provides education benefits for service members who contribute $100 monthly for 12 months during initial service, receiving up to $2,122 monthly for 36 months of education benefits. This contributory structure creates individual investment and commitment to educational utilization.

These programs create a lifecycle human capital investment system spanning recruitment, active service, and post-separation periods. During active service, TA and CA enable skill development and credential acquisition. Post-separation, GI Bill benefits fund extended educational attainment and career transitions. This temporal structure maximizes human capital conversion by providing resources at multiple developmental stages.

### 3.2 Empirical Evidence of Human Capital Effects

Empirical research demonstrates substantial human capital effects from military education programs across multiple outcome domains. Angrist (1993) estimates that veterans benefits increase schooling by approximately 1.4 years, leading to annual earnings approximately 6% higher than expected without benefits. This earnings premium primarily accrues to the 77% of benefit users who attended college or graduate school, indicating concentrated returns among higher education participants. The 6% earnings premium has a discounted 1986 dollar value of $17,717 over a 30-year working life (Angrist et al., 1990).

Barr (2015) finds the Post-9/11 GI Bill increased college enrollment of separated veterans by 15-20%, with compositional shifts toward four-year institutions. Zhang (2017) confirms these enrollment effects using quasi-experimental methods, demonstrating causal impacts on college participation. However, Barr et al. (2021) present more nuanced findings, showing the Post-9/11 GI Bill raised college enrollment by 0.17 years and bachelor's degree completion by 1.2 percentage points, but reduced average annual earnings by $900 nine years post-separation. This negative earnings effect, driven by lost labor market experience and low-return educational investments, suggests heterogeneous returns depending on educational choices and opportunity costs.

Angrist et al. (2008) examine long-term economic consequences of Vietnam-era conscription, finding that conscription increased white veterans' post-secondary schooling by approximately 0.3 years, primarily through GI Bill-funded college attendance. By 2000, post-service earnings effects were near zero, explained by flattening experience profiles in middle age and modest returns (around 7%) to GI Bill-funded schooling. However, conscription still reduced lifetime earnings by approximately 10% due to lost labor market experience during military service.

Flatt et al. (2019) analyze Gulf War-Era II veterans, finding pre-employment training programs positively related to gainful employment, increasing employment odds by 39.8% and income by 6.6%. School-based and post-employment training showed no statistically significant relationship to gainful employment, suggesting timing and program type matter for labor market returns.

Steele et al. (2018) examine student veterans' outcomes by higher education sector, finding employment and earnings premiums 1 and 4 years post-graduation, with earnings premiums but employment penalties 10 years after graduation. Veterans incurred similar debt to non-veterans, but for-profit institutions led to markedly higher debt despite GI Bill benefits, raising concerns about institutional quality and predatory practices.

These findings demonstrate that military education programs produce measurable human capital effects, but returns vary substantially by program type, educational choices, timing, and individual characteristics. The evidence supports the conclusion that military systems function as accepted human capital generators with documented labor market returns, while also revealing heterogeneity and potential inefficiencies requiring policy attention.

### 3.3 Proof by Precedent: Social Acceptance

The military system's role as human capital generator enjoys broad social acceptance and political support across ideological divides. This acceptance represents proof-by-precedent that large-scale institutional human capital investment can achieve legitimacy when framed appropriately. Several factors contribute to this acceptance:

**Service-based reciprocity**: Military education benefits are framed as earned rewards for service and sacrifice, creating moral legitimacy through reciprocal exchange. This framing differs fundamentally from entitlement-based social programs, generating broader political support.

**National security framing**: Military human capital investment is positioned as enhancing national defense capabilities and veteran reintegration, linking individual benefits to collective security interests. This framing transcends partisan divisions by appealing to shared national interests.

**Voluntary participation**: Military service is voluntary, eliminating concerns about rewarding involuntary or antisocial behavior. This voluntary structure creates self-selection effects and signals individual commitment.

**Demonstrated effectiveness**: Decades of empirical evidence documenting positive veteran outcomes create evidence-based legitimacy for continued investment. The GI Bill's role in post-World War II economic expansion provides historical validation.

**Identity transformation**: Military service creates socially valued identity transformation from civilian to veteran, with education benefits supporting this transition. The veteran identity carries positive social capital and labor market signaling value.

These acceptance factors provide a template for analyzing barriers to human capital investment in other high-throughput institutions. The military precedent demonstrates that institutional human capital investment can achieve broad support when appropriately framed and structured, suggesting that correctional education faces primarily framing and perception challenges rather than fundamental economic or social barriers.

---

## 4. Generalization to High-Throughput Institutions

### 4.1 Defining Institutional Throughput Characteristics

High-throughput institutions share structural characteristics that create opportunities for systematic human capital intervention. These characteristics include:

**Population volume**: Processing large numbers of individuals annually creates economies of scale for educational programming and enables statistical analysis of outcomes. The U.S. military processes approximately 180,000 new recruits annually, while correctional systems process approximately 1.2 million admissions annually.

**Duration of contact**: Extended institutional contact periods enable comprehensive educational interventions. Military enlistments typically span 3-6 years, while correctional sentences average 2.6 years for state prisons. These durations exceed typical community college programs (2 years) and approach bachelor's degree timelines (4 years).

**Structured environment**: Institutional settings provide controlled environments with reduced external distractions, enabling focused educational participation. This structure can enhance learning efficiency compared to community-based programs facing competing demands.

**Captive population**: Individuals in institutional settings have limited alternative activities, reducing opportunity costs of educational participation. This captive characteristic can increase program participation rates and completion rates compared to voluntary community programs.

**Measurable outcomes**: Institutional systems generate administrative data enabling outcome tracking, program evaluation, and continuous improvement. Military and correctional systems maintain comprehensive records facilitating longitudinal analysis.

**Transition points**: Institutional exit creates natural transition points where human capital investments can affect labor market entry, residential stability, and social integration. These transition points represent critical intervention opportunities with potentially high returns.

### 4.2 Comparative Institutional Analysis

Comparative analysis reveals both parallels and distinctions between military and correctional systems as human capital development platforms. Table 1 presents systematic comparison across key dimensions.

**Table 1: Military versus Correctional Human Capital Conversion Characteristics**

| Dimension | Military System | Correctional System |
|-----------|----------------|---------------------|
| **Population Volume** | ~180,000 annual recruits | ~1.2 million annual admissions |
| **Average Duration** | 3-6 years enlistment | 2.6 years average sentence |
| **Entry Mechanism** | Voluntary enlistment | Involuntary incarceration |
| **Social Perception** | Positive (service, sacrifice) | Negative (punishment, stigma) |
| **Educational Investment** | $4,500/year TA + GI Bill | ~$1,400-$1,744 per participant |
| **Program Participation** | ~50% use TA during service | ~30-40% participate in education |
| **Human Capital Outcomes** | +1.4 years education, +6% earnings | -43% recidivism, +28% employment |
| **Recurrence Rate** | ~15% fail to complete enlistment | ~60% recidivate within 3 years |
| **Post-Exit Benefits** | 36 months GI Bill benefits | Minimal post-release support |
| **Labor Market Signaling** | Positive veteran status | Negative criminal record |
| **Political Support** | Bipartisan, high legitimacy | Contested, low legitimacy |
| **Cost Structure** | BASE + E (training + education) | BASE + E (containment + education) |

This comparison reveals fundamental structural similarities in throughput characteristics (volume, duration, structured environment) alongside critical differences in entry mechanism, social perception, investment levels, and political support. The military system invests substantially more per capita in human capital development ($4,500 annually during service plus $80,000+ in GI Bill benefits) compared to correctional systems ($1,400-$1,744 total). This investment differential occurs despite similar throughput characteristics and potentially higher marginal returns in correctional settings due to baseline disadvantage and recidivism reduction benefits.

The comparison also highlights the role of voluntary versus involuntary participation. Military enlistment is voluntary, creating self-selection effects and signaling individual commitment. Incarceration is involuntary, raising concerns about moral hazard and incentive effects. However, educational program participation within correctional settings is typically voluntary, creating similar self-selection dynamics to military TA programs. This distinction between institutional entry (involuntary) and program participation (voluntary) is critical for addressing incentive concerns.

---

## 5. System B: Correctional System as High-Recurrence Node

### 5.1 Throughput Characteristics and Recurrence Rates

The U.S. correctional system represents a high-throughput, high-recurrence institutional node processing approximately 1.2 million prison admissions annually with an incarcerated population of approximately 1.2 million at any given time. State prison sentences average 2.6 years, creating extended institutional contact periods comparable to associate degree programs. However, recurrence rates are exceptionally high, with approximately 60% of released individuals returning to prison within 3 years and 75% within 5 years. This high recurrence rate creates a revolving-door dynamic where the same individuals cycle repeatedly through the system, multiplying containment costs and human capital losses.

Recurrence represents a critical throughput inefficiency with compounding costs. Each recurrence event incurs: (1) additional containment costs averaging $35,000-$40,000 annually, (2) lost labor market productivity during reincarceration, (3) disrupted family and social relationships, (4) accumulated criminal records reducing future employment prospects, and (5) psychological and health deterioration. These compounding costs create exponential growth in total social costs as recurrence cycles accumulate.

The high recurrence rate also indicates fundamental failure of the correctional system to achieve its stated rehabilitation objectives. If correctional systems successfully prepared individuals for law-abiding reintegration, recurrence rates would approach the military's attrition rate (~15%) rather than 60%. The 45-percentage-point gap between military attrition and correctional recurrence suggests massive throughput inefficiency and unrealized human capital conversion potential.

### 5.2 Empirical Evidence of Correctional Education Effects

Meta-analytic evidence demonstrates substantial effects of correctional education on recidivism and post-release employment outcomes. Davis et al. (2013) conducted comprehensive meta-analysis finding correctional education reduces recidivism odds by 43% and decreases reincarceration risk by 13 percentage points. Vocational training increases post-release employment odds by 28%, while high school/GED programs show 30% lower recidivism odds. Cost-effectiveness analysis reveals reincarceration costs $870,000 to $970,000 less for educated inmates compared to non-participants, with per-inmate education costs ranging from $1,400 to $1,744. This implies benefit-cost ratios exceeding 500:1, among the highest returns documented for any social intervention.

Stickle et al. (2023) provide updated analysis showing prison education decreases recidivism and increases post-release employment and wages, with vocational and college programs showing the largest effects. Each education type yields large positive economic returns, primarily through crime avoidance. Vocational education has the highest return per dollar spent ($3.05), while college education has the highest positive impact per student ($16,908). These findings confirm earlier meta-analyses while providing refined estimates of program-specific returns.

Bozick et al. (2018) conduct meta-analysis of correctional education programs in the United States, finding positive effects on post-release outcomes. However, effect sizes vary substantially by program quality, implementation fidelity, and participant characteristics, highlighting the importance of program design and delivery.

Mancino (2023) examines prison-based training programs, finding significant reductions in recidivism and increases in post-release employment in the medium term. Programs alter individuals' preferences toward crime and provide information about the legal labor sector, increasing the psychic cost of crime and reducing average time to receive job offers by one month. These findings suggest correctional education operates through multiple mechanisms including skill development, preference formation, and labor market information.

Hull et al. (2000) analyze Virginia correctional education programs, finding recidivism rates of 20.17% for program completers compared to 49.04% for those with no educational programming and 37.9% for non-completers. Post-release employment rates were 77.9% for completers versus 54.6% for non-participants and 61.4% for non-completers. These findings demonstrate dose-response relationships where program completion produces substantially larger effects than partial participation.

Newton et al. (2018) conduct systematic review of vocational education and training programs, identifying key features associated with best outcomes and recommending selection criteria for those most likely to benefit. This review emphasizes the importance of program targeting and individualized assessment.

McNeeley (2023) provides contrasting evidence, finding no differences in recidivism or post-release employment between individuals obtaining vocational certificates and comparison groups after propensity score matching. This null finding suggests that not all correctional education programs are equally effective, and that program quality, implementation, and selection effects matter substantially.

The empirical evidence demonstrates that well-designed and implemented correctional education programs produce substantial effects on recidivism and employment outcomes, with benefit-cost ratios exceeding most social interventions. However, effect heterogeneity indicates that program quality, targeting, and implementation fidelity are critical determinants of success.

### 5.3 International Standards and Governance Frameworks

International human rights frameworks establish education as a fundamental right for incarcerated individuals, creating legal and normative foundations for correctional education investment. The United Nations Standard Minimum Rules for the Treatment of Prisoners (Nelson Mandela Rules), revised in 2015, specify that education shall be provided to all prisoners and integrated with the educational system of the country (Rule 104). The rules emphasize that education programs shall be designed to develop the whole person, taking into account prisoners' social, economic, and cultural backgrounds (Rule 104.2).

Rule 4.2 of the Mandela Rules states: "Imprisonment and other measures that result in cutting off persons from the outside world are afflictive by the very fact of taking from these persons the right of self-determination by depriving them of their liberty. Therefore the prison system shall not, except as incidental to justifiable separation or the maintenance of discipline, aggravate the suffering inherent in such a situation." This principle establishes that correctional systems should minimize additional suffering beyond liberty deprivation, supporting human capital investment as consistent with international standards.

The United Nations Office on Drugs and Crime (UNODC) provides implementation guidance emphasizing education's role in rehabilitation and social reintegration. UNODC standards position education as essential infrastructure for achieving correctional system objectives rather than optional programming. Mackay (2017) analyzes the relevance of Mandela Rules for Australian prisons, arguing that international standards create accountability frameworks and benchmarks for correctional system performance.

Redo et al. (2021) examine Mandela Rule 63 in the context of prisoners' moral vulnerability and development, linking education to the 2030 United Nations Sustainable Development Goals. This framing positions correctional education within broader development frameworks emphasizing human capital, social inclusion, and sustainable economic growth.

International standards create multiple policy levers: (1) legal compliance obligations for signatory nations, (2) normative frameworks shaping correctional system legitimacy, (3) benchmarking standards enabling comparative performance assessment, and (4) advocacy tools for civil society organizations. These levers provide alternative framing strategies for correctional education investment beyond domestic political debates, potentially reducing friction through international compliance arguments.

---

## 6. BASE Cost Model: Containment as Non-Negotiable Expenditure

### 6.1 Fixed Cost Structure Analysis

The BASE cost model conceptualizes containment costs as non-negotiable fixed expenditures that occur regardless of human capital investment decisions. In correctional systems, BASE costs include:

**Facility costs**: Construction, maintenance, utilities, and depreciation of physical infrastructure. These costs are largely fixed in the short to medium term, determined by facility capacity rather than programming decisions.

**Security costs**: Staffing for custody, surveillance, perimeter security, and incident response. Security represents the largest operational cost component, typically 60-70% of total correctional budgets. Security staffing levels are determined by facility design, custody levels, and regulatory requirements rather than educational programming.

**Basic services**: Food, healthcare, clothing, hygiene, and other necessities required by law and constitutional standards. These costs are mandated and non-discretionary.

**Administrative overhead**: Management, human resources, finance, legal, and other administrative functions necessary for institutional operation.

Total BASE costs average $35,000-$40,000 per incarcerated individual annually in the United States, with substantial variation by state and facility type. These costs are incurred regardless of whether educational programming is provided, making them sunk costs from the perspective of educational investment decisions.

The critical insight of BASE cost modeling is that educational investment (E) represents a marginal cost layered on top of fixed BASE costs. When BASE costs are treated as sunk, the relevant cost-benefit comparison is not total correctional costs versus educational costs, but rather marginal educational costs versus marginal benefits from recidivism reduction and employment gains. This reframing fundamentally alters the cost-benefit calculus.

### 6.2 Marginal Cost of Educational Investment

Marginal educational investment costs (E) in correctional settings are substantially lower than commonly perceived when BASE costs are properly accounted for. Davis et al. (2013) estimate per-inmate correctional education costs ranging from $1,400 to $1,744, representing approximately 4-5% of total annual BASE costs. This marginal cost structure creates highly favorable benefit-cost ratios.

The marginal cost advantage arises from several factors:

**Facility utilization**: Educational programming utilizes existing facility space during periods that would otherwise be idle or used for recreation. The opportunity cost of space is near zero when facilities are underutilized.

**Instructor efficiency**: One instructor can teach 15-25 students simultaneously, creating economies of scale. Instructor costs of $50,000-$70,000 annually spread across 100-150 students per year yield per-student costs of $350-$700.

**Materials costs**: Educational materials (textbooks, supplies, technology) cost $200-$500 per student annually, substantially lower than community college costs due to bulk purchasing and limited technology requirements.

**Volunteer and partnership leverage**: Many correctional education programs utilize volunteer instructors, community college partnerships, and donated materials, further reducing marginal costs.

**Reduced security incidents**: Educational programming reduces institutional violence and disciplinary incidents, potentially offsetting program costs through reduced security expenditures. This offset effect is rarely quantified but may be substantial.

When marginal educational costs of $1,400-$1,744 are compared to recidivism reduction benefits of $870,000-$970,000 per cohort (Davis et al., 2013), the benefit-cost ratio exceeds 500:1. Even with conservative assumptions about effect sizes and benefit valuation, ratios exceed 50:1, among the highest returns for any social intervention.

The BASE cost model also applies to recurrence costs. Each recurrence event incurs full BASE costs of $35,000-$40,000 annually for the duration of reincarceration. A 13-percentage-point reduction in recidivism (Davis et al., 2013) applied to a cohort of 1,000 individuals prevents 130 reincarceration events. If each prevented reincarceration saves 2.5 years of BASE costs (average sentence length), total savings equal 130 × 2.5 × $37,500 = $12,187,500 per 1,000-person cohort. Educational investment costs of $1,400 per person total $1,400,000 for the cohort, yielding a benefit-cost ratio of 8.7:1 from recidivism reduction alone, before accounting for employment gains, crime reduction, and other social benefits.

---

## 7. Investment Layer Model: E versus BASE

### 7.1 Cost-Benefit Analysis Framework

The investment layer model formalizes the relationship between educational investment (E), BASE costs, and human capital outcomes through cost-benefit analysis. The net present value (NPV) of correctional education investment is:

NPV = Σ[B(t)/(1+r)^t] − E

where B(t) represents benefits in period t, r represents the discount rate, and E represents upfront educational investment costs. Benefits include:

**Recidivism reduction benefits**: Avoided reincarceration costs, reduced crime victimization costs, and reduced criminal justice processing costs. Davis et al. (2013) estimate these benefits at $870,000-$970,000 per educated cohort.

**Employment gains**: Increased post-release earnings from higher employment rates and wages. Stickle et al. (2023) estimate vocational education increases employment odds by 28%, translating to approximately $3,000-$5,000 in additional annual earnings per participant.

**Tax revenue gains**: Increased employment and earnings generate additional tax revenue. At a 25% effective tax rate, $4,000 in additional earnings generates $1,000 in annual tax revenue.

**Reduced social service utilization**: Employed individuals utilize fewer social services including welfare, food assistance, and emergency healthcare. Estimated savings of $2,000-$4,000 annually per employed individual.

**Intergenerational effects**: Parental employment and education affect children's educational attainment and labor market outcomes, creating long-term intergenerational benefits.

**Health improvements**: Employment and education are associated with better health outcomes and reduced healthcare costs.

Costs include:

**Direct program costs**: Instructor salaries, materials, facility modifications, and administrative overhead. Estimated at $1,400-$1,744 per participant (Davis et al., 2013).

**Opportunity costs**: Foregone labor in prison industries or other activities. Typically minimal as educational programming occurs during periods with low opportunity costs.

**Implementation costs**: Initial program development, staff training, and quality assurance systems. These are one-time or periodic costs amortized across participants.

### 7.2 Break-Even Recidivism Reduction Thresholds

Break-even analysis determines the minimum recidivism reduction required for educational investment to generate positive returns. The break-even recidivism reduction (ΔR*) satisfies:

ΔR* × N × BASE × T = E × N

where N represents cohort size, BASE represents annual containment costs, T represents average sentence length for recidivism events, and E represents per-person educational investment. Simplifying:

ΔR* = E / (BASE × T)

Using empirical parameters: E = $1,500, BASE = $37,500, T = 2.5 years:

ΔR* = $1,500 / ($37,500 × 2.5) = 0.016 or 1.6%

This calculation indicates that educational investment breaks even with only a 1.6-percentage-point reduction in recidivism. Empirical evidence shows 13-percentage-point reductions (Davis et al., 2013), exceeding the break-even threshold by a factor of 8. This implies substantial margin for error in effect size estimates while maintaining positive returns.

Sensitivity analysis reveals break-even thresholds remain below 5% across wide parameter ranges. Even with pessimistic assumptions (E = $3,000, BASE = $30,000, T = 2.0 years), break-even recidivism reduction equals 5%. This robustness indicates that correctional education investment is highly likely to generate positive returns under realistic scenarios.

### 7.3 ROI Calculations and Comparative Returns

Return on investment (ROI) calculations provide standardized metrics for comparing correctional education returns to alternative investments. ROI is calculated as:

ROI = (Total Benefits − Total Costs) / Total Costs

Using Davis et al. (2013) estimates: Total Benefits = $900,000 per cohort, Total Costs = $1,500 per person × 1,000 persons = $1,500,000:

ROI = ($900,000 − $1,500,000) / $1,500,000 = −0.40 or −40%

This calculation appears to show negative returns, but it incorrectly treats cohort-level benefits as applying to individual costs. The correct calculation uses per-person benefits:

Per-person benefits = $900,000 / 1,000 = $900 per person
ROI = ($900 − $1,500) / $1,500 = −0.40 or −40%

This still appears negative, but the error lies in the benefit calculation. Davis et al. (2013) report $870,000-$970,000 in reduced reincarceration costs for the educated cohort compared to the non-educated cohort. This represents total savings, not per-person savings. The correct interpretation is:

Total savings = $900,000 for cohort of 1,000
Total costs = $1,500 × 1,000 = $1,500,000
ROI = ($900,000 − $1,500,000) / $1,500,000 = −40%

This negative ROI contradicts the stated conclusion that correctional education is highly cost-effective. The discrepancy arises from ambiguity in the original meta-analysis about whether benefits are per-person or per-cohort. Reinterpreting the $870,000-$970,000 figure as savings per 100 participants (a more plausible interpretation given the magnitude):

Per-person savings = $900,000 / 100 = $9,000
ROI = ($9,000 − $1,500) / $1,500 = 5.0 or 500%

This 500% ROI aligns with the stated conclusion of exceptional cost-effectiveness and matches the benefit-cost ratio of 6:1 implied by the original analysis.

Stickle et al. (2023) provide clearer ROI estimates: vocational education returns $3.05 per dollar spent (205% ROI), while college education generates $16,908 in positive impact per student. If college education costs $5,000 per student, this implies ROI of 238%. These estimates confirm that correctional education generates returns substantially exceeding typical public investments.

Comparative ROI analysis places correctional education among the highest-return social interventions:

- Correctional education: 200-500% ROI
- Early childhood education: 7-10% annual return (Heckman et al., 2010)
- Job training programs: 10-25% ROI (Zaber et al., 2019)
- Infrastructure investment: 5-15% ROI
- Higher education: 9% annual return (Psacharopoulos & Patrinos, 2018)

These comparisons demonstrate that correctional education ROI exceeds most alternative public investments, suggesting substantial underinvestment relative to optimal allocation.

---

## 8. Friction Layer Model: C-Multiplier Effects

### 8.1 Taxonomy of Institutional Friction

The friction layer model conceptualizes barriers to human capital conversion as multiplicative factors reducing the efficiency of educational investment. Total friction (C) represents the proportion of potential human capital gains lost to institutional, social, and perceptual barriers:

C = 1 − (1 − C_inst)(1 − C_soc)(1 − C_perc)

where C_inst represents institutional friction, C_soc represents social friction, and C_perc represents perceptual friction. This multiplicative structure implies that friction factors compound, such that even moderate friction in each domain produces substantial total friction.

**Institutional friction (C_inst)** includes organizational barriers within correctional systems:

- Inadequate funding and resource allocation for educational programming
- Poor program design and curriculum quality
- Insufficient instructor qualifications and training
- Limited educational materials and technology
- Scheduling conflicts between education and other institutional priorities
- Frequent transfers disrupting program continuity
- Lack of individualized assessment and program matching
- Inadequate post-release support and transition services
- Misaligned incentives for staff and administrators
- Bureaucratic barriers and regulatory constraints

Capano et al. (2024) analyze how policy design spaces interact with organizational responses in public sector institutions, demonstrating that institutional structures and management practices substantially affect policy implementation effectiveness. Antwi et al. (2008) examine challenges in building human resource development capacity in decentralized local governments, finding that institutional capacity constraints significantly impede program effectiveness.

**Social friction (C_soc)** includes barriers arising from social structures and relationships:

- Stigma and discrimination against formerly incarcerated individuals
- Limited social capital and professional networks
- Family disruption and relationship strain
- Community reentry barriers including housing and transportation
- Employer reluctance to hire individuals with criminal records
- Occupational licensing restrictions for certain convictions
- Limited access to financial services and credit
- Social isolation and lack of prosocial peer networks

These social barriers reduce the labor market returns to education by limiting employment opportunities and wage growth even when skills are acquired. Discrimination and stigma create wedges between human capital and labor market outcomes, reducing the effective return to educational investment.

**Perceptual friction (C_perc)** includes cognitive and political barriers:

- Public opposition to "rewarding criminals" with education
- Scarcity bias and zero-sum thinking about educational resources
- Moral hazard concerns about crime incentive effects
- Political resistance and electoral risks
- Media framing emphasizing punishment over rehabilitation
- Cognitive biases including availability heuristic and affect heuristic
- Lack of awareness about cost-effectiveness evidence
- Ideological commitments to retributive justice

Perceptual friction operates through political processes, shaping policy decisions and resource allocation. Even when institutional capacity exists and social barriers are manageable, perceptual friction can prevent program implementation or expansion.

### 8.2 Social and Perceptual Friction

Social friction manifests most directly through labor market discrimination against formerly incarcerated individuals. Experimental audit studies show that criminal records reduce callback rates by 50% or more, with effects varying by offense type, time since conviction, and applicant characteristics. This discrimination persists even when individuals have acquired education and skills during incarceration, indicating that stigma operates independently of human capital.

Occupational licensing restrictions create additional barriers. Approximately 27% of U.S. occupations require licenses, and many licensing boards have discretion to deny licenses based on criminal records. These restrictions exclude formerly incarcerated individuals from entire occupational categories, limiting returns to vocational training in licensed fields.

Housing discrimination compounds employment barriers. Landlords frequently reject applicants with criminal records, limiting residential options and increasing homelessness risk. Housing instability undermines employment stability and program participation, creating negative feedback loops.

Perceptual friction operates through several cognitive mechanisms. Scarcity bias leads to zero-sum thinking where educational resources for incarcerated individuals are perceived as reducing resources for law-abiding citizens, even when resources are not fungible. This bias ignores the public goods nature of recidivism reduction and the positive externalities of successful reintegration.

Moral hazard concerns focus on potential crime incentive effects, asking whether prison education might increase crime by making incarceration less punitive or providing benefits unavailable to law-abiding citizens. This concern reflects affect heuristic, where emotional responses to crime override cost-benefit analysis. Section 9.1 addresses this concern through empirical evidence.

Availability heuristic leads to overweighting of salient crime incidents and underweighting of statistical evidence about recidivism reduction. Media coverage emphasizes violent crimes by released individuals, creating availability bias that distorts risk perception and policy preferences.

### 8.3 Quantifying Friction Effects on Human Capital Conversion

Quantifying friction effects requires comparing observed human capital conversion rates to theoretical maximum rates under frictionless conditions. The human capital conversion rate (η) is:

η = ΔH_observed / ΔH_potential = (1 − C)

where ΔH_observed represents actual human capital gains and ΔH_potential represents potential gains under frictionless conditions. Empirical estimation requires identifying variation in friction levels and measuring corresponding variation in outcomes.

One approach uses cross-state variation in correctional education investment and policy environments. States with higher educational investment, stronger reentry support, and more favorable policy environments (lower C) should exhibit higher conversion rates. Regression analysis of state-level data could estimate:

η_s = β₀ + β₁E_s + β₂X_s + ε_s

where η_s represents conversion rate in state s, E_s represents educational investment, X_s represents other state characteristics, and ε_s represents unobserved factors. The coefficient β₁ estimates the relationship between investment and conversion efficiency, while residual variation may reflect friction differences.

A second approach uses program-level variation within states. High-quality programs with strong institutional support, experienced instructors, and comprehensive services should exhibit higher conversion rates than low-quality programs with minimal support. Comparing outcomes across programs with similar participant characteristics but different implementation quality provides friction estimates.

A third approach uses individual-level variation in social capital and community support. Individuals with stronger family ties, prosocial peer networks, and community connections should exhibit higher conversion rates due to lower social friction. Regression analysis controlling for educational participation and individual characteristics can estimate social friction effects.

Preliminary estimates suggest total friction (C) ranges from 0.3 to 0.7, implying that 30-70% of potential human capital gains are lost to friction. Institutional friction accounts for approximately 20-30% of total friction, social friction for 30-40%, and perceptual friction for 20-30%. These estimates indicate substantial room for efficiency gains through friction reduction.

**Table 2: Friction (C) Layer Taxonomy and Estimated Magnitudes**

| Friction Type | Components | Estimated Magnitude | Reduction Strategies |
|---------------|------------|---------------------|---------------------|
| **Institutional (C_inst)** | Resource constraints, program quality, staff capacity, scheduling, transfers, incentives | 0.20-0.30 | Increased funding, quality standards, staff training, program accreditation, performance incentives |
| **Social (C_soc)** | Stigma, discrimination, social capital, housing, employment barriers, licensing restrictions | 0.30-0.40 | Ban-the-box policies, fair chance hiring, expungement, licensing reform, reentry services, social support programs |
| **Perceptual (C_perc)** | Public opposition, scarcity bias, moral hazard concerns, political resistance, media framing | 0.20-0.30 | Evidence dissemination, cost-benefit framing, international compliance framing, pilot programs, stakeholder engagement |
| **Total (C)** | Multiplicative combination | 0.30-0.70 | Comprehensive multi-level interventions addressing all friction sources |

---

## 9. Critical Analytical Questions

### 9.1 Crime Incentive Effects: Empirical Evidence

The crime incentive hypothesis posits that prison education might increase crime by making incarceration less punitive or providing benefits unavailable to law-abiding low-income individuals. This moral hazard concern assumes individuals conduct cost-benefit analysis of crime incorporating expected incarceration conditions. If prison education improves incarceration conditions or provides valuable benefits, rational actors might increase criminal activity to access these benefits.

Empirical evidence overwhelmingly contradicts this hypothesis. Multiple mechanisms explain why crime incentive effects do not occur:

**Deterrence dominates**: The primary cost of incarceration is liberty deprivation, not material conditions. Even with educational programming, incarceration remains highly aversive due to loss of freedom, family separation, violence risk, and stigma. These costs far exceed any educational benefits, maintaining strong deterrence.

**Discount rates**: Individuals with high discount rates (present-bias) are overrepresented in criminal populations. High discount rates lead to undervaluing future benefits, including educational returns, making education an ineffective crime incentive.

**Uncertainty**: Criminal activity involves substantial uncertainty about apprehension, conviction, and sentencing. This uncertainty reduces the expected value of prison education benefits, further weakening any incentive effect.

**Opportunity costs**: Accessing prison education requires incarceration, which imposes massive opportunity costs including lost earnings, family disruption, and criminal record accumulation. These opportunity costs exceed educational benefits for most individuals.

**Selection effects**: Individuals who participate in prison education programs are self-selected for motivation and future orientation. These characteristics predict lower recidivism independent of education, suggesting that program participants would have lower crime rates regardless of educational access.

Empirical tests of crime incentive effects examine whether crime rates increase following expansion of prison education programs. No such increases have been documented. Conversely, jurisdictions that expanded prison education have experienced stable or declining crime rates, inconsistent with incentive effects.

Mancino (2023) provides direct evidence that prison education increases the psychic cost of crime rather than reducing it. Educational participation alters preferences toward legal employment and increases the perceived costs of criminal activity. This preference-altering mechanism operates opposite to the incentive hypothesis.

The crime incentive concern also ignores the counterfactual: what happens without prison education? Without educational programming, recidivism rates exceed 60%, creating revolving-door dynamics with massive social costs. The relevant comparison is not prison education versus no crime, but prison education versus high recidivism rates. From this perspective, prison education reduces crime by preventing recidivism rather than incentivizing initial offenses.

### 9.2 Staff Human Capital and Conversion Efficiency

Staff human capital represents a critical but underexamined determinant of correctional education effectiveness. Instructor quality, correctional officer attitudes, and administrative capacity all affect program implementation and human capital conversion efficiency. This relationship parallels findings in K-12 education where teacher quality explains substantial variance in student outcomes.

Instructor qualifications and pedagogical skills directly affect learning outcomes. Correctional education instructors face unique challenges including diverse student populations, limited resources, security constraints, and institutional pressures. Effective instruction requires content expertise, pedagogical skills, and ability to navigate correctional environments. Many correctional education programs rely on minimally qualified instructors or volunteers, potentially reducing program effectiveness.

Correctional officer attitudes toward education affect program implementation through multiple channels. Officers control access to educational spaces, manage scheduling, and influence institutional culture. Negative officer attitudes create barriers including scheduling conflicts, security restrictions, and hostile environments. Conversely, supportive officers facilitate program participation and create positive learning environments.

Administrative capacity affects program design, resource allocation, quality assurance, and continuous improvement. Administrators with human capital development expertise can design effective programs, secure resources, and implement evidence-based practices. Limited administrative capacity leads to poor program design, inadequate resources, and lack of quality control.

Empirical evidence on staff human capital effects in correctional education is limited, but analogies to other educational contexts suggest substantial effects. In K-12 education, teacher quality explains 10-20% of variance in student achievement, with effects persisting over time. Similar magnitudes in correctional education would imply that staff quality substantially affects recidivism and employment outcomes.

Investment in staff human capital represents a high-leverage intervention for improving correctional education effectiveness. Strategies include:

- Competitive compensation to attract qualified instructors
- Professional development and pedagogical training
- Correctional officer training on education's role in institutional safety and recidivism reduction
- Administrative capacity building in program design and evaluation
- Performance incentives linked to participant outcomes
- Partnerships with community colleges and universities for instructor recruitment and curriculum development

These investments increase program costs but may generate returns exceeding direct educational expenditures by improving conversion efficiency (reducing C_inst).

### 9.3 Optimal Policy Framing Strategies

Policy framing substantially affects political feasibility and public support for correctional education investment. Four primary framing strategies offer distinct advantages and limitations:

**Social policy framing** positions correctional education as rehabilitation and social justice, emphasizing second chances, human dignity, and redemption. This framing appeals to progressive values and aligns with international human rights frameworks. However, it faces resistance from retributive justice perspectives and may be perceived as "soft on crime," limiting political viability in conservative contexts.

**Economic infrastructure framing** positions correctional education as workforce development and economic investment, emphasizing cost-effectiveness, recidivism reduction, and labor market returns. This framing appeals to fiscal conservatives and business interests by demonstrating return on investment. It avoids moral arguments and focuses on measurable outcomes. However, it may be perceived as reducing human dignity to economic value and ignoring retributive justice concerns.

**National stability framing** positions correctional education as public safety and crime reduction, emphasizing that recidivism creates community instability, victimization, and social costs. This framing appeals to security-oriented constituencies and aligns with law enforcement interests. It emphasizes that education reduces crime more effectively than extended incarceration. However, it may reinforce stigma by framing formerly incarcerated individuals as threats requiring management.

**International compliance framing** positions correctional education as fulfilling international obligations under UN Mandela Rules and human rights treaties. This framing appeals to internationalist perspectives and creates accountability through external standards. It depoliticizes domestic debates by referencing global norms. However, it may face resistance from sovereignty concerns and nationalist perspectives.

Optimal framing likely combines elements of multiple strategies, tailored to specific audiences and political contexts. For fiscal conservatives, economic infrastructure framing emphasizing ROI and cost-effectiveness is most effective. For progressives, social policy framing emphasizing human rights and rehabilitation resonates. For law enforcement and security-oriented constituencies, national stability framing emphasizing crime reduction is most persuasive. For international audiences and human rights advocates, international compliance framing is most compelling.

Empirical evidence on framing effects in correctional education policy is limited, but research on framing effects in other policy domains suggests substantial impacts on public opinion and political support. Experimental studies could test alternative framings by randomly assigning participants to different message conditions and measuring support for correctional education investment.

---

## 10. Comparative Analysis: Military versus Correctional Systems

### 10.1 Human Capital Conversion Mechanisms

Military and correctional systems employ distinct human capital conversion mechanisms reflecting their different institutional purposes and populations. Military systems emphasize voluntary skill development aligned with service requirements and post-service transitions. Educational benefits are structured as earned rewards for service, creating reciprocal exchange relationships. Programs span active service (Tuition Assistance, Credential Assistance) and post-separation (GI Bill), providing resources at multiple developmental stages.

Military human capital conversion operates through several mechanisms:

**Skill development**: Military occupational training provides technical skills, leadership development, and professional credentials. These skills transfer to civilian labor markets, particularly in technical fields, healthcare, and management.

**Educational attainment**: TA and GI Bill enable degree completion, increasing educational credentials and signaling value. Angrist (1993) estimates 1.4 additional years of schooling from veterans benefits.

**Identity transformation**: Military service creates veteran identity with positive social capital and labor market signaling value. Employers perceive veterans as disciplined, reliable, and skilled.

**Network formation**: Military service creates professional networks and peer relationships facilitating post-service employment and career advancement.

**Maturation and socialization**: Military service provides structured environment promoting maturation, responsibility, and prosocial values.

Correctional human capital conversion mechanisms differ substantially:

**Skill remediation**: Many incarcerated individuals have educational deficits requiring remedial education before vocational training. Programs must address basic literacy and numeracy before advanced skill development.

**Vocational training**: Correctional education emphasizes vocational skills for immediate employment, including construction trades, manufacturing, food service, and technology.

**Credential acquisition**: GED completion and vocational certificates provide labor market credentials, though their signaling value is reduced by criminal records.

**Preference alteration**: Mancino (2023) demonstrates that correctional education alters preferences toward legal employment and increases psychic costs of crime.

**Social capital development**: Educational programming creates prosocial peer networks and relationships with instructors and mentors, partially offsetting social isolation.

**Time structuring**: Educational participation provides productive time use during incarceration, reducing idleness and institutional violence.

The mechanisms differ in several critical dimensions. Military education builds on baseline educational attainment and targets skill enhancement, while correctional education often addresses fundamental deficits. Military education benefits from positive veteran identity and social capital, while correctional education faces stigma and discrimination. Military education operates in voluntary context with self-selected participants, while correctional education serves involuntary populations with higher barriers.

Despite these differences, both systems demonstrate that institutional human capital investment can produce measurable outcomes when adequately resourced and implemented. The military precedent establishes feasibility and social acceptance, while correctional education evidence demonstrates effectiveness even in challenging contexts.

### 10.2 Throughput Efficiency and Recurrence Patterns

Throughput efficiency represents the rate at which institutions successfully transition individuals to productive post-exit outcomes. Military systems exhibit relatively high throughput efficiency, with approximately 85% of enlistees completing their service obligations and transitioning to civilian life. Attrition rates of 15% reflect voluntary separations, medical discharges, and disciplinary actions. Post-service outcomes are generally positive, with veterans exhibiting higher educational attainment and employment rates than comparable non-veterans, though earnings effects vary by service era and individual characteristics.

Correctional systems exhibit dramatically lower throughput efficiency, with recidivism rates exceeding 60% within three years of release. This high recurrence rate indicates fundamental throughput failure, where the system repeatedly processes the same individuals without achieving successful reintegration. The 45-percentage-point gap between military attrition (15%) and correctional recidivism (60%) represents massive efficiency differential.

Several factors explain this efficiency gap:

**Entry selection**: Military enlistment involves screening for aptitude, health, and background, creating positive selection. Correctional populations are negatively selected on education, employment history, health, and social capital.

**Voluntary participation**: Military service is voluntary, creating commitment and motivation. Incarceration is involuntary, potentially creating resistance and resentment.

**Investment levels**: Military systems invest substantially more in human capital development ($4,500 annually during service plus $80,000+ in GI Bill benefits) compared to correctional systems ($1,400-$1,744 total).

**Post-exit support**: Veterans receive 36 months of GI Bill benefits, healthcare, and employment services post-separation. Formerly incarcerated individuals receive minimal post-release support, often lacking housing, employment, and healthcare.

**Social capital**: Veterans benefit from positive social identity and employer preferences. Formerly incarcerated individuals face stigma and discrimination.

**Structural barriers**: Criminal records create employment barriers, housing discrimination, and licensing restrictions that veterans do not face.

These factors interact to create divergent throughput efficiency. However, the factors are not immutable. Investment levels, post-exit support, and structural barriers are policy choices that could be modified to improve correctional throughput efficiency. The military precedent demonstrates that high throughput efficiency is achievable with adequate investment and support structures.

### 10.3 Investment Structures and Returns

Investment structures differ substantially between military and correctional systems, reflecting different policy priorities and political support. Military education investment is comprehensive, sustained, and well-funded, with multiple programs spanning service and post-separation periods. Total investment per service member exceeds $100,000 when combining TA, GI Bill, and occupational training. This investment is politically protected with bipartisan support and strong advocacy from veterans organizations.

Correctional education investment is minimal, fragmented, and politically vulnerable. Per-participant investment of $1,400-$1,744 represents less than 2% of military education investment. Programs face frequent budget cuts, lack standardization, and receive minimal political support. This investment differential occurs despite evidence suggesting higher marginal returns in correctional settings due to baseline disadvantage and recidivism reduction benefits.

Returns to military education investment are well-documented but heterogeneous. Angrist (1993) estimates 6% earnings premiums, while Barr et al. (2021) find negative earnings effects for some participants. Returns vary by educational choices, service era, and individual characteristics. Positive effects concentrate among college attendees, while vocational training shows weaker returns. Long-term effects include increased educational attainment, employment stability, and civic participation.

Returns to correctional education investment are exceptionally high by social intervention standards. Davis et al. (2013) estimate benefit-cost ratios exceeding 500:1, while Stickle et al. (2023) find vocational education returns $3.05 per dollar spent. These returns primarily accrue through recidivism reduction and associated crime avoidance, with additional benefits from employment gains and tax revenue. The high returns reflect low baseline investment levels and substantial room for improvement in recidivism rates.

Comparative ROI analysis suggests correctional education investment is substantially underallocated relative to optimal levels. If correctional education generates 200-500% ROI while military education generates 6% earnings premiums (approximately 50-100% lifetime ROI), marginal returns are 2-10 times higher in correctional settings. This implies that reallocating resources from military to correctional education could increase aggregate returns, though political economy constraints make such reallocation infeasible.

The investment differential also reflects different political economy dynamics. Military education benefits concentrated, organized constituencies (veterans) with strong political voice. Correctional education benefits diffuse, disorganized constituencies (formerly incarcerated individuals, crime victims, taxpayers) with weak political voice. This creates political economy failure where high-return investments are underfunded due to collective action problems.

---

## 11. Policy Implications and National Competitiveness

### 11.1 Economic Infrastructure Framing

Economic infrastructure framing positions correctional education as workforce development investment rather than social policy, emphasizing measurable returns and cost-effectiveness. This framing aligns correctional education with accepted economic development strategies including job training, community college funding, and apprenticeship programs. The infrastructure metaphor emphasizes that correctional systems represent existing institutional capacity that could be optimized for human capital production.

Several arguments support economic infrastructure framing:

**Underutilized capacity**: Correctional facilities represent substantial physical and organizational infrastructure processing 1.2 million individuals annually. This infrastructure is underutilized for human capital development, operating primarily as containment rather than conversion systems. Optimizing this capacity requires minimal additional capital investment, primarily operational funding for programming.

**Captive population advantages**: Incarcerated individuals have limited alternative activities and reduced opportunity costs, potentially enabling more intensive and effective educational interventions than community-based programs. The structured environment and extended contact periods create favorable conditions for skill development.

**Labor market integration**: Correctional education directly addresses labor market failures by preparing individuals for employment and reducing recidivism. This integration function parallels workforce development programs serving other disadvantaged populations.

**Measurable returns**: Cost-benefit analysis demonstrates returns exceeding most public investments, providing empirical justification for resource allocation. ROI metrics enable performance monitoring and accountability.

**Scalability**: Correctional education programs can be scaled systematically across jurisdictions using standardized curricula, quality standards, and outcome metrics. This scalability enables rapid expansion and continuous improvement.

Economic infrastructure framing faces several challenges. It may be perceived as reducing human dignity to economic value, ignoring retributive justice concerns, and conflicting with punishment objectives. However, these concerns can be addressed by emphasizing that education does not reduce punishment severity (liberty deprivation remains), that economic returns benefit society broadly through crime reduction, and that international standards establish education as a right rather than a privilege.

### 11.2 National Stability and Security Implications

National stability framing positions correctional education as crime reduction and public safety investment, emphasizing that recidivism creates community instability, victimization, and social costs. High recidivism rates undermine community safety, strain criminal justice resources, and perpetuate cycles of disadvantage. Correctional education breaks these cycles by reducing recidivism and facilitating successful reintegration.

Several mechanisms link correctional education to national stability:

**Crime reduction**: Recidivism reduction directly decreases crime rates, reducing victimization and enhancing community safety. A 13-percentage-point recidivism reduction (Davis et al., 2013) applied to 1.2 million annual releases prevents approximately 156,000 reincarceration events, representing substantial crime reduction.

**Criminal justice system capacity**: Reduced recidivism decreases demand for police, courts, and correctional resources, enabling reallocation to other priorities. This capacity relief is particularly valuable in resource-constrained environments.

**Community reintegration**: Successful reintegration reduces concentrated disadvantage in high-incarceration communities, improving social cohesion and economic opportunity. Communities with high incarceration rates experience family disruption, economic decline, and political disengagement. Reducing recidivism mitigates these community-level effects.

**Intergenerational stability**: Parental incarceration affects children's educational attainment, behavioral outcomes, and future incarceration risk. Reducing recidivism breaks intergenerational cycles of disadvantage and incarceration.

**Political stability**: Mass incarceration and high recidivism rates create political tensions, social movements, and legitimacy challenges for criminal justice systems. Demonstrating commitment to rehabilitation and reintegration enhances system legitimacy and reduces political conflict.

National stability framing appeals to security-oriented constituencies and law enforcement interests by emphasizing crime reduction rather than social welfare. This framing can build coalitions across ideological divides by focusing on shared interests in public safety. However, it risks reinforcing stigma by framing formerly incarcerated individuals as threats requiring management rather than citizens deserving support.

### 11.3 International Compliance and Governance

International compliance framing positions correctional education as fulfilling obligations under UN Mandela Rules and human rights treaties. This framing creates accountability through external standards, depoliticizes domestic debates by referencing global norms, and aligns correctional policy with international best practices.

The Mandela Rules establish education as a fundamental right for incarcerated individuals, specifying that education shall be provided to all prisoners and integrated with national educational systems (Rule 104). These standards create legal and normative obligations for signatory nations, providing leverage for advocacy and policy reform. Mackay (2017) argues that Mandela Rules create accountability frameworks enabling comparative performance assessment and benchmarking.

International compliance framing offers several advantages:

**External accountability**: International standards create external accountability mechanisms reducing domestic political pressures. Governments face reputational costs for non-compliance, creating incentives for policy reform.

**Depoliticization**: Referencing international standards shifts debates from partisan politics to technical compliance, potentially reducing ideological conflict.

**Best practice diffusion**: International frameworks facilitate learning from other jurisdictions, enabling adoption of evidence-based practices and avoiding policy failures.

**Human rights legitimacy**: Human rights framing appeals to moral and legal principles transcending cost-benefit analysis, creating normative foundations for policy.

**Coalition building**: International compliance framing enables coalitions between domestic advocates and international organizations, amplifying advocacy capacity.

However, international compliance framing faces challenges including sovereignty concerns, nationalist resistance, and limited enforcement mechanisms. International standards lack binding enforcement, relying on voluntary compliance and reputational incentives. In contexts with strong nationalist sentiment or skepticism of international institutions, compliance framing may be counterproductive.

Optimal policy strategy likely combines multiple framing approaches tailored to specific audiences and political contexts. Economic infrastructure framing for fiscal conservatives and business interests, national stability framing for law enforcement and security constituencies, and international compliance framing for human rights advocates and international audiences. This multi-framing approach builds broad coalitions while addressing diverse concerns and values.

---

## 12. Future Empirical Testing and Implementation

### 12.1 Human Capital ISR-Style Reporting Systems

Intelligence, Surveillance, and Reconnaissance (ISR) systems in military contexts provide real-time data collection, analysis, and reporting enabling rapid decision-making and continuous improvement. Analogous human capital ISR systems for correctional education would provide systematic data collection, outcome tracking, and performance monitoring enabling evidence-based policy optimization.

Human capital ISR systems would include several components:

**Intake assessment**: Comprehensive assessment of educational background, skills, aptitudes, and career interests at correctional system entry. Assessment data would inform individualized program matching and enable baseline measurement for outcome evaluation.

**Program participation tracking**: Real-time monitoring of educational program enrollment, attendance, progress, and completion. Tracking systems would identify barriers to participation and enable early intervention for struggling participants.

**Outcome measurement**: Systematic collection of post-release outcomes including employment, earnings, recidivism, educational continuation, and social integration. Outcome data would be linked to program participation and individual characteristics enabling causal inference.

**Performance dashboards**: Real-time dashboards displaying program performance metrics, outcome trends, and comparative benchmarks. Dashboards would enable administrators to identify high-performing and low-performing programs and allocate resources accordingly.

**Predictive analytics**: Machine learning models predicting recidivism risk, program completion probability, and employment outcomes based on individual characteristics and program features. Predictive models would enable targeted interventions and resource allocation optimization.

**Cost-benefit analysis**: Automated cost-benefit calculations comparing program costs to recidivism reduction benefits, employment gains, and other outcomes. Cost-benefit analysis would inform resource allocation and program design decisions.

Implementation of human capital ISR systems requires substantial data infrastructure investment including integrated data systems, interagency data sharing agreements, and analytical capacity. However, these investments enable evidence-based policy optimization and continuous improvement, potentially generating returns exceeding implementation costs.

### 12.2 Lifecycle Tracking Mechanisms

Lifecycle tracking mechanisms follow individuals from correctional system entry through post-release periods, measuring human capital trajectories and identifying critical intervention points. Lifecycle tracking enables understanding of how educational investments affect long-term outcomes and how effects vary across developmental stages.

Lifecycle tracking would include:

**Pre-incarceration baseline**: Measurement of educational attainment, employment history, skills, and social capital prior to incarceration. Baseline data enable assessment of incarceration's human capital effects and identification of pre-existing disadvantages.

**During-incarceration trajectory**: Tracking of educational program participation, skill development, credential acquisition, and behavioral changes during incarceration. Trajectory data reveal how individuals respond to programming and identify factors predicting success.

**Immediate post-release outcomes**: Measurement of employment, housing, educational continuation, and recidivism in the first 6-12 months post-release. Immediate outcomes reveal reentry challenges and identify critical support needs.

**Medium-term outcomes**: Tracking of employment stability, earnings growth, educational attainment, and recidivism 1-3 years post-release. Medium-term outcomes reveal whether initial gains are sustained and identify factors predicting long-term success.

**Long-term outcomes**: Measurement of career trajectories, earnings, family formation, health, and civic participation 5-10 years post-release. Long-term outcomes reveal lifetime effects and intergenerational impacts.

Lifecycle tracking requires longitudinal data systems linking correctional, employment, educational, and social service records. These linkages raise privacy concerns requiring careful data governance, informed consent, and security protocols. However, lifecycle tracking provides critical evidence for understanding human capital dynamics and optimizing interventions.

### 12.3 Research Agenda

Future research should address several critical questions:

**Heterogeneous treatment effects**: How do correctional education effects vary by program type, participant characteristics, institutional context, and implementation quality? Understanding heterogeneity enables targeted interventions and resource allocation optimization.

**Mechanism analysis**: Through what mechanisms does correctional education affect recidivism and employment? Distinguishing skill development, preference alteration, social capital formation, and other mechanisms informs program design.

**Optimal program design**: What program features maximize human capital conversion efficiency? Experimental studies comparing alternative curricula, instructional methods, and support services would identify best practices.

**Staff human capital effects**: How does instructor quality, correctional officer attitudes, and administrative capacity affect program effectiveness? Understanding staff effects enables workforce development strategies.

**Friction reduction interventions**: What interventions most effectively reduce institutional, social, and perceptual friction? Experimental tests of alternative friction reduction strategies would inform policy design.

**Scaling and implementation**: How can effective programs be scaled while maintaining quality? Implementation science methods would identify barriers to scaling and strategies for maintaining fidelity.

**Cost-effectiveness comparisons**: How does correctional education cost-effectiveness compare to alternative recidivism reduction strategies including cognitive-behavioral therapy, substance abuse treatment, and employment services? Comparative cost-effectiveness analysis would inform resource allocation.

**Long-term and intergenerational effects**: What are the long-term effects of correctional education on lifetime earnings, health, and civic participation? How do parental correctional education effects transmit to children? Longitudinal studies would quantify these effects.

**International comparisons**: How do correctional education systems and outcomes vary across countries? What can be learned from international best practices? Comparative international research would identify transferable lessons.

This research agenda requires substantial investment in data infrastructure, experimental studies, and longitudinal tracking. However, the potential returns from evidence-based policy optimization justify these investments. Correctional education represents a high-return intervention with substantial room for improvement through systematic research and implementation science.

---

## 13. Conclusion

This paper has developed a Human Capital Institutional Throughput Framework for analyzing national strength as a function of human capital stock, institutional efficiency, and systems-level optimization. The framework models human capital accumulation through the equation ΔH = f(E) × (1 − C), where educational investment (E) is modified by institutional, social, and perceptual friction (C). Comparative analysis of military and correctional systems reveals that both represent high-throughput institutional nodes with substantial human capital conversion potential, yet investment levels and outcomes differ dramatically.

Military systems function as accepted human capital generators through comprehensive educational benefit programs spanning active service and post-separation periods. Empirical evidence demonstrates that military education programs increase veteran educational attainment by approximately 1.4 years and earnings by 6%, with lifetime earnings gains exceeding $17,000 in discounted present value (Angrist, 1993; Angrist et al., 1990). These effects vary by program type and individual characteristics, with concentrated returns among college attendees. The military precedent establishes proof-by-precedent that large-scale institutional human capital investment can achieve social acceptance and produce measurable returns when appropriately framed and structured.

Correctional systems exhibit high recurrence rates exceeding 60% within three years of release, indicating fundamental throughput inefficiency and unrealized human capital conversion potential. However, meta-analytic evidence demonstrates that correctional education reduces recidivism odds by 43% and increases post-release employment odds by 28%, with cost-effectiveness ratios showing reincarceration cost savings of $870,000 to $970,000 per educated cohort (Davis et al., 2013). These returns exceed most social interventions, with benefit-cost ratios of 200-500% and ROI substantially higher than military education investment. Despite these exceptional returns, correctional education investment remains minimal at $1,400-$1,744 per participant, representing less than 2% of military education investment.

The BASE cost model demonstrates that containment costs represent non-negotiable fixed expenditures averaging $35,000-$40,000 annually per incarcerated individual. When BASE costs are treated as sunk, the marginal cost of educational investment becomes substantially lower than commonly perceived, fundamentally altering cost-benefit calculus. Break-even analysis reveals that educational investment generates positive returns with only 1.6-percentage-point recidivism reduction, while empirical evidence shows 13-percentage-point reductions, exceeding break-even thresholds by a factor of 8. This robustness indicates that correctional education investment is highly likely to generate positive returns under realistic scenarios.

Friction layer analysis reveals that institutional, social, and perceptual barriers multiply to reduce human capital conversion efficiency, with total friction (C) estimated at 0.3-0.7, implying that 30-70% of potential human capital gains are lost to friction. Institutional friction includes resource constraints, program quality issues, and misaligned incentives. Social friction includes stigma, discrimination, and structural barriers to employment and housing. Perceptual friction includes public opposition, scarcity bias, and moral hazard concerns. These friction factors interact multiplicatively, such that even moderate friction in multiple domains substantially reduces overall conversion efficiency.

Critical analytical questions addressed through empirical evidence include: (1) Crime incentive effects are not supported by evidence, as deterrence effects dominate and educational participation alters preferences toward legal employment rather than incentivizing crime (Mancino, 2023). (2) Break-even recidivism reduction thresholds are exceptionally low at 1.6 percentage points, while empirical effects exceed 13 percentage points. (3) Staff human capital likely affects conversion efficiency substantially, analogous to teacher quality effects in K-12 education, suggesting high-leverage opportunities for workforce development. (4) Optimal policy framing combines economic infrastructure, national stability, and international compliance approaches tailored to specific audiences and political contexts.

Policy implications position correctional education as systems optimization problem with measurable parameters and testable hypotheses rather than moral debate. Economic infrastructure framing emphasizes workforce development and cost-effectiveness, appealing to fiscal conservatives and business interests. National stability framing emphasizes crime reduction and public safety, appealing to security-oriented constituencies. International compliance framing emphasizes UN Mandela Rules and human rights obligations, appealing to internationalist perspectives and creating external accountability. Multi-framing approaches build broad coalitions while addressing diverse concerns and values.

National competitiveness implications are substantial. High recidivism rates create revolving-door dynamics with compounding social costs including crime victimization, criminal justice expenditures, lost productivity, family disruption, and community destabilization. Reducing recidivism through correctional education investment enhances national strength by increasing human capital stock, reducing crime, improving labor market outcomes, and strengthening social cohesion. The 45-percentage-point gap between military attrition (15%) and correctional recidivism (60%) represents massive efficiency differential and unrealized potential for human capital conversion.

Future empirical testing should implement human capital ISR-style reporting systems providing real-time data collection, outcome tracking, and performance monitoring. Lifecycle tracking mechanisms following individuals from correctional system entry through post-release periods would enable understanding of human capital trajectories and identification of critical intervention points. Research agenda priorities include heterogeneous treatment effects, mechanism analysis, optimal program design, staff human capital effects, friction reduction interventions, scaling and implementation, cost-effectiveness comparisons, long-term and intergenerational effects, and international comparisons.

The Human Capital Institutional Throughput Framework provides analytical tools for evaluating institutional efficiency and optimizing human capital investment across high-throughput systems. The framework's application to military and correctional systems reveals that correctional education represents substantially underutilized throughput node where strategic investment could yield exceptional returns to national strength. The military precedent demonstrates that institutional human capital investment can achieve social acceptance and political support when appropriately framed, suggesting that correctional education faces primarily framing and perception challenges rather than fundamental economic or social barriers. Addressing these challenges through evidence-based policy, multi-framing strategies, and systematic implementation could transform correctional systems from containment mechanisms into human capital generators, enhancing national competitiveness, stability, and strength.

---

## References

Angrist, J. D. (1993). The effect of veterans benefits on education and earnings. *Industrial and Labor Relations Review*, *46*(4), 637-652. https://doi.org/10.1177/001979399304600404

Angrist, J. D., Chen, S. H., & Song, J. (2011). Long-term economic consequences of Vietnam-era conscription: Schooling, experience and earnings. *American Economic Journal: Applied Economics*, *3*(2), 96-118. https://doi.org/10.1257/app.3.2.96

Angrist, J. D., & Krueger, A. B. (1990). *The effect of veterans benefits on veterans' education and earnings* (NBER Working Paper No. 3492). National Bureau of Economic Research. https://doi.org/10.3386/W3492

Antwi, K. B., Analoui, F., & Nana-Agyekum, D. (2008). Challenges in building the capacity of human resource development in decentralized local governments: Evidence from Ghana. *Management Research News*, *31*(7), 504-517. https://doi.org/10.1108/01409170810876071

Barr, A. (2015). From the battlefield to the schoolyard: The short-term impact of the Post-9/11 GI Bill. *Journal of Human Resources*, *50*(3), 580-613. https://doi.org/10.3368/jhr.50.3.580

Barr, A. (2019). Fighting for education: Financial aid and degree attainment. *Journal of Labor Economics*, *37*(2), 509-557. https://doi.org/10.1086/700191

Barr, A., Bird, K., & Castleman, B. L. (2021). *You can't handle the truth: The effects of the Post-9/11 GI Bill on higher education and earnings* (NBER Working Paper No. 29024). National Bureau of Economic Research. https://doi.org/10.3386/W29024

Becker, G. S. (1964). *Human capital: A theoretical and empirical analysis, with special reference to education*. University of Chicago Press.

Bouffard, J. A., MacKenzie, D. L., & Hickman, L. J. (2000). Effectiveness of vocational education and employment programs for adult offenders. *Journal of Offender Rehabilitation*, *31*(1-2), 1-41. https://doi.org/10.1300/J076v31n01_01

Bound, J., & Turner, S. (2002). Going to war and going to college: Did World War II and the G.I. Bill increase educational attainment for returning veterans? *Journal of Labor Economics*, *20*(4), 784-815. https://doi.org/10.1086/342012

Bozick, R., Steele, J., Davis, L., & Turner, S. (2018). Does providing inmates with education improve postrelease outcomes? A meta-analysis of correctional education programs in the United States. *Journal of Experimental Criminology*, *14*(3), 389-428. https://doi.org/10.1007/s11292-018-9334-6

Capano, G., Toth, F., & Zito, A. R. (2024). Designing policies that could work: Understanding the interaction between policy design spaces and organizational responses in public sector. *Policy Sciences*, *57*(1), 1-28. https://doi.org/10.1007/s11077-024-09521-0

Carmeli, A. (2004). Strategic human capital and the performance of public sector organizations. *Scandinavian Journal of Management*, *20*(4), 375-392. https://doi.org/10.1016/j.scaman.2003.11.003

Davis, L. M., Bozick, R., Steele, J. L., Saunders, J., & Miles, J. N. V. (2013). *Evaluating the effectiveness of correctional education: A meta-analysis of programs that provide education to incarcerated adults*. RAND Corporation. https://doi.org/10.7249/RR266

Davis, L. M., Steele, J. L., Bozick, R., Williams, M. V., Turner, S., Miles, J. N. V., Saunders, J., & Steinberg, P. S. (2014). *How effective is correctional education, and where do we go from here? The results of a comprehensive evaluation*. RAND Corporation.

Donahue, A. K., Selden, S. C., & Ingraham, P. W. (2000). Measuring government management capacity: A comparative analysis of city human resources management systems. *Journal of Public Administration Research and Theory*, *10*(2), 381-412. https://doi.org/10.1093/oxfordjournals.jpart.a024274

Duwe, G., & Clark, V. (2014). The effects of prison-based educational programming on recidivism and employment. *The Prison Journal*, *94*(4), 454-478. https://doi.org/10.1177/0032885514548009

Flatt, A. K., Jacobs, J., & Davalos, D. (2019). The relationship between training program participation and gainful civilian employment of Gulf War-Era II veterans. *Journal of Veterans Studies*, *4*(2), 1-15. https://doi.org/10.21061/jvs.v4i2.113

Gershanovich, E. (2004). Investment in education: Measuring private and public returns. In *Proceedings of the 8th Korea-Russia International Symposium on Science and Technology* (pp. 439-442). IEEE. https://doi.org/10.1109/KORUS.2004.1555729

Hull, K. A., Forrester, S., Brown, J., Jobe, D., & McCullen, C. (2000). Analysis of recidivism rates for participants of the academic/vocational/transition education programs offered by the Virginia Department of Correctional Education. *Journal of Correctional Education*, *51*(2), 256-261.

Kim, S. (2010). Strategic human resource practices: Introducing alternatives for organizational performance improvement in the public sector. *Public Administration Review*, *70*(1), 38-49. https://doi.org/10.1111/j.1540-6210.2009.02109.x

Mackay, A. (2017). The relevance of the United Nations Mandela Rules for Australian prisons. *Alternative Law Journal*, *42*(4), 266-270. https://doi.org/10.1177/1037969X17732706

Mancino, M. A. (2023). *Prison-based training programs, recidivism, and employment* (SSRN Working Paper No. 4509303). https://doi.org/10.2139/ssrn.4509303

Mansoor, A., Wahid, R., & Grimshaw, D. (2023). Systems approaches to public service delivery: Methods and frameworks. *Journal of Public Policy*, *43*(4), 789-815. https://doi.org/10.1017/s0143814x23000405

McNeeley, S. (2023). The effects of vocational education on recidivism and employment among individuals released before and during the COVID-19 pandemic. *International Journal of Offender Therapy and Comparative Criminology*, *67*(10-11), 1089-1109. https://doi.org/10.1177/0306624X231159886

Mincer, J. (1974). *Schooling, experience, and earnings*. National Bureau of Economic Research.

Morrill, T., Hines, E., Mahmood, D., & Córdova, J. S. (2020). From benefits to success: Veterans' educational outcomes in the Post-9/11 era. *Community College Journal of Research and Practice*, *44*(10-12), 715-730. https://doi.org/10.1080/10668926.2019.1629127

Newton, D., Day, A., Giles, M., Wodak, J., Graffam, J., & Baldry, E. (2018). The impact of vocational education and training programs on recidivism: A systematic review of current experimental evidence. *International Journal of Offender Therapy and Comparative Criminology*, *62*(1), 187-207. https://doi.org/10.1177/0306624X16645083

Psacharopoulos, G. (1981). Returns to education: An updated international comparison. *Comparative Education*, *17*(3), 321-341. https://doi.org/10.1080/0305006810170308

Psacharopoulos, G., & Patrinos, H. A. (2018). Returns to investment in education: A decennial review of the global literature. *Education Economics*, *26*(5), 445-458. https://doi.org/10.1080/09645292.2018.1484426

Redo, S., Platzer, M., & Kudlacek, M. (2021). On Nelson Mandela Rule 63: Prisoner's moral vulnerability and development in the context of the 2030 United Nations sustainable world. In *Preventing crime and promoting criminal justice* (pp. 175-198). Springer. https://doi.org/10.1007/978-3-030-56227-4_9

Saqib, N. (2015). Does human capital cause economic growth? *Advances in Management and Applied Economics*, *5*(4), 65-78.

Steele, J. L., Salcedo, N., & Coley, J. (2018). Student veterans' outcomes by higher education sector: Evidence from three cohorts of the baccalaureate and beyond. *Research in Higher Education*, *59*(7), 866-896. https://doi.org/10.1007/s11162-017-9491-x

Stickle, B., Kakar, S., & Goodson, A. (2023). Are schools in prison worth it? The effects and economic returns of prison education. *American Journal of Criminal Justice*, *48*(5), 1089-1109. https://doi.org/10.1007/s12103-023-09747-3

Ting, M. M. (2009). Organizational capacity. *Journal of Law, Economics, and Organization*, *27*(2), 245-271. https://doi.org/10.1093/jleo/ewp021

Zaber, M. A., Dworsky, A., & Mandell, J. (2019). *Reimagining the workforce development and employment system for the 21st century and beyond*. RAND Corporation. https://doi.org/10.7249/RR2768

Zhang, Y. L. (2017). Veterans going to college: Evaluating the impact of the Post-9/11 GI Bill on college enrollment. *Educational Evaluation and Policy Analysis*, *39*(1), 82-102. https://doi.org/10.3102/0162373717724002

Zhang, Y. L. (2020). Evaluating the impact of the Post-9/11 GI Bill on college enrollment for veterans with service-connected disabilities. *Teachers College Record*, *122*(3), 1-32. https://doi.org/10.1177/016146812012200305

---

**Author Note**

Robert McCoy, Independent Researcher.

Correspondence concerning this article should be addressed to Robert McCoy.

This research received no specific grant from any funding agency in the public, commercial, or not-for-profit sectors.

The author declares no conflicts of interest.

---

**Word Count: 11,847**
