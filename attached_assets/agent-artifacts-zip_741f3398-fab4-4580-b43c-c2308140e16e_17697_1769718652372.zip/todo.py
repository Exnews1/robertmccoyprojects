I'll help you create a comprehensive doctoral-level research paper on Human Capital Institutional Throughput Framework comparing military and correctional systems. Let me start by conducting a thorough literature search to gather the necessary academic sources.

Planner Code plan:
```python
def main():
    # 1. Conduct comprehensive literature search on human capital institutional frameworks
    search_query = "human capital institutional throughput frameworks military correctional systems education policy economics"
    
    # 2. Search academic databases for relevant research
    scholarly_results = scholarly_literature_search(
        query=search_query,
        databases=["scispace", "google_scholar", "arxiv"],
        max_results_per_db=100,
        output_file_path="/home/sandbox/human_capital_literature.json"
    )
    
    # 3. Search for specific domains
    military_education_search = scholarly_literature_search(
        query="military voluntary education tuition assistance GI Bill human capital outcomes",
        databases=["scispace", "google_scholar"],
        max_results_per_db=50,
        output_file_path="/home/sandbox/military_hc_literature.json"
    )
    
    correctional_education_search = scholarly_literature_search(
        query="correctional education recidivism human capital Mandela Rules prison rehabilitation economics",
        databases=["scispace", "google_scholar"],
        max_results_per_db=50,
        output_file_path="/home/sandbox/correctional_hc_literature.json"
    )
    
    # 4. Search for institutional theory and systems modeling
    institutional_theory_search = scholarly_literature_search(
        query="institutional throughput theory systems human capital conversion policy frameworks",
        databases=["scispace", "google_scholar"],
        max_results_per_db=40,
        output_file_path="/home/sandbox/institutional_theory_literature.json"
    )
    
    # 5. Extract insights from all search results
    insights = extract_insights_from_search_results(
        search_results_paths=[
            "/home/sandbox/human_capital_literature.json",
            "/home/sandbox/military_hc_literature.json", 
            "/home/sandbox/correctional_hc_literature.json",
            "/home/sandbox/institutional_theory_literature.json"
        ],
        user_questions="""
        1. What are the key theories and models of human capital development in institutional settings?
        2. How do military voluntary education programs contribute to human capital formation?
        3. What does research show about correctional education effectiveness on recidivism and human capital?
        4. How do institutional throughput frameworks model human capital conversion?
        5. What are the economic models for measuring human capital ROI in institutional settings?
        6. How do Mandela Rules relate to human capital preservation in corrections?
        7. What friction factors affect institutional human capital conversion?
        8. How can we model national strength as a function of human capital stock and institutional throughput?
        """,
        return_reply_to_user=False
    )
    
    # 6. Create comprehensive research paper
    paper_content = write_report(
        task="Create a doctoral-level APA 7 research paper titled 'Human Capital Institutional Throughput Framework: A Comparative Analysis of Military and Correctional Systems' with the following requirements: 8000-12000 words, dense citations, comparative analysis, economic modeling, systems theory framework, Mandela Rules integration, policy implications, tables and figures. Focus on the core thesis: National Strength (S) as function of Human Capital Stock (H), Institutional Throughput (T), Recurrence/Re-entry Failure (R), Containment Base Cost (BASE), Human Capital Investment per Individual (E), and Institutional/Social Friction (C) with ΔH = f(E) × (1 − C).",
        output_file_path="/home/sandbox/human_capital_paper.md"
    )
    
    print("Research paper created successfully at /home/sandbox/human_capital_paper.md")
    
if __name__ == "__main__":
    main()
```