# Policy Research Illustrations: Human Capital Institutional Throughput Framework

## Deliverables Summary

Two professional policy research illustrations created for the Human Capital Institutional Throughput Framework research paper by Robert McCoy.

---

## Illustration 1: Current System Loop — High Recurrence Custody Cycle

**File**: `us_correctional_system_cycle.png`

**Purpose**: Visualize the current U.S. correctional system as a self-reinforcing closed-loop cycle with continuous taxpayer funding flowing into containment infrastructure.

### Visual Elements Included:

✅ **Central Node**: ~2M Incarcerated Population (large deep navy circle)

✅ **Circular Flow Arrows**: 
- Arrest → Incarceration → Release → Reentry Instability → Reoffense → Arrest
- Thick navy arrows showing continuous cycle

✅ **High Recidivism Indicator**: Soft red/orange glow on "Reoffense" node emphasizing the high-recurrence loop

✅ **Taxpayer Funding Streams**: Multiple gray arrows flowing from all directions into the system, labeled "Taxpayer Funding"

✅ **Reentry Instability Indicators** (abstract, respectful):
- Fractured briefcase icon (Job Instability)
- Broken house icon (Housing Instability)
- Disconnected network nodes (Social Disconnection)

✅ **Background**: Neutral institutional grid texture with faded U.S. map silhouettes

### Design Specifications:

- **Color Palette**: Deep navy, muted gray, soft red accent
- **Style**: Clean data visualization, government report infographic
- **Aspect Ratio**: 16:9 (website hero card format)
- **Mood**: Analytical, systemic, neutral
- **Tone**: No faces, no prison suffering imagery, no political messaging

### Use Cases:

- Research paper Figure 3 or supplementary illustration
- Executive summary visual
- Website hero section background
- Policy presentation slide
- Government report infographic

---

## Illustration 2: Future State — Human Capital Investment Reducing Recurrence Over Time

**File**: `correctional_system_transformation.png`

**Purpose**: Visualize how education and human capital investment transform the correctional system from high-recurrence containment to productive workforce reintegration.

### Visual Elements Included:

✅ **LEFT SIDE (Current State - Fading)**:
- ~2M Prison Population node (muted gray/brown)
- Thick recurrence loop with "Reoffense" highlighted in soft red
- High taxpayer funding streams (gray arrows)
- Reentry instability indicators (job, housing, social disconnection)

✅ **CENTER (Transformation Layer)**:
- **"HUMAN CAPITAL INVESTMENT LAYER"** banner (bright blue background)
- Education symbols flowing into system:
  - Books and textbooks
  - Credential certificates
  - Trade skills tools (wrench/gear)
  - Digital learning (computer/tablet)
  - Professional certifications
  - Vocational training icons
- Blue arrows showing investment flowing into "Transforming Correctional Population"

✅ **RIGHT SIDE (Future State)**:
- "Reduced Incarcerated Population" node (smaller, deep blue)
- Thin recurrence loop (fading, reduced)
- Strong outward green arrows to positive outcomes:
  - **Workforce Participation** (briefcase + growth chart)
  - **Stable Housing** (house + key)
  - **Community Reintegration** (handshake + network)
  - **Economic Growth & Safer Communities**
- "Reduced Taxpayer Cost" label on smaller funding stream

### Design Specifications:

- **Color Palette**: 
  - Left = Muted gray + soft red (current inefficiency)
  - Center = Blue + white (investment/intervention)
  - Right = Deep blue + muted green (stability/productivity)
- **Style**: Clean infographic, policy visualization, consistent with Illustration 1
- **Aspect Ratio**: 16:9 (website hero card format)
- **Mood**: Optimistic but grounded, system improvement focus
- **Tone**: No propaganda, no "miracle cure" visuals, no faces

### Use Cases:

- Research paper Figure 4 or supplementary illustration
- Executive summary transformation visual
- Website transformation section
- Policy presentation "future state" slide
- Legislative briefing materials

---

## Technical Specifications

### Both Illustrations:

- **Format**: PNG (high resolution)
- **Aspect Ratio**: 16:9 (1920x1080 recommended for web use)
- **Style Consistency**: Government/academic publication ready
- **Color Theory**: 
  - Red/orange = inefficiency, recurrence, cost
  - Blue = intervention, investment, transformation
  - Green = stability, productivity, positive outcomes
  - Gray = neutral infrastructure, taxpayer burden
- **Typography**: Clean sans-serif, high readability
- **Accessibility**: High contrast, clear labeling, colorblind-friendly palette

### Design Principles Applied:

1. **Systems Thinking**: Visual emphasis on flows, loops, and feedback mechanisms
2. **Economic Framing**: Taxpayer costs and ROI clearly visible
3. **Neutral Tone**: Analytical rather than emotional or political
4. **Respectful Representation**: Abstract symbols rather than individuals or suffering
5. **Evidence-Based**: Visual elements correspond to empirical findings in research paper

---

## Integration with Research Paper

### Recommended Placement:

**Main Research Paper** (`McCoy_Human_Capital_Institutional_Throughput_Framework.md`):
- Illustration 1 → Section 6 or 7 (Prison System as High Recurrence Throughput Node)
- Illustration 2 → Section 11 or 12 (Policy Implications / Future State)

**Executive Summary** (`Executive_Summary_Public_Policy.md`):
- Illustration 1 → "System B: Correctional Human Capital Model" section
- Illustration 2 → "Policy Implications: A Systems Optimization Roadmap" section

**Website** (`Website_Content_Blocks.json`):
- Illustration 1 → Hero section or "correctional_model_summary"
- Illustration 2 → "policy_implications" or transformation section

---

## Caption Recommendations

### For Illustration 1:

**Short Caption**: 
"Figure 3. Current U.S. Correctional System: High Recurrence Custody Cycle. The system processes 10.6 million admissions annually with 60% recidivism, creating a self-reinforcing loop consuming continuous taxpayer funding."

**Extended Caption**: 
"Figure 3. Current State Correctional System Model. The U.S. correctional system operates as a closed-loop cycle with ~2 million incarcerated population experiencing continuous flows through arrest, incarceration, release, reentry instability, reoffense, and re-arrest. Taxpayer funding streams continuously into containment infrastructure ($100 billion/year BASE costs). Reentry instability manifests as job market barriers, housing insecurity, and social network disconnection, contributing to 60% recidivism within 5 years—a 45-percentage-point efficiency gap compared to military systems (15% attrition)."

### For Illustration 2:

**Short Caption**: 
"Figure 4. Future State Correctional System: Human Capital Investment Reducing Recurrence. Education and training investment transforms high-recurrence containment into productive workforce reintegration, reducing recidivism by 43% and generating 200-500% ROI."

**Extended Caption**: 
"Figure 4. Transformation Model Through Human Capital Investment. The illustration depicts system evolution from current high-recurrence state (left) through human capital investment intervention (center) to optimized future state (right). The Human Capital Investment Layer introduces education, credentials, vocational training, and digital learning into the correctional population, reducing recidivism from 60% to 34% (43% reduction per Davis et al., 2013). Outward flows increase to workforce participation (+28% employment), stable housing, community reintegration, and economic growth. Total taxpayer cost decreases through reduced re-incarceration despite education investment, demonstrating break-even at 1.6 percentage points recidivism reduction versus 13-43 percentage points empirical effects."

---

## File Deliverables

1. **us_correctional_system_cycle.png** - Current system high recurrence loop
2. **correctional_system_transformation.png** - Future state transformation model
3. **ILLUSTRATION_DELIVERABLES.md** - This documentation file

---

## Usage Rights & Attribution

**Author**: Robert McCoy  
**Created for**: Human Capital Institutional Throughput Framework Research Paper  
**Style**: Professional policy research visualization  
**Licensing**: [Specify as needed for publication]

**Suggested Attribution**: 
"Illustrations created for 'Human Capital Institutional Throughput Framework: A Comparative Analysis of Military and Correctional Systems' by Robert McCoy (2026)."

---

## Additional Notes

### Consistency with Research Framework:

Both illustrations align with the core thesis framework:
- **ΔH = f(E) × (1 − C)** visually represented through investment flows and friction barriers
- **BASE costs** shown as continuous taxpayer funding regardless of education investment
- **Friction coefficient (C)** implied through thickness of recurrence loops and instability indicators
- **Throughput efficiency** visualized through population flows and outcome pathways

### Accessibility Considerations:

- High contrast text and icons
- Clear labeling without relying solely on color
- Scalable vector-style design elements
- Readable at multiple sizes (presentation, print, web)

### Future Illustration Opportunities:

If additional visuals are needed:
- Friction Taxonomy detailed breakdown (Table 2 as infographic)
- Military vs. Correctional comparison side-by-side
- International comparison (U.S. vs. Nordic model recidivism)
- Break-even ROI calculator visualization
- ISR-style human capital tracking system diagram

---

**Document Created**: 2026-01-29  
**For**: Robert McCoy Human Capital Institutional Throughput Framework Project  
**Version**: 1.0
