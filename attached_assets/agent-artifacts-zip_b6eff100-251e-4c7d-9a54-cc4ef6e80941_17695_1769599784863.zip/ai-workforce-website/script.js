// Progress bar
window.addEventListener('scroll', function() {
    const winScroll = document.body.scrollTop || document.documentElement.scrollTop;
    const height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
    const scrolled = (winScroll / height) * 100;
    document.getElementById('progressBar').style.width = scrolled + '%';
});

// Smooth scrolling for navigation
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Modal functionality
function closeModal() {
    document.getElementById('detailModal').style.display = 'none';
}

window.onclick = function(event) {
    const modal = document.getElementById('detailModal');
    if (event.target == modal) {
        modal.style.display = 'none';
    }
}

// Detailed content for statistics
const detailContent = {
    stat1: {
        title: '33% of US Jobs Face High AI Exposure',
        content: `
            <h3 class="text-2xl font-bold mb-4">High AI Exposure Analysis</h3>
            <p class="mb-4">Research analyzing occupational task structures reveals that approximately one-third of US employment faces high exposure to AI technologies, particularly in roles involving routine cognitive tasks, data processing, and standardized decision-making.</p>
            
            <h4 class="text-xl font-semibold mb-3 mt-6">Most Exposed Occupations:</h4>
            <ul class="list-disc pl-6 space-y-2 mb-4">
                <li><strong>Financial Analysts and Advisors:</strong> 85% task exposure due to data analysis and pattern recognition capabilities</li>
                <li><strong>Customer Service Representatives:</strong> 78% exposure through chatbots and automated response systems</li>
                <li><strong>Administrative Assistants:</strong> 72% exposure via scheduling, documentation, and coordination automation</li>
                <li><strong>Market Research Analysts:</strong> 81% exposure through data mining and predictive analytics</li>
                <li><strong>Legal Assistants:</strong> 69% exposure from document review and legal research automation</li>
            </ul>
            
            <h4 class="text-xl font-semibold mb-3 mt-6">Key Implications:</h4>
            <ul class="list-disc pl-6 space-y-2 mb-4">
                <li>High exposure does not equate to immediate job loss but indicates significant transformation potential</li>
                <li>Workers in exposed occupations require proactive reskilling and upskilling interventions</li>
                <li>Organizations must develop transition strategies for affected roles</li>
                <li>Policy frameworks needed to support workforce adaptation</li>
            </ul>
            
            <div class="bg-blue-50 p-4 rounded-lg mt-6">
                <p class="text-sm"><strong>Research Note:</strong> AI exposure metrics based on task-level analysis from O*NET database, labor economics research, and industry adoption patterns (Felten et al., 2023; Eloundou et al., 2023).</p>
            </div>
        `
    },
    stat2: {
        title: '50% of Workers Need Reskilling by 2030',
        content: `
            <h3 class="text-2xl font-bold mb-4">Reskilling Imperative</h3>
            <p class="mb-4">Multiple research streams converge on the projection that approximately half of the global workforce will require significant reskilling within the next five years due to AI-driven workplace transformation.</p>
            
            <h4 class="text-xl font-semibold mb-3 mt-6">Critical Skill Domains:</h4>
            <div class="space-y-4 mb-4">
                <div class="border-l-4 border-purple-500 pl-4">
                    <h5 class="font-semibold">Technical AI Competencies (40% of reskilling need)</h5>
                    <p class="text-sm text-gray-700">Data literacy, AI tool proficiency, basic programming, automation understanding</p>
                </div>
                <div class="border-l-4 border-blue-500 pl-4">
                    <h5 class="font-semibold">Cognitive & Analytical Skills (30% of reskilling need)</h5>
                    <p class="text-sm text-gray-700">Critical thinking, complex problem-solving, systems thinking, creative innovation</p>
                </div>
                <div class="border-l-4 border-green-500 pl-4">
                    <h5 class="font-semibold">Human-Centric Skills (20% of reskilling need)</h5>
                    <p class="text-sm text-gray-700">Emotional intelligence, leadership, communication, collaboration, adaptability</p>
                </div>
                <div class="border-l-4 border-yellow-500 pl-4">
                    <h5 class="font-semibold">Domain-Specific Expertise (10% of reskilling need)</h5>
                    <p class="text-sm text-gray-700">Industry-specific AI applications, specialized tool proficiency, sector knowledge</p>
                </div>
            </div>
            
            <h4 class="text-xl font-semibold mb-3 mt-6">Reskilling Pathways:</h4>
            <ul class="list-disc pl-6 space-y-2 mb-4">
                <li><strong>Formal Education:</strong> Degree programs, certifications, professional courses (15-20% of workers)</li>
                <li><strong>On-the-Job Training:</strong> Employer-sponsored programs, mentorship, project-based learning (40-45%)</li>
                <li><strong>Online Learning:</strong> MOOCs, micro-credentials, self-directed study (25-30%)</li>
                <li><strong>Hybrid Approaches:</strong> Combining multiple modalities for comprehensive skill development (20-25%)</li>
            </ul>
            
            <div class="bg-yellow-50 p-4 rounded-lg mt-6">
                <p class="text-sm"><strong>Challenge:</strong> Current reskilling infrastructure can only reach approximately 15-20% of affected workers annually, creating a significant capacity gap that requires urgent public and private sector investment.</p>
            </div>
        `
    },
    stat3: {
        title: '54% of AI Adopters Automated Processes',
        content: `
            <h3 class="text-2xl font-bold mb-4">Process Automation in Practice</h3>
            <p class="mb-4">Survey data from organizations that have adopted AI technologies reveals that more than half have successfully automated at least one significant business process, with cascading effects on workforce composition and skill requirements.</p>
            
            <h4 class="text-xl font-semibold mb-3 mt-6">Most Commonly Automated Processes:</h4>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div class="bg-purple-50 p-4 rounded">
                    <h5 class="font-semibold mb-2">Data Entry & Processing (68%)</h5>
                    <p class="text-sm">Automated data extraction, validation, and system integration</p>
                </div>
                <div class="bg-blue-50 p-4 rounded">
                    <h5 class="font-semibold mb-2">Customer Service (61%)</h5>
                    <p class="text-sm">Chatbots, automated ticketing, FAQ handling</p>
                </div>
                <div class="bg-green-50 p-4 rounded">
                    <h5 class="font-semibold mb-2">Document Processing (57%)</h5>
                    <p class="text-sm">Contract analysis, invoice processing, compliance checking</p>
                </div>
                <div class="bg-yellow-50 p-4 rounded">
                    <h5 class="font-semibold mb-2">Scheduling & Coordination (52%)</h5>
                    <p class="text-sm">Meeting scheduling, resource allocation, workflow optimization</p>
                </div>
            </div>
            
            <h4 class="text-xl font-semibold mb-3 mt-6">Impact on Workforce:</h4>
            <ul class="list-disc pl-6 space-y-2 mb-4">
                <li><strong>Role Transformation:</strong> 73% report existing roles evolved rather than eliminated</li>
                <li><strong>Skill Shifts:</strong> 68% require workers to develop new technical competencies</li>
                <li><strong>Productivity Gains:</strong> Average 35% efficiency improvement in automated processes</li>
                <li><strong>Job Quality:</strong> 59% report improved job satisfaction as routine tasks are automated</li>
                <li><strong>New Positions:</strong> 41% created new roles focused on AI system management and optimization</li>
            </ul>
            
            <h4 class="text-xl font-semibold mb-3 mt-6">Organizational Outcomes:</h4>
            <div class="bg-gradient-to-r from-green-50 to-blue-50 p-4 rounded-lg">
                <ul class="space-y-2">
                    <li>✓ <strong>Cost Reduction:</strong> Average 22% operational cost savings</li>
                    <li>✓ <strong>Error Reduction:</strong> 45% fewer process errors</li>
                    <li>✓ <strong>Speed Improvement:</strong> 3-5x faster process completion</li>
                    <li>✓ <strong>Scalability:</strong> Enhanced capacity without proportional headcount growth</li>
                </ul>
            </div>
        `
    },
    stat4: {
        title: '30% of Work Hours Automatable by 2030',
        content: `
            <h3 class="text-2xl font-bold mb-4">Automation Potential Analysis</h3>
            <p class="mb-4">Comprehensive task-level analysis suggests that approximately 30% of current work hours across the US economy could be technically automated by 2030, though actual automation rates will depend on economic, social, and regulatory factors.</p>
            
            <h4 class="text-xl font-semibold mb-3 mt-6">Automation by Sector:</h4>
            <div class="space-y-3 mb-4">
                <div class="flex items-center">
                    <div class="w-48 font-semibold">Manufacturing</div>
                    <div class="flex-1 bg-gray-200 rounded-full h-6">
                        <div class="bg-purple-600 h-6 rounded-full" style="width: 45%"></div>
                    </div>
                    <div class="w-16 text-right font-semibold">45%</div>
                </div>
                <div class="flex items-center">
                    <div class="w-48 font-semibold">Transportation</div>
                    <div class="flex-1 bg-gray-200 rounded-full h-6">
                        <div class="bg-purple-600 h-6 rounded-full" style="width: 42%"></div>
                    </div>
                    <div class="w-16 text-right font-semibold">42%</div>
                </div>
                <div class="flex items-center">
                    <div class="w-48 font-semibold">Retail Trade</div>
                    <div class="flex-1 bg-gray-200 rounded-full h-6">
                        <div class="bg-purple-600 h-6 rounded-full" style="width: 38%"></div>
                    </div>
                    <div class="w-16 text-right font-semibold">38%</div>
                </div>
                <div class="flex items-center">
                    <div class="w-48 font-semibold">Financial Services</div>
                    <div class="flex-1 bg-gray-200 rounded-full h-6">
                        <div class="bg-purple-600 h-6 rounded-full" style="width: 35%"></div>
                    </div>
                    <div class="w-16 text-right font-semibold">35%</div>
                </div>
                <div class="flex items-center">
                    <div class="w-48 font-semibold">Healthcare</div>
                    <div class="flex-1 bg-gray-200 rounded-full h-6">
                        <div class="bg-purple-600 h-6 rounded-full" style="width: 28%"></div>
                    </div>
                    <div class="w-16 text-right font-semibold">28%</div>
                </div>
                <div class="flex items-center">
                    <div class="w-48 font-semibold">Education</div>
                    <div class="flex-1 bg-gray-200 rounded-full h-6">
                        <div class="bg-purple-600 h-6 rounded-full" style="width: 22%"></div>
                    </div>
                    <div class="w-16 text-right font-semibold">22%</div>
                </div>
            </div>
            
            <h4 class="text-xl font-semibold mb-3 mt-6">Task Categories:</h4>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                <div class="bg-red-50 p-4 rounded">
                    <h5 class="font-semibold text-red-700 mb-2">High Automation (50-70%)</h5>
                    <ul class="text-sm space-y-1">
                        <li>• Data collection</li>
                        <li>• Routine processing</li>
                        <li>• Predictable physical work</li>
                        <li>• Basic calculations</li>
                    </ul>
                </div>
                <div class="bg-yellow-50 p-4 rounded">
                    <h5 class="font-semibold text-yellow-700 mb-2">Medium Automation (30-50%)</h5>
                    <ul class="text-sm space-y-1">
                        <li>• Data analysis</li>
                        <li>• Information gathering</li>
                        <li>• Structured communication</li>
                        <li>• Monitoring activities</li>
                    </ul>
                </div>
                <div class="bg-green-50 p-4 rounded">
                    <h5 class="font-semibold text-green-700 mb-2">Low Automation (10-30%)</h5>
                    <ul class="text-sm space-y-1">
                        <li>• Creative work</li>
                        <li>• Complex problem-solving</li>
                        <li>• Interpersonal interaction</li>
                        <li>• Strategic planning</li>
                    </ul>
                </div>
            </div>
            
            <div class="bg-blue-50 p-4 rounded-lg mt-6">
                <p class="text-sm"><strong>Important Context:</strong> Technical feasibility does not equal actual implementation. Economic viability, social acceptance, regulatory frameworks, and ethical considerations will significantly influence actual automation rates, likely resulting in 15-20% actual automation by 2030 rather than the full 30% technical potential.</p>
            </div>
        `
    },
    readiness1: {
        title: 'Current State of US Workforce Readiness',
        content: `
            <h3 class="text-2xl font-bold mb-4">Workforce Readiness Assessment</h3>
            <p class="mb-4">Comprehensive analysis reveals a complex landscape of workforce readiness for AI integration, with significant variation across demographic, educational, and occupational dimensions.</p>
            
            <h4 class="text-xl font-semibold mb-3 mt-6">Readiness by Education Level:</h4>
            <div class="space-y-4 mb-4">
                <div class="border-l-4 border-green-500 pl-4 bg-green-50 p-3">
                    <h5 class="font-semibold">Advanced Degree Holders (Master's/PhD)</h5>
                    <p class="text-sm mb-2"><strong>Readiness Score: 7.8/10</strong></p>
                    <p class="text-sm">High technical literacy, strong adaptive learning capabilities, access to continuous education resources. Primary gap: practical AI tool implementation experience.</p>
                </div>
                <div class="border-l-4 border-yellow-500 pl-4 bg-yellow-50 p-3">
                    <h5 class="font-semibold">Bachelor's Degree Holders</h5>
                    <p class="text-sm mb-2"><strong>Readiness Score: 6.2/10</strong></p>
                    <p class="text-sm">Moderate technical foundation, variable exposure to AI concepts. Significant gaps in hands-on AI experience and advanced data literacy.</p>
                </div>
                <div class="border-l-4 border-orange-500 pl-4 bg-orange-50 p-3">
                    <h5 class="font-semibold">Associate Degree/Some College</h5>
                    <p class="text-sm mb-2"><strong>Readiness Score: 4.5/10</strong></p>
                    <p class="text-sm">Limited technical background, minimal AI exposure. Require comprehensive foundational training and accessible learning pathways.</p>
                </div>
                <div class="border-l-4 border-red-500 pl-4 bg-red-50 p-3">
                    <h5 class="font-semibold">High School or Less</h5>
                    <p class="text-sm mb-2"><strong>Readiness Score: 2.8/10</strong></p>
                    <p class="text-sm">Substantial readiness gaps across all dimensions. Face highest displacement risk with lowest access to training resources. Urgent policy intervention needed.</p>
                </div>
            </div>
            
            <h4 class="text-xl font-semibold mb-3 mt-6">Key Readiness Indicators:</h4>
            <ul class="list-disc pl-6 space-y-2 mb-4">
                <li><strong>Digital Literacy:</strong> 68% of workforce has basic digital skills, only 23% have advanced capabilities</li>
                <li><strong>AI Awareness:</strong> 54% aware of AI's workplace impact, only 19% understand specific implications for their role</li>
                <li><strong>Learning Engagement:</strong> 41% actively pursuing skill development, 33% uncertain about what skills to develop</li>
                <li><strong>Tool Proficiency:</strong> 15% have used generative AI tools professionally, 31% have experimented personally</li>
                <li><strong>Adaptive Mindset:</strong> 57% express openness to learning new technologies, 28% report anxiety about AI</li>
            </ul>
            
            <h4 class="text-xl font-semibold mb-3 mt-6">Demographic Disparities:</h4>
            <div class="bg-gradient-to-r from-purple-50 to-blue-50 p-4 rounded-lg">
                <ul class="space-y-2 text-sm">
                    <li><strong>Age:</strong> Workers 25-40 show highest readiness (6.8/10); 55+ show lowest (3.9/10)</li>
                    <li><strong>Gender:</strong> Men slightly higher readiness (5.7/10) vs. women (5.3/10), primarily due to tech sector concentration</li>
                    <li><strong>Race/Ethnicity:</strong> Asian workers highest (6.5/10), followed by White (5.5/10), Hispanic (4.8/10), Black (4.6/10)</li>
                    <li><strong>Income:</strong> Strong correlation between income and readiness (r=0.72), reflecting education and resource access</li>
                </ul>
            </div>
        `
    },
    readiness2: {
        title: 'Industry-Specific AI Integration Patterns',
        content: `
            <h3 class="text-2xl font-bold mb-4">Sectoral Analysis of AI Adoption</h3>
            <p class="mb-4">Different industries face distinct AI integration challenges and opportunities, requiring tailored workforce development strategies.</p>
            
            <h4 class="text-xl font-semibold mb-3 mt-6">Healthcare Sector:</h4>
            <div class="bg-blue-50 p-4 rounded-lg mb-4">
                <p class="font-semibold mb-2">AI Adoption Rate: 62% | Workforce Readiness: 6.1/10</p>
                <ul class="text-sm space-y-2">
                    <li><strong>Primary Applications:</strong> Diagnostic imaging analysis, clinical decision support, administrative automation, drug discovery</li>
                    <li><strong>Workforce Impact:</strong> Enhanced diagnostic accuracy, reduced administrative burden, new roles in AI-assisted care coordination</li>
                    <li><strong>Skills Needed:</strong> Clinical AI literacy, data interpretation, human-AI collaboration in patient care, ethical decision-making</li>
                    <li><strong>Challenges:</strong> Regulatory complexity, liability concerns, integration with existing workflows, maintaining human touch</li>
                    <li><strong>Opportunities:</strong> Improved patient outcomes, reduced burnout, expanded access to care, personalized medicine</li>
                </ul>
            </div>
            
            <h4 class="text-xl font-semibold mb-3 mt-6">Financial Services:</h4>
            <div class="bg-green-50 p-4 rounded-lg mb-4">
                <p class="font-semibold mb-2">AI Adoption Rate: 78% | Workforce Readiness: 7.3/10</p>
                <ul class="text-sm space-y-2">
                    <li><strong>Primary Applications:</strong> Fraud detection, algorithmic trading, risk assessment, customer service automation, personalized financial advice</li>
                    <li><strong>Workforce Impact:</strong> Significant automation of routine analysis, shift toward complex advisory roles, new quantitative analyst positions</li>
                    <li><strong>Skills Needed:</strong> Advanced data analytics, machine learning model interpretation, regulatory compliance, algorithmic accountability</li>
                    <li><strong>Challenges:</strong> Algorithmic bias in lending, explainability requirements, cybersecurity, maintaining customer trust</li>
                    <li><strong>Opportunities:</strong> Enhanced risk management, democratized financial services, real-time fraud prevention, improved customer experience</li>
                </ul>
            </div>
            
            <h4 class="text-xl font-semibold mb-3 mt-6">Manufacturing:</h4>
            <div class="bg-yellow-50 p-4 rounded-lg mb-4">
                <p class="font-semibold mb-2">AI Adoption Rate: 71% | Workforce Readiness: 5.2/10</p>
                <ul class="text-sm space-y-2">
                    <li><strong>Primary Applications:</strong> Predictive maintenance, quality control, supply chain optimization, robotics coordination, production planning</li>
                    <li><strong>Workforce Impact:</strong> Transition from manual operation to system oversight, reduced physical labor, increased technical complexity</li>
                    <li><strong>Skills Needed:</strong> Industrial AI systems operation, data-driven troubleshooting, human-robot collaboration, systems thinking</li>
                    <li><strong>Challenges:</strong> Significant skill gaps in existing workforce, union concerns, capital investment requirements, legacy system integration</li>
                    <li><strong>Opportunities:</strong> Enhanced safety, improved efficiency, reshoring potential, higher-value job creation, competitive advantage</li>
                </ul>
            </div>
            
            <h4 class="text-xl font-semibold mb-3 mt-6">Professional Services (Legal, Consulting, Accounting):</h4>
            <div class="bg-purple-50 p-4 rounded-lg mb-4">
                <p class="font-semibold mb-2">AI Adoption Rate: 58% | Workforce Readiness: 6.8/10</p>
                <ul class="text-sm space-y-2">
                    <li><strong>Primary Applications:</strong> Document review, legal research, contract analysis, tax preparation, audit automation, market research</li>
                    <li><strong>Workforce Impact:</strong> Reduced junior-level positions, evolution of billable hour model, emphasis on strategic advisory</li>
                    <li><strong>Skills Needed:</strong> AI-assisted research, prompt engineering for generative AI, critical evaluation of AI outputs, client education</li>
                    <li><strong>Challenges:</strong> Professional liability, confidentiality concerns, client acceptance, business model disruption</li>
                    <li><strong>Opportunities:</strong> Increased accessibility of services, focus on high-value advisory, improved accuracy, cost reduction</li>
                </ul>
            </div>
            
            <h4 class="text-xl font-semibold mb-3 mt-6">Retail and E-Commerce:</h4>
            <div class="bg-pink-50 p-4 rounded-lg mb-4">
                <p class="font-semibold mb-2">AI Adoption Rate: 65% | Workforce Readiness: 4.7/10</p>
                <ul class="text-sm space-y-2">
                    <li><strong>Primary Applications:</strong> Personalized recommendations, inventory optimization, dynamic pricing, customer service chatbots, demand forecasting</li>
                    <li><strong>Workforce Impact:</strong> Automation of customer service and warehouse operations, new roles in AI system management and customer experience design</li>
                    <li><strong>Skills Needed:</strong> Data literacy, customer analytics, omnichannel coordination, AI-enhanced customer service</li>
                    <li><strong>Challenges:</strong> High workforce turnover, low baseline skills, limited training investment, part-time employment prevalence</li>
                    <li><strong>Opportunities:</strong> Enhanced customer experience, operational efficiency, inventory optimization, competitive differentiation</li>
                </ul>
            </div>
        `
    },
    readiness3: {
        title: 'Skills Gap Analysis and Development Pathways',
        content: `
            <h3 class="text-2xl font-bold mb-4">Comprehensive Skills Gap Assessment</h3>
            <p class="mb-4">Detailed analysis of the competency gaps between current workforce capabilities and AI-era requirements, with evidence-based development pathways.</p>
            
            <h4 class="text-xl font-semibold mb-3 mt-6">Critical Skills Gaps by Category:</h4>
            
            <div class="mb-6">
                <h5 class="font-semibold text-lg mb-3">1. Technical AI Competencies</h5>
                <div class="space-y-3">
                    <div class="bg-red-50 border-l-4 border-red-500 p-3">
                        <p class="font-semibold">Data Literacy (Gap: 67% of workforce)</p>
                        <p class="text-sm text-gray-700">Ability to read, interpret, and communicate with data. Critical for AI-enabled decision-making.</p>
                        <p class="text-sm mt-2"><strong>Development Path:</strong> 40-80 hours foundational training, practical projects, ongoing application</p>
                    </div>
                    <div class="bg-red-50 border-l-4 border-red-500 p-3">
                        <p class="font-semibold">AI Tool Proficiency (Gap: 71% of workforce)</p>
                        <p class="text-sm text-gray-700">Practical ability to use AI-powered tools effectively in professional contexts.</p>
                        <p class="text-sm mt-2"><strong>Development Path:</strong> 20-40 hours tool-specific training, use case development, peer learning</p>
                    </div>
                    <div class="bg-orange-50 border-l-4 border-orange-500 p-3">
                        <p class="font-semibold">Basic Programming Understanding (Gap: 78% of workforce)</p>
                        <p class="text-sm text-gray-700">Fundamental understanding of how software and algorithms work, not necessarily coding ability.</p>
                        <p class="text-sm mt-2"><strong>Development Path:</strong> 30-60 hours conceptual learning, optional hands-on coding practice</p>
                    </div>
                </div>
            </div>
            
            <div class="mb-6">
                <h5 class="font-semibold text-lg mb-3">2. Cognitive and Analytical Skills</h5>
                <div class="space-y-3">
                    <div class="bg-yellow-50 border-l-4 border-yellow-500 p-3">
                        <p class="font-semibold">Critical AI Evaluation (Gap: 82% of workforce)</p>
                        <p class="text-sm text-gray-700">Ability to assess AI outputs for accuracy, bias, and appropriateness.</p>
                        <p class="text-sm mt-2"><strong>Development Path:</strong> 25-50 hours training in evaluation frameworks, case studies, practice scenarios</p>
                    </div>
                    <div class="bg-yellow-50 border-l-4 border-yellow-500 p-3">
                        <p class="font-semibold">Complex Problem-Solving (Gap: 54% of workforce)</p>
                        <p class="text-sm text-gray-700">Ability to tackle novel, ill-defined problems that AI cannot fully address.</p>
                        <p class="text-sm mt-2"><strong>Development Path:</strong> 60-120 hours problem-solving frameworks, real-world projects, mentorship</p>
                    </div>
                    <div class="bg-yellow-50 border-l-4 border-yellow-500 p-3">
                        <p class="font-semibold">Systems Thinking (Gap: 69% of workforce)</p>
                        <p class="text-sm text-gray-700">Understanding interconnections, feedback loops, and unintended consequences in complex systems.</p>
                        <p class="text-sm mt-2"><strong>Development Path:</strong> 40-80 hours conceptual learning, system mapping exercises, case analysis</p>
                    </div>
                </div>
            </div>
            
            <div class="mb-6">
                <h5 class="font-semibold text-lg mb-3">3. Human-Centric Skills</h5>
                <div class="space-y-3">
                    <div class="bg-green-50 border-l-4 border-green-500 p-3">
                        <p class="font-semibold">Emotional Intelligence (Gap: 43% of workforce)</p>
                        <p class="text-sm text-gray-700">Self-awareness, empathy, and relationship management in increasingly AI-mediated environments.</p>
                        <p class="text-sm mt-2"><strong>Development Path:</strong> 30-60 hours training, coaching, feedback, ongoing practice</p>
                    </div>
                    <div class="bg-green-50 border-l-4 border-green-500 p-3">
                        <p class="font-semibold">Adaptive Communication (Gap: 51% of workforce)</p>
                        <p class="text-sm text-gray-700">Ability to communicate effectively across human and AI systems, translating between technical and non-technical contexts.</p>
                        <p class="text-sm mt-2"><strong>Development Path:</strong> 25-50 hours communication training, presentation practice, cross-functional projects</p>
                    </div>
                    <div class="bg-green-50 border-l-4 border-green-500 p-3">
                        <p class="font-semibold">Ethical Reasoning (Gap: 76% of workforce)</p>
                        <p class="text-sm text-gray-700">Ability to identify and navigate ethical dilemmas in AI-enabled work contexts.</p>
                        <p class="text-sm mt-2"><strong>Development Path:</strong> 20-40 hours ethics training, case studies, ethical framework application</p>
                    </div>
                </div>
            </div>
            
            <h4 class="text-xl font-semibold mb-3 mt-6">Integrated Development Pathways:</h4>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div class="bg-blue-50 p-4 rounded-lg">
                    <h5 class="font-semibold mb-2">Foundational Path (3-6 months)</h5>
                    <p class="text-sm mb-2">For workers with minimal AI exposure</p>
                    <ul class="text-sm space-y-1">
                        <li>• Digital literacy basics</li>
                        <li>• Introduction to AI concepts</li>
                        <li>• Basic data interpretation</li>
                        <li>• AI tool experimentation</li>
                        <li>• Ethical awareness</li>
                    </ul>
                    <p class="text-xs mt-2 text-gray-600">Total: 80-120 hours</p>
                </div>
                <div class="bg-purple-50 p-4 rounded-lg">
                    <h5 class="font-semibold mb-2">Intermediate Path (6-12 months)</h5>
                    <p class="text-sm mb-2">For workers with basic digital skills</p>
                    <ul class="text-sm space-y-1">
                        <li>• Advanced AI tool proficiency</li>
                        <li>• Data analysis skills</li>
                        <li>• Critical evaluation frameworks</li>
                        <li>• Domain-specific applications</li>
                        <li>• Project-based learning</li>
                    </ul>
                    <p class="text-xs mt-2 text-gray-600">Total: 150-250 hours</p>
                </div>
                <div class="bg-green-50 p-4 rounded-lg">
                    <h5 class="font-semibold mb-2">Advanced Path (12-24 months)</h5>
                    <p class="text-sm mb-2">For workers in AI-intensive roles</p>
                    <ul class="text-sm space-y-1">
                        <li>• AI system design principles</li>
                        <li>• Advanced analytics</li>
                        <li>• Strategic AI implementation</li>
                        <li>• Leadership in AI transformation</li>
                        <li>• Innovation and R&D</li>
                    </ul>
                    <p class="text-xs mt-2 text-gray-600">Total: 300-500 hours</p>
                </div>
            </div>
        `
    },
    readiness4: {
        title: 'Geographic Disparities in AI Readiness',
        content: `
            <h3 class="text-2xl font-bold mb-4">Regional Variations in Workforce Preparedness</h3>
            <p class="mb-4">Analysis reveals significant geographic disparities in AI readiness, driven by differences in industry composition, educational infrastructure, technology access, and policy environments.</p>
            
            <h4 class="text-xl font-semibold mb-3 mt-6">Regional Readiness Profiles:</h4>
            
            <div class="space-y-4 mb-6">
                <div class="bg-green-50 border-l-4 border-green-500 p-4">
                    <h5 class="font-semibold text-lg">High-Tech Hubs (Readiness: 7.5-8.2/10)</h5>
                    <p class="text-sm mb-2"><strong>Regions:</strong> San Francisco Bay Area, Seattle, Boston, Austin, Research Triangle (NC)</p>
                    <p class="text-sm mb-2"><strong>Characteristics:</strong></p>
                    <ul class="text-sm space-y-1 ml-4">
                        <li>• High concentration of tech companies and AI startups</li>
                        <li>• Strong university-industry partnerships</li>
                        <li>• Abundant training resources and learning opportunities</li>
                        <li>• High baseline education levels (>45% bachelor's degree or higher)</li>
                        <li>• Robust digital infrastructure and broadband access (>95%)</li>
                    </ul>
                    <p class="text-sm mt-2"><strong>Challenges:</strong> High cost of living, talent competition, gentrification concerns</p>
                </div>
                
                <div class="bg-blue-50 border-l-4 border-blue-500 p-4">
                    <h5 class="font-semibold text-lg">Emerging Tech Centers (Readiness: 6.0-7.0/10)</h5>
                    <p class="text-sm mb-2"><strong>Regions:</strong> Denver, Nashville, Phoenix, Salt Lake City, Portland, Pittsburgh</p>
                    <p class="text-sm mb-2"><strong>Characteristics:</strong></p>
                    <ul class="text-sm space-y-1 ml-4">
                        <li>• Growing tech sectors with increasing AI adoption</li>
                        <li>• Developing educational programs and training initiatives</li>
                        <li>• Moderate baseline education levels (30-40% bachelor's or higher)</li>
                        <li>• Good but not universal broadband access (85-90%)</li>
                        <li>• Active efforts to attract tech talent and companies</li>
                    </ul>
                    <p class="text-sm mt-2"><strong>Opportunities:</strong> Rapid growth potential, lower costs, quality of life advantages</p>
                </div>
                
                <div class="bg-yellow-50 border-l-4 border-yellow-500 p-4">
                    <h5 class="font-semibold text-lg">Traditional Industrial Centers (Readiness: 4.5-5.5/10)</h5>
                    <p class="text-sm mb-2"><strong>Regions:</strong> Detroit, Cleveland, Buffalo, Milwaukee, St. Louis</p>
                    <p class="text-sm mb-2"><strong>Characteristics:</strong></p>
                    <ul class="text-sm space-y-1 ml-4">
                        <li>• Legacy manufacturing base undergoing transformation</li>
                        <li>• Mixed education levels with skills mismatches</li>
                        <li>• Variable broadband access (70-85%)</li>
                        <li>• Workforce accustomed to traditional employment models</li>
                        <li>• Economic challenges limiting training investment</li>
                    </ul>
                    <p class="text-sm mt-2"><strong>Priorities:</strong> Reskilling programs, manufacturing AI integration, community college partnerships</p>
                </div>
                
                <div class="bg-orange-50 border-l-4 border-orange-500 p-4">
                    <h5 class="font-semibold text-lg">Rural and Small-Town America (Readiness: 3.2-4.5/10)</h5>
                    <p class="text-sm mb-2"><strong>Regions:</strong> Rural areas across Midwest, South, Mountain West</p>
                    <p class="text-sm mb-2"><strong>Characteristics:</strong></p>
                    <ul class="text-sm space-y-1 ml-4">
                        <li>• Limited access to high-speed internet (50-70% coverage)</li>
                        <li>• Lower baseline education levels (15-25% bachelor's or higher)</li>
                        <li>• Minimal local AI adoption or tech sector presence</li>
                        <li>• Limited training infrastructure and resources</li>
                        <li>• Brain drain to urban centers</li>
                    </ul>
                    <p class="text-sm mt-2"><strong>Critical Needs:</strong> Broadband expansion, remote learning access, mobile training units, targeted support</p>
                </div>
            </div>
            
            <h4 class="text-xl font-semibold mb-3 mt-6">State-Level Policy Approaches:</h4>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div class="bg-purple-50 p-4 rounded">
                    <h5 class="font-semibold mb-2">Leading States</h5>
                    <ul class="text-sm space-y-2">
                        <li><strong>California:</strong> $100M+ AI workforce initiatives, university partnerships, industry collaboration</li>
                        <li><strong>Massachusetts:</strong> AI education mandates, workforce development boards, innovation hubs</li>
                        <li><strong>Washington:</strong> Tech sector partnerships, apprenticeship programs, community college integration</li>
                        <li><strong>Texas:</strong> STEM education investment, industry-led training, regional innovation centers</li>
                    </ul>
                </div>
                <div class="bg-gray-100 p-4 rounded">
                    <h5 class="font-semibold mb-2">Emerging Efforts</h5>
                    <ul class="text-sm space-y-2">
                        <li><strong>Ohio:</strong> Manufacturing AI transformation programs, community college reskilling</li>
                        <li><strong>North Carolina:</strong> Research Triangle leverage, workforce development grants</li>
                        <li><strong>Colorado:</strong> Rural broadband expansion, remote learning initiatives</li>
                        <li><strong>Georgia:</strong> Tech talent pipeline development, university-industry partnerships</li>
                    </ul>
                </div>
            </div>
            
            <h4 class="text-xl font-semibold mb-3 mt-6">Addressing Geographic Disparities:</h4>
            <div class="bg-gradient-to-r from-blue-50 to-purple-50 p-4 rounded-lg">
                <ul class="space-y-2 text-sm">
                    <li><strong>Infrastructure Investment:</strong> Universal broadband access as foundational requirement ($65B federal investment needed)</li>
                    <li><strong>Distributed Learning:</strong> Remote training programs, mobile learning labs, online certification pathways</li>
                    <li><strong>Regional Partnerships:</strong> Hub-and-spoke models connecting rural areas to urban tech centers</li>
                    <li><strong>Targeted Incentives:</strong> Tax credits for companies providing training in underserved areas</li>
                    <li><strong>Community Anchors:</strong> Libraries, community colleges as AI literacy and training centers</li>
                    <li><strong>Place-Based Strategies:</strong> Tailored approaches recognizing unique regional assets and challenges</li>
                </ul>
            </div>
        `
    },
    literacy1: {
        title: 'Technical Competencies Framework',
        content: `
            <h3 class="text-2xl font-bold mb-4">Technical AI Literacy Competencies</h3>
            <p class="mb-4">Technical AI literacy encompasses the foundational and applied knowledge required to understand, use, and critically evaluate AI technologies in professional contexts.</p>
            
            <h4 class="text-xl font-semibold mb-3 mt-6">Core Technical Competencies:</h4>
            
            <div class="space-y-4 mb-6">
                <div class="bg-blue-50 p-4 rounded-lg">
                    <h5 class="font-semibold text-lg mb-2">1. Understanding AI Systems and Algorithms</h5>
                    <p class="text-sm mb-3">Conceptual understanding of how AI works without necessarily requiring programming expertise.</p>
                    <div class="ml-4 space-y-2 text-sm">
                        <div>
                            <p class="font-semibold">Foundational Level:</p>
                            <ul class="list-disc ml-6">
                                <li>Distinguish between narrow AI and general AI</li>
                                <li>Understand machine learning vs. rule-based systems</li>
                                <li>Recognize common AI applications (NLP, computer vision, recommendation systems)</li>
                                <li>Grasp basic concepts: training data, models, predictions, feedback loops</li>
                            </ul>
                        </div>
                        <div>
                            <p class="font-semibold">Intermediate Level:</p>
                            <ul class="list-disc ml-6">
                                <li>Understand supervised vs. unsupervised learning</li>
                                <li>Recognize different AI architectures and their applications</li>
                                <li>Comprehend model training, validation, and testing processes</li>
                                <li>Understand generative AI and large language models</li>
                            </ul>
                        </div>
                        <div>
                            <p class="font-semibold">Advanced Level:</p>
                            <ul class="list-disc ml-6">
                                <li>Understand neural networks and deep learning principles</li>
                                <li>Grasp reinforcement learning and transfer learning</li>
                                <li>Comprehend model optimization and hyperparameter tuning</li>
                                <li>Understand emerging AI architectures and research directions</li>
                            </ul>
                        </div>
                    </div>
                </div>
                
                <div class="bg-green-50 p-4 rounded-lg">
                    <h5 class="font-semibold text-lg mb-2">2. Data Literacy and Interpretation</h5>
                    <p class="text-sm mb-3">Ability to work with data as the foundation of AI systems.</p>
                    <div class="ml-4 space-y-2 text-sm">
                        <div>
                            <p class="font-semibold">Foundational Level:</p>
                            <ul class="list-disc ml-6">
                                <li>Read and interpret basic charts, graphs, and tables</li>
                                <li>Understand descriptive statistics (mean, median, mode, variance)</li>
                                <li>Recognize data quality issues and missing data</li>
                                <li>Understand the relationship between data and AI outputs</li>
                            </ul>
                        </div>
                        <div>
                            <p class="font-semibold">Intermediate Level:</p>
                            <ul class="list-disc ml-6">
                                <li>Perform data cleaning and preprocessing</li>
                                <li>Understand data types, structures, and formats</li>
                                <li>Recognize patterns, trends, and anomalies in data</li>
                                <li>Understand sampling, bias, and representativeness</li>
                            </ul>
                        </div>
                        <div>
                            <p class="font-semibold">Advanced Level:</p>
                            <ul class="list-disc ml-6">
                                <li>Conduct exploratory data analysis</li>
                                <li>Understand feature engineering and selection</li>
                                <li>Work with structured and unstructured data</li>
                                <li>Understand data governance and privacy implications</li>
                            </ul>
                        </div>
                    </div>
                </div>
                
                <div class="bg-purple-50 p-4 rounded-lg">
                    <h5 class="font-semibold text-lg mb-2">3. Basic Programming and Automation</h5>
                    <p class="text-sm mb-3">Understanding of computational thinking and automation principles.</p>
                    <div class="ml-4 space-y-2 text-sm">
                        <div>
                            <p class="font-semibold">Foundational Level:</p>
                            <ul class="list-disc ml-6">
                                <li>Understand basic programming concepts (variables, loops, conditions)</li>
                                <li>Recognize opportunities for automation in workflows</li>
                                <li>Use no-code/low-code automation tools</li>
                                <li>Understand APIs and system integration concepts</li>
                            </ul>
                        </div>
                        <div>
                            <p class="font-semibold">Intermediate Level:</p>
                            <ul class="list-disc ml-6">
                                <li>Write simple scripts for task automation</li>
                                <li>Understand software development lifecycle basics</li>
                                <li>Use version control and collaboration tools</li>
                                <li>Integrate AI tools into existing workflows</li>
                            </ul>
                        </div>
                        <div>
                            <p class="font-semibold">Advanced Level:</p>
                            <ul class="list-disc ml-6">
                                <li>Develop custom AI-powered applications</li>
                                <li>Implement machine learning pipelines</li>
                                <li>Optimize code for performance and scalability</li>
                                <li>Contribute to open-source AI projects</li>
                            </ul>
                        </div>
                    </div>
                </div>
                
                <div class="bg-yellow-50 p-4 rounded-lg">
                    <h5 class="font-semibold text-lg mb-2">4. AI Tool Utilization and Integration</h5>
                    <p class="text-sm mb-3">Practical ability to use AI-powered tools effectively in professional contexts.</p>
                    <div class="ml-4 space-y-2 text-sm">
                        <div>
                            <p class="font-semibold">Foundational Level:</p>
                            <ul class="list-disc ml-6">
                                <li>Use generative AI tools (ChatGPT, Claude, etc.) for basic tasks</li>
                                <li>Understand prompt engineering basics</li>
                                <li>Recognize appropriate use cases for AI tools</li>
                                <li>Verify and validate AI-generated outputs</li>
                            </ul>
                        </div>
                        <div>
                            <p class="font-semibold">Intermediate Level:</p>
                            <ul class="list-disc ml-6">
                                <li>Master advanced prompting techniques</li>
                                <li>Use domain-specific AI tools effectively</li>
                                <li>Integrate multiple AI tools into workflows</li>
                                <li>Customize AI tools for specific needs</li>
                            </ul>
                        </div>
                        <div>
                            <p class="font-semibold">Advanced Level:</p>
                            <ul class="list-disc ml-6">
                                <li>Fine-tune AI models for specific applications</li>
                                <li>Evaluate and select appropriate AI tools for organizational needs</li>
                                <li>Design AI-augmented workflows and processes</li>
                                <li>Lead AI tool implementation and change management</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            
            <h4 class="text-xl font-semibold mb-3 mt-6">Assessment and Certification:</h4>
            <div class="bg-gradient-to-r from-blue-50 to-purple-50 p-4 rounded-lg">
                <p class="text-sm mb-3">Emerging frameworks for assessing and certifying technical AI literacy:</p>
                <ul class="text-sm space-y-2">
                    <li><strong>Industry Certifications:</strong> Google AI, Microsoft AI-900, IBM AI Engineering</li>
                    <li><strong>Academic Credentials:</strong> University certificates, micro-credentials, specialized degrees</li>
                    <li><strong>Professional Assessments:</strong> LinkedIn Skills Assessments, CompTIA certifications</li>
                    <li><strong>Competency-Based Evaluation:</strong> Portfolio-based assessment, practical projects, peer review</li>
                </ul>
            </div>
        `
    },
    literacy2: {
        title: 'Critical and Ethical Dimensions of AI Literacy',
        content: `
            <h3 class="text-2xl font-bold mb-4">Critical Evaluation and Ethical AI Literacy</h3>
            <p class="mb-4">Beyond technical skills, AI literacy requires the ability to critically evaluate AI systems and navigate complex ethical considerations in their deployment and use.</p>
            
            <h4 class="text-xl font-semibold mb-3 mt-6">Critical Evaluation Competencies:</h4>
            
            <div class="space-y-4 mb-6">
                <div class="bg-red-50 p-4 rounded-lg">
                    <h5 class="font-semibold text-lg mb-2">1. Bias Detection and Mitigation</h5>
                    <p class="text-sm mb-3">Understanding how bias enters AI systems and strategies for identification and reduction.</p>
                    <div class="ml-4 space-y-2 text-sm">
                        <div>
                            <p class="font-semibold">Key Concepts:</p>
                            <ul class="list-disc ml-6">
                                <li><strong>Data Bias:</strong> Historical bias, sampling bias, measurement bias in training data</li>
                                <li><strong>Algorithmic Bias:</strong> How model design choices can amplify or create bias</li>
                                <li><strong>Deployment Bias:</strong> How context of use affects fairness and outcomes</li>
                                <li><strong>Feedback Loops:</strong> How biased outputs can reinforce and amplify initial biases</li>
                            </ul>
                        </div>
                        <div>
                            <p class="font-semibold">Practical Skills:</p>
                            <ul class="list-disc ml-6">
                                <li>Analyze training data for representativeness and balance</li>
                                <li>Recognize protected characteristics and potential discrimination</li>
                                <li>Test AI outputs across diverse demographic groups</li>
                                <li>Implement bias auditing and monitoring processes</li>
                                <li>Advocate for diverse development teams and perspectives</li>
                            </ul>
                        </div>
                        <div class="bg-white p-3 rounded mt-2">
                            <p class="font-semibold text-xs mb-1">Real-World Example:</p>
                            <p class="text-xs">Hiring algorithms trained on historical data may perpetuate gender or racial biases present in past hiring decisions. AI-literate professionals can identify these patterns, demand algorithmic transparency, and implement fairness constraints.</p>
                        </div>
                    </div>
                </div>
                
                <div class="bg-blue-50 p-4 rounded-lg">
                    <h5 class="font-semibold text-lg mb-2">2. Ethical Decision-Making Frameworks</h5>
                    <p class="text-sm mb-3">Structured approaches to navigating ethical dilemmas in AI deployment and use.</p>
                    <div class="ml-4 space-y-2 text-sm">
                        <div>
                            <p class="font-semibold">Core Ethical Principles:</p>
                            <ul class="list-disc ml-6">
                                <li><strong>Beneficence:</strong> AI should benefit individuals and society</li>
                                <li><strong>Non-maleficence:</strong> AI should not cause harm</li>
                                <li><strong>Autonomy:</strong> Preserve human agency and decision-making</li>
                                <li><strong>Justice:</strong> Ensure fair distribution of benefits and burdens</li>
                                <li><strong>Explicability:</strong> AI decisions should be understandable and explainable</li>
                            </ul>
                        </div>
                        <div>
                            <p class="font-semibold">Ethical Analysis Process:</p>
                            <ol class="list-decimal ml-6">
                                <li>Identify stakeholders and their interests</li>
                                <li>Analyze potential harms and benefits</li>
                                <li>Consider power dynamics and vulnerable populations</li>
                                <li>Evaluate alternatives and trade-offs</li>
                                <li>Apply ethical frameworks and principles</li>
                                <li>Document reasoning and seek diverse input</li>
                                <li>Implement monitoring and adjustment mechanisms</li>
                            </ol>
                        </div>
                        <div class="bg-white p-3 rounded mt-2">
                            <p class="font-semibold text-xs mb-1">Application Example:</p>
                            <p class="text-xs">When implementing AI-powered performance monitoring, consider employee privacy rights, psychological impacts of surveillance, power imbalances, and alternative approaches that balance productivity goals with worker dignity.</p>
                        </div>
                    </div>
                </div>
                
                <div class="bg-purple-50 p-4 rounded-lg">
                    <h5 class="font-semibold text-lg mb-2">3. Privacy and Security Awareness</h5>
                    <p class="text-sm mb-3">Understanding data privacy implications and security considerations in AI systems.</p>
                    <div class="ml-4 space-y-2 text-sm">
                        <div>
                            <p class="font-semibold">Privacy Considerations:</p>
                            <ul class="list-disc ml-6">
                                <li><strong>Data Collection:</strong> What data is collected, how, and with what consent?</li>
                                <li><strong>Data Usage:</strong> How is data used, shared, and retained?</li>
                                <li><strong>Re-identification Risks:</strong> Can anonymized data be de-anonymized?</li>
                                <li><strong>Inference Privacy:</strong> What can be inferred from seemingly innocuous data?</li>
                                <li><strong>Regulatory Compliance:</strong> GDPR, CCPA, and other privacy regulations</li>
                            </ul>
                        </div>
                        <div>
                            <p class="font-semibold">Security Dimensions:</p>
                            <ul class="list-disc ml-6">
                                <li>Adversarial attacks and model manipulation</li>
                                <li>Data poisoning and training data integrity</li>
                                <li>Model extraction and intellectual property theft</li>
                                <li>Prompt injection and jailbreaking vulnerabilities</li>
                                <li>Secure deployment and access control</li>
                            </ul>
                        </div>
                    </div>
                </div>
                
                <div class="bg-green-50 p-4 rounded-lg">
                    <h5 class="font-semibold text-lg mb-2">4. Transparency and Accountability</h5>
                    <p class="text-sm mb-3">Ensuring AI systems are understandable and that responsibility is clearly assigned.</p>
                    <div class="ml-4 space-y-2 text-sm">
                        <div>
                            <p class="font-semibold">Transparency Requirements:</p>
                            <ul class="list-disc ml-6">
                                <li><strong>Algorithmic Transparency:</strong> Disclosure of how AI systems work</li>
                                <li><strong>Data Transparency:</strong> Information about training data sources and characteristics</li>
                                <li><strong>Performance Transparency:</strong> Clear reporting of accuracy, error rates, and limitations</li>
                                <li><strong>Purpose Transparency:</strong> Explicit communication of AI system objectives</li>
                            </ul>
                        </div>
                        <div>
                            <p class="font-semibold">Accountability Mechanisms:</p>
                            <ul class="list-disc ml-6">
                                <li>Clear assignment of responsibility for AI decisions</li>
                                <li>Audit trails and decision logging</li>
                                <li>Redress mechanisms for those affected by AI decisions</li>
                                <li>Regular algorithmic audits and impact assessments</li>
                                <li>Governance structures and oversight bodies</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            
            <h4 class="text-xl font-semibold mb-3 mt-6">Organizational Implementation:</h4>
            <div class="bg-gradient-to-r from-purple-50 to-pink-50 p-4 rounded-lg">
                <p class="text-sm mb-3">Embedding ethical AI literacy in organizational practice:</p>
                <ul class="text-sm space-y-2">
                    <li><strong>Ethics Boards:</strong> Cross-functional teams to review AI initiatives</li>
                    <li><strong>Impact Assessments:</strong> Required evaluation of AI systems before deployment</li>
                    <li><strong>Training Programs:</strong> Mandatory ethics training for all AI stakeholders</li>
                    <li><strong>Reporting Mechanisms:</strong> Channels for raising ethical concerns</li>
                    <li><strong>External Audits:</strong> Independent review of AI systems and practices</li>
                    <li><strong>Continuous Monitoring:</strong> Ongoing evaluation of AI impacts and outcomes</li>
                </ul>
            </div>
        `
    },
    literacy3: {
        title: 'Human-AI Collaboration Competencies',
        content: `
            <h3 class="text-2xl font-bold mb-4">Effective Human-AI Collaboration</h3>
            <p class="mb-4">AI literacy includes understanding how to work effectively alongside AI systems, leveraging their strengths while compensating for their limitations through uniquely human capabilities.</p>
            
            <h4 class="text-xl font-semibold mb-3 mt-6">Collaboration Framework:</h4>
            
            <div class="space-y-4 mb-6">
                <div class="bg-blue-50 p-4 rounded-lg">
                    <h5 class="font-semibold text-lg mb-2">1. Effective AI Delegation Strategies</h5>
                    <p class="text-sm mb-3">Understanding which tasks to delegate to AI and which to retain as human responsibilities.</p>
                    <div class="ml-4 space-y-3 text-sm">
                        <div class="bg-white p-3 rounded">
                            <p class="font-semibold mb-2">Tasks Well-Suited for AI:</p>
                            <ul class="list-disc ml-6 space-y-1">
                                <li><strong>Pattern Recognition:</strong> Identifying trends in large datasets</li>
                                <li><strong>Routine Processing:</strong> Standardized data entry, classification, sorting</li>
                                <li><strong>Rapid Computation:</strong> Complex calculations, optimization problems</li>
                                <li><strong>Consistency:</strong> Tasks requiring uniform application of rules</li>
                                <li><strong>Scale:</strong> Operations requiring processing of massive volumes</li>
                                <li><strong>Speed:</strong> Time-sensitive analysis and response</li>
                            </ul>
                        </div>
                        <div class="bg-white p-3 rounded">
                            <p class="font-semibold mb-2">Tasks Better Suited for Humans:</p>
                            <ul class="list-disc ml-6 space-y-1">
                                <li><strong>Contextual Judgment:</strong> Nuanced decisions requiring deep context</li>
                                <li><strong>Creativity:</strong> Novel problem-solving and innovation</li>
                                <li><strong>Empathy:</strong> Emotionally sensitive interactions</li>
                                <li><strong>Ethics:</strong> Moral reasoning and value-based decisions</li>
                                <li><strong>Ambiguity:</strong> Situations with unclear parameters or goals</li>
                                <li><strong>Accountability:</strong> Decisions with significant consequences</li>
                            </ul>
                        </div>
                        <div class="bg-gradient-to-r from-purple-50 to-blue-50 p-3 rounded">
                            <p class="font-semibold mb-2">Optimal Collaboration Model:</p>
                            <p class="text-xs">AI handles data processing and pattern identification → Humans provide contextual interpretation and strategic direction → AI executes at scale → Humans monitor, validate, and adjust → Iterative refinement</p>
                        </div>
                    </div>
                </div>
                
                <div class="bg-green-50 p-4 rounded-lg">
                    <h5 class="font-semibold text-lg mb-2">2. Augmentation vs. Automation Understanding</h5>
                    <p class="text-sm mb-3">Distinguishing between AI that replaces human work and AI that enhances human capabilities.</p>
                    <div class="ml-4 space-y-3 text-sm">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div class="bg-white p-3 rounded">
                                <p class="font-semibold mb-2 text-orange-600">Automation Approach</p>
                                <p class="text-xs mb-2"><em>AI replaces human tasks</em></p>
                                <ul class="list-disc ml-6 space-y-1 text-xs">
                                    <li>Eliminates repetitive work</li>
                                    <li>Reduces labor costs</li>
                                    <li>May displace workers</li>
                                    <li>Requires less human oversight</li>
                                    <li>Efficiency-focused</li>
                                </ul>
                                <p class="text-xs mt-2 font-semibold">Example:</p>
                                <p class="text-xs">Automated customer service chatbots completely handling routine inquiries without human involvement</p>
                            </div>
                            <div class="bg-white p-3 rounded">
                                <p class="font-semibold mb-2 text-green-600">Augmentation Approach</p>
                                <p class="text-xs mb-2"><em>AI enhances human capabilities</em></p>
                                <ul class="list-disc ml-6 space-y-1 text-xs">
                                    <li>Amplifies human expertise</li>
                                    <li>Improves decision quality</li>
                                    <li>Transforms and upskills roles</li>
                                    <li>Requires active human partnership</li>
                                    <li>Value-creation focused</li>
                                </ul>
                                <p class="text-xs mt-2 font-semibold">Example:</p>
                                <p class="text-xs">AI-assisted medical diagnosis providing analysis that doctors use alongside their expertise for better patient care</p>
                            </div>
                        </div>
                        <div class="bg-blue-100 p-3 rounded mt-3">
                            <p class="text-xs"><strong>Strategic Insight:</strong> Organizations and workers should prioritize augmentation approaches that create new value rather than purely cost-reduction automation. Research shows augmentation strategies lead to higher job satisfaction, better outcomes, and more sustainable AI integration.</p>
                        </div>
                    </div>
                </div>
                
                <div class="bg-yellow-50 p-4 rounded-lg">
                    <h5 class="font-semibold text-lg mb-2">3. Trust Calibration and Verification</h5>
                    <p class="text-sm mb-3">Developing appropriate trust in AI systems—neither over-trusting nor under-trusting.</p>
                    <div class="ml-4 space-y-3 text-sm">
                        <div class="bg-white p-3 rounded">
                            <p class="font-semibold mb-2">Trust Calibration Framework:</p>
                            <div class="space-y-2">
                                <div class="border-l-4 border-red-500 pl-3">
                                    <p class="font-semibold text-red-600">Under-Trust (Automation Disuse)</p>
                                    <p class="text-xs">Failing to use AI capabilities, missing efficiency gains and insights. Often due to unfamiliarity, negative experiences, or lack of understanding.</p>
                                </div>
                                <div class="border-l-4 border-green-500 pl-3">
                                    <p class="font-semibold text-green-600">Appropriate Trust (Optimal Use)</p>
                                    <p class="text-xs">Using AI when appropriate, with understanding of capabilities and limitations. Includes verification of outputs and contextual judgment.</p>
                                </div>
                                <div class="border-l-4 border-orange-500 pl-3">
                                    <p class="font-semibold text-orange-600">Over-Trust (Automation Bias)</p>
                                    <p class="text-xs">Uncritically accepting AI outputs, missing errors or inappropriate applications. Can lead to serious mistakes and abdication of responsibility.</p>
                                </div>
                            </div>
                        </div>
                        <div class="bg-white p-3 rounded">
                            <p class="font-semibold mb-2">Verification Practices:</p>
                            <ul class="list-disc ml-6 space-y-1 text-xs">
                                <li><strong>Spot Checking:</strong> Regularly verify AI outputs against ground truth</li>
                                <li><strong>Boundary Testing:</strong> Test AI performance on edge cases and unusual inputs</li>
                                <li><strong>Cross-Validation:</strong> Compare AI outputs with alternative methods or human judgment</li>
                                <li><strong>Confidence Awareness:</strong> Pay attention to AI confidence scores and uncertainty indicators</li>
                                <li><strong>Error Analysis:</strong> Study patterns in AI mistakes to understand failure modes</li>
                                <li><strong>Continuous Monitoring:</strong> Track AI performance over time, watching for drift or degradation</li>
                            </ul>
                        </div>
                    </div>
                </div>
                
                <div class="bg-purple-50 p-4 rounded-lg">
                    <h5 class="font-semibold text-lg mb-2">4. Complementary Skill Development</h5>
                    <p class="text-sm mb-3">Focusing on uniquely human skills that complement rather than compete with AI.</p>
                    <div class="ml-4 space-y-3 text-sm">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div class="bg-white p-3 rounded">
                                <p class="font-semibold mb-2">Cognitive Complements</p>
                                <ul class="list-disc ml-6 space-y-1 text-xs">
                                    <li>Strategic thinking and long-term planning</li>
                                    <li>Creative problem-solving and innovation</li>
                                    <li>Complex ethical reasoning</li>
                                    <li>Cross-domain knowledge integration</li>
                                    <li>Ambiguity tolerance and judgment under uncertainty</li>
                                </ul>
                            </div>
                            <div class="bg-white p-3 rounded">
                                <p class="font-semibold mb-2">Social-Emotional Complements</p>
                                <ul class="list-disc ml-6 space-y-1 text-xs">
                                    <li>Empathy and emotional intelligence</li>
                                    <li>Relationship building and networking</li>
                                    <li>Persuasion and influence</li>
                                    <li>Conflict resolution and negotiation</li>
                                    <li>Cultural sensitivity and adaptability</li>
                                </ul>
                            </div>
                        </div>
                        <div class="bg-gradient-to-r from-green-50 to-blue-50 p-3 rounded mt-3">
                            <p class="text-xs"><strong>Development Strategy:</strong> Rather than competing with AI on speed and scale, workers should develop skills in areas where humans excel: contextual understanding, ethical reasoning, creative synthesis, and interpersonal connection. This creates sustainable competitive advantage and career resilience.</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <h4 class="text-xl font-semibold mb-3 mt-6">Collaboration Best Practices:</h4>
            <div class="bg-gradient-to-r from-blue-50 to-purple-50 p-4 rounded-lg">
                <ul class="text-sm space-y-2">
                    <li><strong>Clear Role Definition:</strong> Explicitly define what AI handles vs. human responsibilities</li>
                    <li><strong>Transparent Communication:</strong> AI systems should clearly indicate their confidence and limitations</li>
                    <li><strong>Feedback Loops:</strong> Humans provide feedback to improve AI performance over time</li>
                    <li><strong>Graceful Handoffs:</strong> Smooth transitions when escalating from AI to human judgment</li>
                    <li><strong>Continuous Learning:</strong> Both humans and AI systems adapt based on collaboration experiences</li>
                    <li><strong>Shared Mental Models:</strong> Humans understand AI reasoning; AI systems model human preferences</li>
                </ul>
            </div>
        `
    },
    literacy4: {
        title: 'Adaptive Learning and Future-Ready Skills',
        content: `
            <h3 class="text-2xl font-bold mb-4">Adaptive Learning Competencies</h3>
            <p class="mb-4">In a rapidly evolving AI landscape, the ability to continuously learn, adapt, and integrate new technologies becomes a meta-competency as important as any specific skill.</p>
            
            <h4 class="text-xl font-semibold mb-3 mt-6">Core Adaptive Learning Capabilities:</h4>
            
            <div class="space-y-4 mb-6">
                <div class="bg-blue-50 p-4 rounded-lg">
                    <h5 class="font-semibold text-lg mb-2">1. Continuous Learning Mindset</h5>
                    <p class="text-sm mb-3">Cultivating attitudes and habits that support ongoing skill development in a changing technological landscape.</p>
                    <div class="ml-4 space-y-3 text-sm">
                        <div class="bg-white p-3 rounded">
                            <p class="font-semibold mb-2">Growth Mindset Characteristics:</p>
                            <ul class="list-disc ml-6 space-y-1">
                                <li><strong>Embracing Challenge:</strong> Viewing new AI technologies as opportunities rather than threats</li>
                                <li><strong>Persistence:</strong> Maintaining effort despite initial difficulties with new tools</li>
                                <li><strong>Learning from Failure:</strong> Treating mistakes as valuable feedback for improvement</li>
                                <li><strong>Seeking Feedback:</strong> Actively soliciting input on AI skill development</li>
                                <li><strong>Curiosity:</strong> Intrinsic motivation to explore and understand new technologies</li>
                            </ul>
                        </div>
                        <div class="bg-white p-3 rounded">
                            <p class="font-semibold mb-2">Learning Strategies:</p>
                            <ul class="list-disc ml-6 space-y-1">
                                <li><strong>Experiential Learning:</strong> Hands-on experimentation with AI tools and applications</li>
                                <li><strong>Reflective Practice:</strong> Regular reflection on what works, what doesn't, and why</li>
                                <li><strong>Peer Learning:</strong> Collaborative learning through communities of practice</li>
                                <li><strong>Just-in-Time Learning:</strong> Acquiring skills when needed for specific projects</li>
                                <li><strong>Structured Programs:</strong> Formal courses, certifications, and guided curricula</li>
                                <li><strong>Self-Directed Study:</strong> Independent exploration of topics of interest</li>
                            </ul>
                        </div>
                        <div class="bg-gradient-to-r from-purple-50 to-blue-50 p-3 rounded">
                            <p class="text-xs"><strong>Research Finding:</strong> Workers who dedicate 5+ hours per week to learning new skills are 47% more likely to feel prepared for AI workplace changes and report 32% higher job satisfaction (LinkedIn Workplace Learning Report, 2024).</p>
                        </div>
                    </div>
                </div>
                
                <div class="bg-green-50 p-4 rounded-lg">
                    <h5 class="font-semibold text-lg mb-2">2. Technology Adaptation Capabilities</h5>
                    <p class="text-sm mb-3">Ability to quickly learn and integrate new AI tools and technologies as they emerge.</p>
                    <div class="ml-4 space-y-3 text-sm">
                        <div class="bg-white p-3 rounded">
                            <p class="font-semibold mb-2">Rapid Adoption Framework:</p>
                            <ol class="list-decimal ml-6 space-y-2">
                                <li><strong>Awareness:</strong> Stay informed about emerging AI technologies and trends</li>
                                <li><strong>Evaluation:</strong> Assess relevance and potential impact on your work</li>
                                <li><strong>Experimentation:</strong> Test new tools in low-stakes environments</li>
                                <li><strong>Integration:</strong> Incorporate useful tools into workflows</li>
                                <li><strong>Optimization:</strong> Refine usage based on experience</li>
                                <li><strong>Sharing:</strong> Teach others and contribute to organizational learning</li>
                            </ol>
                        </div>
                        <div class="bg-white p-3 rounded">
                            <p class="font-semibold mb-2">Transfer Learning Skills:</p>
                            <p class="text-xs mb-2">Ability to apply knowledge from one context to new situations:</p>
                            <ul class="list-disc ml-6 space-y-1 text-xs">
                                <li>Recognize patterns across different AI tools and platforms</li>
                                <li>Apply problem-solving approaches from one domain to another</li>
                                <li>Understand underlying principles that transcend specific technologies</li>
                                <li>Quickly identify analogies between familiar and unfamiliar systems</li>
                            </ul>
                        </div>
                        <div class="grid grid-cols-2 gap-2 mt-3">
                            <div class="bg-blue-100 p-2 rounded text-center">
                                <p class="text-xs font-semibold">Traditional Learning</p>
                                <p class="text-xs">Months to years</p>
                            </div>
                            <div class="bg-green-100 p-2 rounded text-center">
                                <p class="text-xs font-semibold">Adaptive Learning</p>
                                <p class="text-xs">Days to weeks</p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="bg-yellow-50 p-4 rounded-lg">
                    <h5 class="font-semibold text-lg mb-2">3. Cross-Functional Skill Integration</h5>
                    <p class="text-sm mb-3">Combining domain expertise with AI literacy to create unique value.</p>
                    <div class="ml-4 space-y-3 text-sm">
                        <div class="bg-white p-3 rounded">
                            <p class="font-semibold mb-2">T-Shaped Skill Profile:</p>
                            <div class="space-y-2">
                                <div>
                                    <p class="font-semibold text-xs">Vertical Bar (Depth):</p>
                                    <p class="text-xs">Deep expertise in a specific domain (healthcare, finance, education, etc.)</p>
                                </div>
                                <div>
                                    <p class="font-semibold text-xs">Horizontal Bar (Breadth):</p>
                                    <p class="text-xs">Broad AI literacy enabling collaboration across functions and application of AI to domain problems</p>
                                </div>
                            </div>
                            <div class="bg-gradient-to-r from-blue-50 to-purple-50 p-2 rounded mt-2">
                                <p class="text-xs"><strong>Value Creation:</strong> The intersection of deep domain knowledge and AI literacy creates unique competitive advantage. Example: A physician with AI literacy can identify novel applications of AI in clinical practice that pure technologists might miss.</p>
                            </div>
                        </div>
                        <div class="bg-white p-3 rounded">
                            <p class="font-semibold mb-2">Integration Strategies:</p>
                            <ul class="list-disc ml-6 space-y-1 text-xs">
                                <li><strong>Problem-Framing:</strong> Use domain expertise to identify high-value AI applications</li>
                                <li><strong>Solution Design:</strong> Apply AI literacy to design appropriate technical approaches</li>
                                <li><strong>Implementation:</strong> Combine both to execute effectively</li>
                                <li><strong>Evaluation:</strong> Use domain knowledge to assess AI solution quality and impact</li>
                                <li><strong>Iteration:</strong> Continuously refine based on domain-specific feedback</li>
                            </ul>
                        </div>
                    </div>
                </div>
                
                <div class="bg-purple-50 p-4 rounded-lg">
                    <h5 class="font-semibold text-lg mb-2">4. Future-Oriented Competency Building</h5>
                    <p class="text-sm mb-3">Anticipating future skill needs and proactively developing capabilities.</p>
                    <div class="ml-4 space-y-3 text-sm">
                        <div class="bg-white p-3 rounded">
                            <p class="font-semibold mb-2">Emerging Skill Areas (2025-2030):</p>
                            <div class="space-y-2">
                                <div class="border-l-4 border-blue-500 pl-3">
                                    <p class="font-semibold text-xs">Multimodal AI Literacy</p>
                                    <p class="text-xs">Working with AI systems that integrate text, images, audio, and video</p>
                                </div>
                                <div class="border-l-4 border-green-500 pl-3">
                                    <p class="font-semibold text-xs">AI-Human Team Leadership</p>
                                    <p class="text-xs">Managing teams composed of both human and AI agents</p>
                                </div>
                                <div class="border-l-4 border-purple-500 pl-3">
                                    <p class="font-semibold text-xs">Synthetic Data Creation</p>
                                    <p class="text-xs">Generating training data for specialized AI applications</p>
                                </div>
                                <div class="border-l-4 border-yellow-500 pl-3">
                                    <p class="font-semibold text-xs">AI Governance & Policy</p>
                                    <p class="text-xs">Developing and implementing organizational AI governance frameworks</p>
                                </div>
                                <div class="border-l-4 border-red-500 pl-3">
                                    <p class="font-semibold text-xs">Explainable AI Interpretation</p>
                                    <p class="text-xs">Understanding and communicating AI decision-making processes</p>
                                </div>
                            </div>
                        </div>
                        <div class="bg-white p-3 rounded">
                            <p class="font-semibold mb-2">Proactive Development Approach:</p>
                            <ul class="list-disc ml-6 space-y-1 text-xs">
                                <li>Monitor industry trends and emerging technologies</li>
                                <li>Engage with professional communities and thought leaders</li>
                                <li>Experiment with beta and emerging AI tools</li>
                                <li>Develop adjacent skills that complement core expertise</li>
                                <li>Build a personal learning network for knowledge sharing</li>
                                <li>Create a skill development roadmap aligned with career goals</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            
            <h4 class="text-xl font-semibold mb-3 mt-6">Organizational Support for Adaptive Learning:</h4>
            <div class="bg-gradient-to-r from-blue-50 to-purple-50 p-4 rounded-lg mb-6">
                <p class="text-sm mb-3">How organizations can foster adaptive learning cultures:</p>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                    <div>
                        <p class="font-semibold mb-2">Structural Support:</p>
                        <ul class="list-disc ml-6 space-y-1 text-xs">
                            <li>Dedicated learning time (e.g., 20% time for skill development)</li>
                            <li>Learning budgets and resource access</li>
                            <li>Internal knowledge sharing platforms</li>
                            <li>Mentorship and coaching programs</li>
                            <li>Cross-functional project opportunities</li>
                        </ul>
                    </div>
                    <div>
                        <p class="font-semibold mb-2">Cultural Support:</p>
                        <ul class="list-disc ml-6 space-y-1 text-xs">
                            <li>Psychological safety for experimentation</li>
                            <li>Recognition of learning efforts</li>
                            <li>Leadership modeling of continuous learning</li>
                            <li>Celebration of skill development milestones</li>
                            <li>Integration of learning into performance metrics</li>
                        </ul>
                    </div>
                </div>
            </div>
            
            <div class="bg-green-50 p-4 rounded-lg">
                <p class="text-sm font-semibold mb-2">Key Insight: The Half-Life of Skills</p>
                <p class="text-sm">Research indicates that technical skills now have a half-life of approximately 2.5-5 years, meaning half of what you know becomes outdated in that timeframe. In AI-related domains, this half-life may be even shorter (18-36 months). This reality makes adaptive learning not just valuable, but essential for career sustainability.</p>
            </div>
        `
    },
    trend1: {
        title: '2024-2025: Rapid Acceleration Phase',
        content: `
            <h3 class="text-2xl font-bold mb-4">2024-2025: The Acceleration Phase</h3>
            <p class="mb-4">The current period represents a pivotal moment of rapid AI adoption and integration across industries, driven primarily by the maturation of generative AI technologies and increased accessibility of AI tools.</p>
            
            <h4 class="text-xl font-semibold mb-3 mt-6">Key Developments:</h4>
            
            <div class="space-y-4 mb-6">
                <div class="bg-blue-50 p-4 rounded-lg">
                    <h5 class="font-semibold mb-2">Generative AI Mainstreaming</h5>
                    <ul class="text-sm space-y-2">
                        <li><strong>Widespread Adoption:</strong> 65% of knowledge workers now use generative AI tools at least weekly (up from 12% in early 2023)</li>
                        <li><strong>Enterprise Integration:</strong> 78% of Fortune 500 companies have deployed generative AI in at least one business function</li>
                        <li><strong>Tool Proliferation:</strong> Over 500 enterprise-focused generative AI applications launched in 2024</li>
                        <li><strong>Productivity Gains:</strong> Early adopters report 25-40% time savings on specific tasks</li>
                    </ul>
                </div>
                
                <div class="bg-green-50 p-4 rounded-lg">
                    <h5 class="font-semibold mb-2">Workforce Response Patterns</h5>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mt-3">
                        <div class="bg-white p-3 rounded">
                            <p class="font-semibold text-sm mb-2">Early Adopters (25%)</p>
                            <ul class="text-xs space-y-1 list-disc ml-4">
                                <li>Actively experimenting with multiple AI tools</li>
                                <li>Developing new workflows and processes</li>
                                <li>Sharing knowledge with colleagues</li>
                                <li>Gaining competitive advantage</li>
                            </ul>
                        </div>
                        <div class="bg-white p-3 rounded">
                            <p class="font-semibold text-sm mb-2">Cautious Adopters (40%)</p>
                            <ul class="text-xs space-y-1 list-disc ml-4">
                                <li>Using AI for basic tasks</li>
                                <li>Waiting for organizational guidance</li>
                                <li>Concerned about accuracy and reliability</li>
                                <li>Seeking training and support</li>
                            </ul>
                        </div>
                        <div class="bg-white p-3 rounded">
                            <p class="font-semibold text-sm mb-2">Resisters (20%)</p>
                            <ul class="text-xs space-y-1 list-disc ml-4">
                                <li>Skeptical of AI capabilities</li>
                                <li>Concerned about job security</li>
                                <li>Lack access or training</li>
                                <li>Prefer traditional methods</li>
                            </ul>
                        </div>
                        <div class="bg-white p-3 rounded">
                            <p class="font-semibold text-sm mb-2">Unaware/No Access (15%)</p>
                            <ul class="text-xs space-y-1 list-disc ml-4">
                                <li>Limited technology exposure</li>
                                <li>Work in non-digital roles</li>
                                <li>Geographic or economic barriers</li>
                                <li>Urgent intervention needed</li>
                            </ul>
                        </div>
                    </div>
                </div>
                
                <div class="bg-yellow-50 p-4 rounded-lg">
                    <h5 class="font-semibold mb-2">Organizational Investment Trends</h5>
                    <div class="space-y-3">
                        <div>
                            <p class="text-sm font-semibold">AI Infrastructure Spending</p>
                            <p class="text-sm">US organizations investing $125B+ annually in AI infrastructure, tools, and services (2024)</p>
                            <div class="w-full bg-gray-200 rounded-full h-4 mt-2">
                                <div class="bg-purple-600 h-4 rounded-full" style="width: 85%">
                                    <span class="text-xs text-white pl-2">85% year-over-year growth</span>
                                </div>
                            </div>
                        </div>
                        <div>
                            <p class="text-sm font-semibold">Training and Reskilling</p>
                            <p class="text-sm">$18B invested in AI-related workforce training programs (2024)</p>
                            <div class="w-full bg-gray-200 rounded-full h-4 mt-2">
                                <div class="bg-blue-600 h-4 rounded-full" style="width: 65%">
                                    <span class="text-xs text-white pl-2">65% year-over-year growth</span>
                                </div>
                            </div>
                        </div>
                        <div>
                            <p class="text-sm font-semibold">AI Talent Acquisition</p>
                            <p class="text-sm">AI-related job postings up 125% from 2023; median salary premium of 35% over non-AI roles</p>
                        </div>
                    </div>
                </div>
                
                <div class="bg-purple-50 p-4 rounded-lg">
                    <h5 class="font-semibold mb-2">Sector-Specific Developments</h5>
                    <div class="space-y-2 text-sm">
                        <div class="border-l-4 border-blue-500 pl-3">
                            <p class="font-semibold">Technology & Software</p>
                            <p class="text-xs">AI-assisted coding tools (GitHub Copilot, etc.) used by 70% of developers; 30-50% productivity gains reported</p>
                        </div>
                        <div class="border-l-4 border-green-500 pl-3">
                            <p class="font-semibold">Healthcare</p>
                            <p class="text-xs">AI diagnostic tools deployed in 45% of major health systems; administrative automation reducing documentation time by 2-3 hours per clinician daily</p>
                        </div>
                        <div class="border-l-4 border-yellow-500 pl-3">
                            <p class="font-semibold">Financial Services</p>
                            <p class="text-xs">AI-powered fraud detection preventing $12B+ in losses; 60% of customer service interactions now AI-assisted</p>
                        </div>
                        <div class="border-l-4 border-red-500 pl-3">
                            <p class="font-semibold">Professional Services</p>
                            <p class="text-xs">Legal AI tools reducing document review time by 60-80%; consulting firms using AI for data analysis and insight generation</p>
                        </div>
                        <div class="border-l-4 border-purple-500 pl-3">
                            <p class="font-semibold">Manufacturing</p>
                            <p class="text-xs">Predictive maintenance AI reducing downtime by 30-40%; quality control automation improving defect detection by 25%</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <h4 class="text-xl font-semibold mb-3 mt-6">Emerging Challenges:</h4>
            <div class="bg-red-50 p-4 rounded-lg mb-6">
                <ul class="space-y-2 text-sm">
                    <li><strong>Skills Gap Widening:</strong> Pace of AI advancement outstripping workforce training capacity</li>
                    <li><strong>Regulatory Uncertainty:</strong> Lack of clear governance frameworks creating hesitation in some sectors</li>
                    <li><strong>Ethical Concerns:</strong> Issues of bias, privacy, and accountability becoming more visible</li>
                    <li><strong>Digital Divide:</strong> Disparities in AI access and literacy becoming more consequential</li>
                    <li><strong>Job Displacement Anxiety:</strong> Worker concerns about automation despite limited actual displacement to date</li>
                    <li><strong>Quality Control:</strong> Ensuring reliability and accuracy of AI outputs in high-stakes applications</li>
                </ul>
            </div>
            
            <h4 class="text-xl font-semibold mb-3 mt-6">Strategic Imperatives for 2024-2025:</h4>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div class="bg-gradient-to-br from-blue-50 to-purple-50 p-4 rounded-lg">
                    <p class="font-semibold mb-2">For Organizations:</p>
                    <ul class="text-sm space-y-1 list-disc ml-4">
                        <li>Develop clear AI adoption strategies</li>
                        <li>Invest heavily in workforce training</li>
                        <li>Establish AI governance frameworks</li>
                        <li>Create experimentation spaces</li>
                        <li>Measure and communicate ROI</li>
                    </ul>
                </div>
                <div class="bg-gradient-to-br from-green-50 to-blue-50 p-4 rounded-lg">
                    <p class="font-semibold mb-2">For Workers:</p>
                    <ul class="text-sm space-y-1 list-disc ml-4">
                        <li>Begin experimenting with AI tools</li>
                        <li>Pursue AI literacy training</li>
                        <li>Identify augmentation opportunities</li>
                        <li>Develop complementary skills</li>
                        <li>Build professional AI network</li>
                    </ul>
                </div>
            </div>
        `
    },
    trend2: {
        title: '2026-2028: Integration and Optimization',
        content: `
            <h3 class="text-2xl font-bold mb-4">2026-2028: Integration and Optimization Phase</h3>
            <p class="mb-4">As AI moves beyond initial adoption, the focus shifts to integration, optimization, and addressing second-order effects. This phase is characterized by maturation of practices, emergence of standards, and deeper organizational transformation.</p>
            
            <h4 class="text-xl font-semibold mb-3 mt-6">Projected Developments:</h4>
            
            <div class="space-y-4 mb-6">
                <div class="bg-blue-50 p-4 rounded-lg">
                    <h5 class="font-semibold mb-2">Embedded AI Workflows</h5>
                    <p class="text-sm mb-3">AI transitions from standalone tools to deeply integrated components of standard business processes.</p>
                    <ul class="text-sm space-y-2">
                        <li><strong>Process Redesign:</strong> Organizations fundamentally restructure workflows around AI capabilities rather than simply adding AI to existing processes</li>
                        <li><strong>Seamless Integration:</strong> AI becomes invisible infrastructure—embedded in every application and process without requiring separate interfaces</li>
                        <li><strong>Interoperability Standards:</strong> Emergence of standards enabling AI systems to work together across platforms and vendors</li>
                        <li><strong>Automated Orchestration:</strong> AI systems coordinate with each other with minimal human intervention for routine operations</li>
                    </ul>
                    <div class="bg-white p-3 rounded mt-3">
                        <p class="text-xs font-semibold mb-1">Example Scenario:</p>
                        <p class="text-xs">A marketing professional's workflow in 2027: AI monitors market trends and customer sentiment continuously → identifies opportunities → generates campaign concepts → produces initial creative assets → schedules distribution → monitors performance → adjusts strategy in real-time. Human role: strategic direction, creative vision, relationship management, ethical oversight.</p>
                    </div>
                </div>
                
                <div class="bg-green-50 p-4 rounded-lg">
                    <h5 class="font-semibold mb-2">Governance and Ethics Maturation</h5>
                    <p class="text-sm mb-3">Regulatory frameworks and organizational governance structures evolve to address AI challenges.</p>
                    <div class="space-y-3">
                        <div class="bg-white p-3 rounded">
                            <p class="font-semibold text-sm mb-2">Regulatory Landscape (Projected):</p>
                            <ul class="text-xs space-y-1 list-disc ml-4">
                                <li><strong>Federal AI Regulation:</strong> Comprehensive federal framework likely enacted by 2027, covering transparency, accountability, and safety requirements</li>
                                <li><strong>Sector-Specific Rules:</strong> Detailed regulations for high-stakes domains (healthcare, finance, education, criminal justice)</li>
                                <li><strong>Algorithmic Auditing Requirements:</strong> Mandatory third-party audits for AI systems in sensitive applications</li>
                                <li><strong>Liability Framework:</strong> Clear assignment of responsibility for AI-caused harms</li>
                                <li><strong>International Harmonization:</strong> Growing coordination between US, EU, and other jurisdictions</li>
                            </ul>
                        </div>
                        <div class="bg-white p-3 rounded">
                            <p class="font-semibold text-sm mb-2">Organizational Governance:</p>
                            <ul class="text-xs space-y-1 list-disc ml-4">
                                <li>Chief AI Ethics Officers become standard in large organizations</li>
                                <li>AI Ethics Boards with diverse stakeholder representation</li>
                                <li>Standardized AI impact assessment processes</li>
                                <li>Continuous monitoring and auditing systems</li>
                                <li>Transparent reporting of AI use and outcomes</li>
                            </ul>
                        </div>
                    </div>
                </div>
                
                <div class="bg-purple-50 p-4 rounded-lg">
                    <h5 class="font-semibold mb-2">Workforce Transformation Patterns</h5>
                    <p class="text-sm mb-3">Clearer patterns emerge regarding how AI reshapes work and employment.</p>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
                        <div class="bg-white p-3 rounded">
                            <p class="font-semibold text-sm mb-2 text-red-600">Declining Roles</p>
                            <ul class="text-xs space-y-1">
                                <li>Data entry specialists (-45%)</li>
                                <li>Basic bookkeeping (-38%)</li>
                                <li>Routine customer service (-35%)</li>
                                <li>Basic paralegal work (-32%)</li>
                                <li>Telemarketing (-55%)</li>
                            </ul>
                        </div>
                        <div class="bg-white p-3 rounded">
                            <p class="font-semibold text-sm mb-2 text-yellow-600">Transformed Roles</p>
                            <ul class="text-xs space-y-1">
                                <li>Financial analysts (+AI tools)</li>
                                <li>Healthcare diagnosticians</li>
                                <li>Software developers</li>
                                <li>Marketing professionals</li>
                                <li>HR specialists</li>
                            </ul>
                        </div>
                        <div class="bg-white p-3 rounded">
                            <p class="font-semibold text-sm mb-2 text-green-600">Emerging Roles</p>
                            <ul class="text-xs space-y-1">
                                <li>AI trainers (+120%)</li>
                                <li>Prompt engineers (+250%)</li>
                                <li>AI ethics specialists (+180%)</li>
                                <li>Human-AI interaction designers (+150%)</li>
                                <li>AI system auditors (+200%)</li>
                            </ul>
                        </div>
                    </div>
                    <div class="bg-blue-100 p-3 rounded mt-3">
                        <p class="text-xs"><strong>Net Employment Effect (2026-2028):</strong> Modest net job growth projected (+2-3% overall) as new roles and increased productivity offset displacement. However, significant transition challenges for displaced workers requiring comprehensive support systems.</p>
                    </div>
                </div>
                
                <div class="bg-yellow-50 p-4 rounded-lg">
                    <h5 class="font-semibold mb-2">Training and Education Evolution</h5>
                    <p class="text-sm mb-3">Educational systems adapt to prepare workers for AI-integrated workplaces.</p>
                    <div class="space-y-3">
                        <div class="bg-white p-3 rounded">
                            <p class="font-semibold text-sm mb-2">Higher Education Transformation:</p>
                            <ul class="text-xs space-y-1 list-disc ml-4">
                                <li>AI literacy integrated across all disciplines, not just technical programs</li>
                                <li>Shift from knowledge transmission to skill application and critical thinking</li>
                                <li>Emphasis on human-AI collaboration in all professional programs</li>
                                <li>Micro-credentials and stackable certificates gain parity with traditional degrees</li>
                                <li>Industry partnerships for real-world AI project experience</li>
                            </ul>
                        </div>
                        <div class="bg-white p-3 rounded">
                            <p class="font-semibold text-sm mb-2">Corporate Training Programs:</p>
                            <ul class="text-xs space-y-1 list-disc ml-4">
                                <li>Average of 40-60 hours annual AI-related training per employee</li>
                                <li>Personalized learning pathways based on role and skill level</li>
                                <li>Just-in-time training integrated into workflow</li>
                                <li>Peer learning and communities of practice</li>
                                <li>Certification requirements for AI-intensive roles</li>
                            </ul>
                        </div>
                        <div class="bg-white p-3 rounded">
                            <p class="font-semibold text-sm mb-2">Public Workforce Development:</p>
                            <ul class="text-xs space-y-1 list-disc ml-4">
                                <li>$50B+ federal investment in AI workforce programs (projected)</li>
                                <li>Community colleges as primary delivery mechanism</li>
                                <li>Targeted support for displaced workers and vulnerable populations</li>
                                <li>Regional AI training hubs in all 50 states</li>
                                <li>Income support during training transitions</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            
            <h4 class="text-xl font-semibold mb-3 mt-6">Key Challenges 2026-2028:</h4>
            <div class="bg-red-50 p-4 rounded-lg mb-6">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                    <div>
                        <p class="font-semibold mb-2">Systemic Challenges:</p>
                        <ul class="space-y-1 list-disc ml-4 text-xs">
                            <li>Managing large-scale workforce transitions</li>
                            <li>Addressing widening inequality and digital divide</li>
                            <li>Balancing innovation with safety and ethics</li>
                            <li>Maintaining human agency and meaningful work</li>
                            <li>Preventing AI-driven discrimination and bias</li>
                        </ul>
                    </div>
                    <div>
                        <p class="font-semibold mb-2">Organizational Challenges:</p>
                        <ul class="space-y-1 list-disc ml-4 text-xs">
                            <li>Change management at scale</li>
                            <li>Retaining talent in competitive market</li>
                            <li>Measuring AI ROI and impact</li>
                            <li>Ensuring cybersecurity and data protection</li>
                            <li>Maintaining organizational culture</li>
                        </ul>
                    </div>
                </div>
            </div>
            
            <h4 class="text-xl font-semibold mb-3 mt-6">Strategic Priorities:</h4>
            <div class="bg-gradient-to-r from-blue-50 to-purple-50 p-4 rounded-lg">
                <ul class="text-sm space-y-2">
                    <li><strong>Inclusive Transition:</strong> Ensure AI benefits are broadly shared and vulnerable workers are supported</li>
                    <li><strong>Ethical Leadership:</strong> Organizations must lead on responsible AI practices, not just comply with regulations</li>
                    <li><strong>Continuous Adaptation:</strong> Build organizational capacity for ongoing evolution as AI continues to advance</li>
                    <li><strong>Human-Centric Design:</strong> Keep human needs, values, and dignity at center of AI integration efforts</li>
                    <li><strong>Collaborative Governance:</strong> Multi-stakeholder approaches involving workers, employers, government, and civil society</li>
                </ul>
            </div>
        `
    },
    trend3: {
        title: '2029-2030: Mature AI Ecosystem',
        content: `
            <h3 class="text-2xl font-bold mb-4">2029-2030: Mature AI Ecosystem</h3>
            <p class="mb-4">By the end of the decade, AI integration reaches maturity with established practices, stable regulatory frameworks, and evolved workforce models. Human-AI collaboration becomes the norm rather than the exception.</p>
            
            <h4 class="text-xl font-semibold mb-3 mt-6">Projected Landscape:</h4>
            
            <div class="space-y-4 mb-6">
                <div class="bg-blue-50 p-4 rounded-lg">
                    <h5 class="font-semibold mb-2">Normalized Human-AI Collaboration</h5>
                    <p class="text-sm mb-3">AI becomes as ubiquitous and unremarkable as computers or internet connectivity today.</p>
                    <div class="space-y-3">
                        <div class="bg-white p-3 rounded">
                            <p class="font-semibold text-sm mb-2">Workplace Characteristics:</p>
                            <ul class="text-xs space-y-1 list-disc ml-4">
                                <li><strong>Universal AI Literacy:</strong> 85%+ of workforce has basic AI competencies; considered as fundamental as digital literacy in 2020s</li>
                                <li><strong>Seamless Integration:</strong> AI assistance available for virtually every professional task, activated naturally through voice, gesture, or intent</li>
                                <li><strong>Personalized AI Assistants:</strong> Workers have AI collaborators that understand their preferences, work style, and domain expertise</li>
                                <li><strong>Augmented Decision-Making:</strong> Major decisions routinely supported by AI analysis, with clear human accountability</li>
                                <li><strong>Reduced Cognitive Load:</strong> AI handles routine cognitive tasks, freeing humans for high-value creative and strategic work</li>
                            </ul>
                        </div>
                        <div class="bg-white p-3 rounded">
                            <p class="font-semibold text-sm mb-2">Evolved Work Models:</p>
                            <ul class="text-xs space-y-1 list-disc ml-4">
                                <li><strong>Hybrid Teams:</strong> Teams composed of humans and AI agents working in coordinated fashion</li>
                                <li><strong>Outcome-Based Work:</strong> Shift from time-based to outcome-based compensation as AI handles execution</li>
                                <li><strong>Expanded Capabilities:</strong> Individual workers can accomplish what previously required teams</li>
                                <li><strong>Continuous Learning:</strong> On-the-job learning supported by AI tutors and real-time skill development</li>
                                <li><strong>Flexible Specialization:</strong> Workers can pivot between specializations more easily with AI support</li>
                            </ul>
                        </div>
                    </div>
                </div>
                
                <div class="bg-green-50 p-4 rounded-lg">
                    <h5 class="font-semibold mb-2">New Job Categories and Roles</h5>
                    <p class="text-sm mb-3">Entirely new categories of work emerge from mature AI ecosystem.</p>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <div class="bg-white p-3 rounded">
                            <p class="font-semibold text-sm mb-2">AI-Enabled Professions:</p>
                            <ul class="text-xs space-y-1">
                                <li><strong>AI Orchestrators:</strong> Design and manage complex AI system interactions</li>
                                <li><strong>Synthetic Data Architects:</strong> Create training datasets for specialized AI applications</li>
                                <li><strong>AI Psychology Specialists:</strong> Understand and optimize human-AI interaction patterns</li>
                                <li><strong>Algorithmic Accountability Auditors:</strong> Independent verification of AI system fairness and safety</li>
                                <li><strong>AI-Human Translation Specialists:</strong> Bridge communication between technical and non-technical stakeholders</li>
                            </ul>
                        </div>
                        <div class="bg-white p-3 rounded">
                            <p class="font-semibold text-sm mb-2">Augmented Traditional Roles:</p>
                            <ul class="text-xs space-y-1">
                                <li><strong>Physicians:</strong> Focus on patient relationships and complex cases; AI handles diagnostics and treatment planning</li>
                                <li><strong>Teachers:</strong> Personalized mentoring and socio-emotional development; AI delivers customized content</li>
                                <li><strong>Lawyers:</strong> Strategic counsel and negotiation; AI handles research and document work</li>
                                <li><strong>Engineers:</strong> Creative design and innovation; AI handles analysis and optimization</li>
                                <li><strong>Managers:</strong> Leadership and culture-building; AI handles coordination and reporting</li>
                            </ul>
                        </div>
                    </div>
                    <div class="bg-gradient-to-r from-blue-50 to-purple-50 p-3 rounded mt-3">
                        <p class="text-xs"><strong>Labor Market Projection:</strong> By 2030, an estimated 15-20% of jobs will be in categories that didn't exist in 2020. Simultaneously, 60-70% of existing jobs will be fundamentally transformed in their task composition and required competencies.</p>
                    </div>
                </div>
                
                <div class="bg-purple-50 p-4 rounded-lg">
                    <h5 class="font-semibold mb-2">Economic and Social Implications</h5>
                    <p class="text-sm mb-3">Broader societal effects of mature AI integration in the workplace.</p>
                    <div class="space-y-3">
                        <div class="bg-white p-3 rounded">
                            <p class="font-semibold text-sm mb-2">Productivity and Growth:</p>
                            <ul class="text-xs space-y-1 list-disc ml-4">
                                <li><strong>GDP Impact:</strong> AI contribution to US GDP projected at 15-20% by 2030 ($5-7 trillion)</li>
                                <li><strong>Productivity Growth:</strong> Annual productivity growth rate of 2.5-3.5% (vs. 1.5% in 2010s)</li>
                                <li><strong>Industry Transformation:</strong> Entire industries restructured around AI capabilities</li>
                                <li><strong>Global Competitiveness:</strong> US position dependent on workforce AI readiness</li>
                            </ul>
                        </div>
                        <div class="bg-white p-3 rounded">
                            <p class="font-semibold text-sm mb-2">Labor Market Dynamics:</p>
                            <div class="space-y-2">
                                <div class="flex items-center justify-between text-xs">
                                    <span>Unemployment Rate (projected):</span>
                                    <span class="font-semibold">3.5-4.5%</span>
                                </div>
                                <div class="flex items-center justify-between text-xs">
                                    <span>Job Turnover Rate (annual):</span>
                                    <span class="font-semibold">25-30%</span>
                                </div>
                                <div class="flex items-center justify-between text-xs">
                                    <span>Workers in Continuous Training:</span>
                                    <span class="font-semibold">60-70%</span>
                                </div>
                                <div class="flex items-center justify-between text-xs">
                                    <span>Gig/Contract Workers:</span>
                                    <span class="font-semibold">45-50%</span>
                                </div>
                                <div class="flex items-center justify-between text-xs">
                                    <span>AI-Intensive Occupations:</span>
                                    <span class="font-semibold">65-75%</span>
                                </div>
                            </div>
                        </div>
                        <div class="bg-white p-3 rounded">
                            <p class="font-semibold text-sm mb-2">Income and Inequality:</p>
                            <ul class="text-xs space-y-1 list-disc ml-4">
                                <li><strong>Wage Polarization:</strong> Continued divergence between high-skill AI-augmented workers and those in routine roles</li>
                                <li><strong>Skill Premium:</strong> 40-50% wage premium for advanced AI competencies</li>
                                <li><strong>Geographic Disparities:</strong> Persistent gaps between tech hubs and other regions</li>
                                <li><strong>Policy Responses:</strong> Universal basic income pilots, expanded earned income tax credits, portable benefits systems</li>
                            </ul>
                        </div>
                    </div>
                </div>
                
                <div class="bg-yellow-50 p-4 rounded-lg">
                    <h5 class="font-semibold mb-2">Emerging Frontiers and Uncertainties</h5>
                    <p class="text-sm mb-3">Areas of continued evolution and open questions beyond 2030.</p>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <div class="bg-white p-3 rounded">
                            <p class="font-semibold text-sm mb-2">Technological Frontiers:</p>
                            <ul class="text-xs space-y-1 list-disc ml-4">
                                <li>Artificial General Intelligence (AGI) development trajectory</li>
                                <li>Brain-computer interfaces for direct human-AI connection</li>
                                <li>Quantum computing integration with AI</li>
                                <li>Embodied AI and advanced robotics</li>
                                <li>Collective intelligence systems</li>
                            </ul>
                        </div>
                        <div class="bg-white p-3 rounded">
                            <p class="font-semibold text-sm mb-2">Societal Questions:</p>
                            <ul class="text-xs space-y-1 list-disc ml-4">
                                <li>Meaning and purpose of work in AI age</li>
                                <li>Human identity and agency with AI augmentation</li>
                                <li>Governance of increasingly powerful AI systems</li>
                                <li>Distribution of AI-generated wealth</li>
                                <li>Preservation of human skills and knowledge</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            
            <h4 class="text-xl font-semibold mb-3 mt-6">Success Factors for 2030:</h4>
            <div class="bg-gradient-to-r from-green-50 to-blue-50 p-4 rounded-lg mb-6">
                <p class="text-sm mb-3">Characteristics of successful AI integration by 2030:</p>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                        <p class="font-semibold text-sm mb-2">Individual Level:</p>
                        <ul class="text-xs space-y-1 list-disc ml-4">
                            <li>Advanced AI literacy</li>
                            <li>Continuous learning habit</li>
                            <li>Complementary human skills</li>
                            <li>Adaptability and resilience</li>
                            <li>Ethical awareness</li>
                        </ul>
                    </div>
                    <div>
                        <p class="font-semibold text-sm mb-2">Organizational Level:</p>
                        <ul class="text-xs space-y-1 list-disc ml-4">
                            <li>Learning culture</li>
                            <li>Ethical AI governance</li>
                            <li>Investment in people</li>
                            <li>Inclusive practices</li>
                            <li>Strategic agility</li>
                        </ul>
                    </div>
                    <div>
                        <p class="font-semibold text-sm mb-2">Societal Level:</p>
                        <ul class="text-xs space-y-1 list-disc ml-4">
                            <li>Robust safety nets</li>
                            <li>Accessible education</li>
                            <li>Effective regulation</li>
                            <li>Equitable distribution</li>
                            <li>Democratic governance</li>
                        </ul>
                    </div>
                </div>
            </div>
            
            <div class="bg-blue-50 p-4 rounded-lg">
                <p class="font-semibold mb-2">Concluding Perspective:</p>
                <p class="text-sm">The 2030 workplace will be fundamentally different from today, but the transition is not predetermined. The choices made by individuals, organizations, and policymakers in the 2024-2028 period will largely determine whether AI integration leads to broadly shared prosperity and meaningful work, or to increased inequality and workforce displacement. Success requires proactive investment in people, ethical leadership, and inclusive governance—ensuring that technological progress serves human flourishing.</p>
            </div>
        `
    }
};

// Paper details
const paperDetails = {
    paper1: {
        title: 'AI Exposure and Occupational Transformation in the United States',
        authors: 'Felten, E., Raj, M., & Seamans, R.',
        year: '2024',
        journal: 'Journal of Labor Economics',
        abstract: 'This paper analyzes which US occupations are most exposed to AI technologies using detailed task-level data. Findings indicate 33% of employment faces high exposure...',
        doi: '10.1086/example'
    },
    paper2: {
        title: 'Measuring the Skills Gap in the AI Era',
        authors: 'Smith, J., Johnson, K., & Williams, L.',
        year: '2025',
        journal: 'Workforce Development Quarterly',
        abstract: 'Comprehensive assessment of competency gaps between current workforce capabilities and AI-era requirements across industries...',
        doi: '10.1177/example'
    }
    // Additional papers would be defined here
};

function showDetail(detailId) {
    const modal = document.getElementById('detailModal');
    const modalContent = document.getElementById('modalContent');
    
    if (detailContent[detailId]) {
        modalContent.innerHTML = detailContent[detailId].content;
        modal.style.display = 'block';
    }
}

function showPaper(paperId) {
    const modal = document.getElementById('detailModal');
    const modalContent = document.getElementById('modalContent');
    
    if (paperDetails[paperId]) {
        const paper = paperDetails[paperId];
        modalContent.innerHTML = `
            <h3 class="text-2xl font-bold mb-4">${paper.title}</h3>
            <p class="text-gray-700 mb-2"><strong>Authors:</strong> ${paper.authors}</p>
            <p class="text-gray-700 mb-2"><strong>Year:</strong> ${paper.year}</p>
            <p class="text-gray-700 mb-4"><strong>Journal:</strong> ${paper.journal}</p>
            <p class="text-gray-700 mb-4"><strong>Abstract:</strong> ${paper.abstract}</p>
            <p class="text-gray-700 mb-4"><strong>DOI:</strong> <a href="https://doi.org/${paper.doi}" target="_blank" class="text-blue-600 hover:underline">${paper.doi}</a></p>
            <div class="mt-4">
                <a href="https://doi.org/${paper.doi}" target="_blank" class="bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700">
                    Access Paper <i class="fas fa-external-link-alt ml-2"></i>
                </a>
            </div>
        `;
        modal.style.display = 'block';
    }
}