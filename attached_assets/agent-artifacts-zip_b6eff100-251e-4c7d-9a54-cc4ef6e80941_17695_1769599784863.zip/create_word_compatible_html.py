#!/usr/bin/env python3
"""
Create Word-compatible HTML from Markdown report
This HTML can be opened in Microsoft Word and saved as .docx
"""

import re

def markdown_to_html(md_file, html_file):
    """Convert markdown to Word-compatible HTML"""
    
    with open(md_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Start HTML with Word-compatible styling
    html = '''<!DOCTYPE html>
<html xmlns:o="urn:schemas-microsoft-com:office:office"
      xmlns:w="urn:schemas-microsoft-com:office:word"
      xmlns="http://www.w3.org/TR/REC-html40">
<head>
<meta charset="utf-8">
<title>AI Workforce Readiness Report</title>
<style>
/* APA 7th Edition Styling */
body {
    font-family: 'Times New Roman', Times, serif;
    font-size: 12pt;
    line-height: 2.0;
    margin: 1in;
    color: #000000;
}

h1 {
    font-size: 14pt;
    font-weight: bold;
    text-align: center;
    margin-top: 24pt;
    margin-bottom: 12pt;
    page-break-after: avoid;
}

h2 {
    font-size: 12pt;
    font-weight: bold;
    margin-top: 18pt;
    margin-bottom: 6pt;
    page-break-after: avoid;
}

h3 {
    font-size: 12pt;
    font-weight: bold;
    font-style: italic;
    margin-top: 12pt;
    margin-bottom: 6pt;
    page-break-after: avoid;
}

p {
    margin-top: 0;
    margin-bottom: 12pt;
    text-align: left;
    text-indent: 0.5in;
}

.no-indent {
    text-indent: 0;
}

.center {
    text-align: center;
    text-indent: 0;
}

.references p {
    text-indent: -0.5in;
    margin-left: 0.5in;
}

ul, ol {
    margin-left: 0.5in;
}

li {
    margin-bottom: 6pt;
}

.toc {
    page-break-after: always;
}

.toc ul {
    list-style-type: none;
}

.executive-summary {
    font-style: italic;
    margin-bottom: 24pt;
}

blockquote {
    margin-left: 0.5in;
    margin-right: 0.5in;
    font-style: italic;
}

.page-break {
    page-break-before: always;
}
</style>
</head>
<body>
'''
    
    # Process content
    lines = content.split('\n')
    in_references = False
    in_toc = False
    skip_next_hr = False
    
    for i, line in enumerate(lines):
        # Skip horizontal rules
        if line.strip() == '---':
            if not skip_next_hr:
                html += '<div class="page-break"></div>\n'
            skip_next_hr = False
            continue
        
        # Handle headers
        if line.startswith('# '):
            title = line[2:].strip()
            html += f'<h1>{title}</h1>\n'
            skip_next_hr = True
            continue
        
        if line.startswith('## '):
            title = line[3:].strip()
            if 'References' in title:
                in_references = True
                html += '<div class="references">\n'
            if 'Table of Contents' in title:
                in_toc = True
                html += '<div class="toc">\n'
            html += f'<h2>{title}</h2>\n'
            continue
        
        if line.startswith('### '):
            title = line[4:].strip()
            html += f'<h3>{title}</h3>\n'
            continue
        
        # Handle bold text
        line = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', line)
        
        # Handle italic text
        line = re.sub(r'\*(.+?)\*', r'<em>\1</em>', line)
        
        # Handle links - convert to APA format with hyperlinks
        line = re.sub(r'\[([^\]]+)\]\(([^)]+)\)', r'<a href="\2">\1</a>', line)
        
        # Handle inline citations - keep as is for APA
        # Citations like (Author, Year) or (Author et al., Year)
        
        # Empty line
        if not line.strip():
            continue
        
        # Regular paragraph
        if line.strip() and not line.startswith('#'):
            # Check if it's a list item
            if line.strip().startswith('- ') or line.strip().startswith('* '):
                item = line.strip()[2:]
                html += f'<li>{item}</li>\n'
            elif re.match(r'^\d+\.', line.strip()):
                item = re.sub(r'^\d+\.\s*', '', line.strip())
                html += f'<li>{item}</li>\n'
            else:
                # Regular paragraph
                if in_references:
                    html += f'<p class="no-indent">{line.strip()}</p>\n'
                else:
                    html += f'<p>{line.strip()}</p>\n'
    
    # Close any open divs
    if in_references:
        html += '</div>\n'
    if in_toc:
        html += '</div>\n'
    
    # Close HTML
    html += '''
</body>
</html>
'''
    
    # Write HTML file
    with open(html_file, 'w', encoding='utf-8') as f:
        f.write(html)
    
    print(f"✓ Created Word-compatible HTML: {html_file}")
    print(f"  File size: {len(html):,} bytes")
    print()
    print("To convert to .docx:")
    print("  1. Open this HTML file in Microsoft Word")
    print("  2. Go to File > Save As")
    print("  3. Choose 'Word Document (.docx)' as the format")
    print("  4. Save the file")

def main():
    md_file = '/home/sandbox/AI_Workforce_Readiness_Report.md'
    html_file = '/home/sandbox/AI_Workforce_Readiness_Report.html'
    
    print("Creating Word-compatible HTML from Markdown...")
    print()
    
    markdown_to_html(md_file, html_file)
    
    return 0

if __name__ == '__main__':
    import sys
    sys.exit(main())
