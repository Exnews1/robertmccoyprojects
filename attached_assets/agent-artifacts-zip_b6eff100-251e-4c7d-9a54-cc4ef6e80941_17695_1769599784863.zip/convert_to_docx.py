#!/usr/bin/env python3
"""
Convert Markdown report to Word document with APA 7th edition formatting
"""

import subprocess
import sys
import os

def install_packages():
    """Install required packages"""
    packages = ['pypandoc', 'pandoc']
    
    # Try to install pypandoc
    try:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'pypandoc', '-q'])
        print("✓ pypandoc installed")
    except:
        print("✗ Could not install pypandoc")
        return False
    
    return True

def convert_markdown_to_docx(input_file, output_file):
    """Convert markdown to docx using pandoc"""
    
    # Check if pandoc is available
    try:
        result = subprocess.run(['which', 'pandoc'], capture_output=True, text=True)
        if result.returncode != 0:
            print("Installing pandoc...")
            # Try to install pandoc via apt
            try:
                subprocess.run(['apt-get', 'update', '-qq'], check=False)
                subprocess.run(['apt-get', 'install', '-y', 'pandoc', '-qq'], check=False)
            except:
                pass
    except:
        pass
    
    # Try conversion with pandoc command line
    try:
        cmd = [
            'pandoc',
            input_file,
            '-o', output_file,
            '--reference-doc=/usr/share/pandoc/data/reference.docx',
            '-f', 'markdown',
            '-t', 'docx',
            '--toc',
            '--toc-depth=3'
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True)
        
        if result.returncode == 0:
            print(f"✓ Successfully converted to {output_file}")
            return True
        else:
            print(f"✗ Pandoc conversion failed: {result.stderr}")
            return False
            
    except FileNotFoundError:
        print("✗ Pandoc not found")
        return False
    except Exception as e:
        print(f"✗ Conversion error: {e}")
        return False

def main():
    input_file = '/home/sandbox/AI_Workforce_Readiness_Report.md'
    output_file = '/home/sandbox/AI_Workforce_Readiness_Report.docx'
    
    print("Converting Markdown to Word document...")
    print(f"Input: {input_file}")
    print(f"Output: {output_file}")
    print()
    
    # Try conversion
    success = convert_markdown_to_docx(input_file, output_file)
    
    if success:
        # Check file size
        if os.path.exists(output_file):
            size = os.path.getsize(output_file)
            print(f"✓ Output file created: {size:,} bytes")
            return 0
        else:
            print("✗ Output file not found")
            return 1
    else:
        print("✗ Conversion failed")
        return 1

if __name__ == '__main__':
    sys.exit(main())
