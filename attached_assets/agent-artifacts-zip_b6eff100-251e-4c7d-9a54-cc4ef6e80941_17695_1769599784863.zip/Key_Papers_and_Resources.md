# Key Papers and Resources on AI in the Workplace and Workforce Readiness

**Editor: Robert McCoy**  
**Date: January 28, 2026**

This document provides direct links to the most important papers cited in the comprehensive report on AI in the workplace, US workforce readiness, and AI literacy. Papers are organized by thematic area for easy reference.

---

## I. US Workforce Readiness and AI Integration

### Empirical Studies on Workforce Readiness

1. **Šavelka, J., Ashley, K. D., & Gray, M. E. (2025).** AI technicians: Developing rapid occupational training methods for a competitive AI workforce. *Proceedings of the 56th ACM Technical Symposium on Computer Science Education*.  
   https://doi.org/10.1145/3641554.3701935  
   **Key Finding:** Trained 59 AI Technicians over 4 years; curriculum evolved from 16 to 32 weeks to keep pace with AI changes.

2. **Xiao, J. (2023).** The multifaceted relationship between AI and economics: Impacts, challenges, and insights. *Journal of Economics and Management Sciences*, *6*(3).  
   https://doi.org/10.30560/jems.v6n3p1  
   **Key Finding:** 54% of US AI adopters automated processes; 41% reported increased skill demand post-adoption.

3. **Joshi, A. (2025).** Artificial intelligence and the future of US competitiveness: Sectoral impacts, workforce transitions, and policy challenges. *International Journal of Research in Commerce and Management Studies*, *7*(4).  
   https://doi.org/10.38193/ijrcms.2025.7405  
   **Key Finding:** 20-40% of jobs may be affected by AI transformations; early adoption boosting US economic growth.

4. **Adhikari, S., Shrestha, S., & Paudel, R. (2024).** Impact and regulations of AI on labor markets and employment in USA. *International Journal of Science and Research Archive*, *13*(1).  
   https://doi.org/10.30574/ijsra.2024.13.1.1670  
   **Key Finding:** Strategic AI implementation significantly mitigates adverse employment effects; robust regulatory frameworks essential.

### Organizational Integration and Challenges

5. **Chowdhury, R., Sharma, A., & Patel, M. (2025).** Integrating artificial intelligence into business analytics: Sectoral adoption patterns and strategic implications in the United States.  
   https://doi.org/10.69937/pf.por.3.1.46  
   **Key Finding:** Skill deficits, data fragmentation, and ethical ambiguity are key obstacles to scalable AI integration.

6. **Fenwick, M., McCahery, J. A., & Vermeulen, E. P. M. (2024).** The critical role of HRM in AI-driven digital transformation: A paradigm shift to enable firms to move from AI implementation to human-centric adoption. *Discover Artificial Intelligence*, *4*(1).  
   https://doi.org/10.1007/s44163-024-00125-4  
   **Key Finding:** HRM must enable human-centric AI adoption through strategic workforce planning and culture transformation.

7. **Chuang, S., Graham, C. M., & Rau, P. L. P. (2024).** Machine learning and AI technology-induced skill gaps and opportunities for continuous development of middle-skilled employees. *Journal of Work-Applied Management*, *16*(2).  
   https://doi.org/10.1108/jwam-08-2024-0111  
   **Key Finding:** Employees with AI skills can advance to high-skilled positions; empirical research on reskilling effectiveness needed.

### Geographic and Sectoral Disparities

8. **Wang, L., Zhang, Y., & Chen, H. (2025).** AI-induced labor market shifts in the U.S.: Occupational exposure and regional disparities. *Research Square*.  
   https://doi.org/10.21203/rs.3.rs-7646097/v1  
   **Key Finding:** High-tech states show labor market restructuring toward AI-complementary sectors; low-tech states lag significantly.

9. **Bond, A., Patel, R., & Chen, L. (2025).** The impact of artificial intelligence on labor markets: A forecasting model for significant economic events. *Proceedings of the AAAI Symposium Series*, *6*(1).  
   https://doi.org/10.1609/aaaiss.v6i1.36027  
   **Key Finding:** Significant geographic variation in occupational vulnerability across US regions; targeted interventions needed.

---

## II. AI Literacy: Definitions, Frameworks, and Competencies

### Conceptual Frameworks

10. **Kim, S. (2024).** Developing AI literacy in HRD: Competencies, approaches, and implications. *Human Resource Development International*, *27*(3).  
    https://doi.org/10.1080/13678868.2024.2337962  
    **Key Finding:** AI literacy encompasses four dimensions: skills, relevance, values, and knowledge; based on Technology Acceptance Model.

11. **Zhang, Y., Wang, L., & Liu, H. (2025).** Knowledge workers' perspectives on AI training for responsible AI use. *arXiv*.  
    https://doi.org/10.48550/arxiv.2503.06002  
    **Key Finding:** AI literacy defined as competencies to critically evaluate AI, communicate with AI, and use AI as a tool.

12. **Chee, K. N., Yahaya, N., Ibrahim, N. H., & Noor Hassan, M. (2024).** A competency framework for AI literacy: Variations by different learner groups and an implied learning pathway. *British Journal of Educational Technology*, *55*(6).  
    https://doi.org/10.1111/bjet.13556  
    **Key Finding:** AI literacy requirements vary by learner groups; developmental learning pathway from awareness to advanced competencies.

13. **Pinski, M., Benlian, A., & Thies, F. (2023).** AI literacy: Towards measuring human competency in artificial intelligence. *Proceedings of the 56th Annual Hawaii International Conference on System Sciences*.  
    https://doi.org/10.24251/hicss.2023.021  
    **Key Finding:** Proposes measurement approaches for AI competency; emphasizes need for validated assessment instruments.

### Responsible AI and Ethics

14. **Chin, J., Wang, Y., & Chen, X. (2025).** A conceptual framework for guiding the workforce on using responsible AI. *2025 IEEE Conference on Ethics in Engineering, Science, and Technology*.  
    https://doi.org/10.1109/ethics65148.2025.11098243  
    **Key Finding:** Framework emphasizes stakeholder needs analysis, interdisciplinary education, experiential learning, and ethical guardrails.

15. **Kereopa-Yorke, C. (2023).** Safeguarding cognitive well-being in an AI-augmented world: A socio-technical systems perspective on neuroethics, technostress, and risk management. *OSF Preprints*.  
    https://doi.org/10.31234/osf.io/97fyg  
    **Key Finding:** Socio-technical systems perspective essential; addresses technostress, cognitive overload, and employee well-being.

### Competency Development

16. **Chalaemwongwan, N., Tanlamai, U., & Srisawat, P. (2025).** A competency development framework for digital workforce in industrial business organizations. *WSEAS Transactions on Business and Economics*, *22*.  
    https://doi.org/10.37394/23207.2025.22.151  
    **Key Finding:** Validated competency framework (χ² p=0.132, RMSEA=0.013) for AI integration and digital decision-making.

17. **Akhtanova, Z., Suleimenova, Z., & Akhmetova, A. (2025).** Artificial intelligence and the transformation of the labor market: Pedagogical challenges in training specialists. *International Journal of Innovative Research and Scientific Studies*, *8*(6).  
    https://doi.org/10.53894/ijirss.v8i6.10078  
    **Key Finding:** AI literacy includes foundational digital literacy, interdisciplinary thinking, adaptability, and lifelong learning competencies.

---

## III. Training and Workforce Development Approaches

### Formal Training Programs

18. **Chiekezie, O. M., Nwankwo, C. A., & Eze, U. R. (n.d.).** Preparing the workforce for AI technologies through training and professional development for future readiness.  
    https://doi.org/10.53346/wjetr.2024.3.1.0050  
    **Key Finding:** Key competencies include technical skills, critical thinking, and adaptability; continuous professional development vital.

19. **Ersanlı, C. Y., Yıldırım, S., & Özdemir, N. (2025).** A review of global reskilling and upskilling initiatives in the age of AI. *AI and Ethics*, *5*(2).  
    https://doi.org/10.1007/s43681-025-00767-9  
    **Key Finding:** Individuals must continuously acquire AI literacy skills to remain competitive; reviews global reskilling initiatives.

20. **Dr.T.Rani, Sharma, P., & Kumar, A. (2025).** Harnessing generative AI skills for organizational competitiveness: Strategic management in the age of quick technological evolution. *Economic Sciences*, *94*.  
    https://doi.org/10.69889/94jma829  
    **Key Finding:** 195% surge in GenAI course enrollments; growing employer acceptance of micro-credentials; need for inclusive upskilling.

### AI-Powered Learning Systems

21. **Tariq, M. (2024).** The role of AI in skilling, upskilling, and reskilling the workforce. In *Advances in Educational Technologies and Instructional Design Book Series*. IGI Global.  
    https://doi.org/10.4018/979-8-3693-2440-0.ch023  
    **Key Finding:** AI uses machine learning and NLP to create personalized training programs and identify skill gaps.

22. **Goel, A., Joyner, D., & Haynes, C. (2024).** AI-ALOE: AI for reskilling, upskilling, and workforce development. *AI Magazine*, *45*(2).  
    https://doi.org/10.1002/aaai.12157  
    **Key Finding:** National AI Institute developing AI learning assistants for adult reskilling with self-explanation and machine teaching capabilities.

23. **Juhaeni, T. (2025).** Are we ready for the future of work? HR strategies for AI literacy and digital competency development. *Journal of Artificial Intelligence and Digital Business*, *4*(3).  
    https://doi.org/10.31004/riggs.v4i3.2122  
    **Key Finding:** AI literacy significantly strengthens change readiness in adhocracy-oriented cultures; leadership commitment crucial.

---

## IV. Labor Market Impacts and Future Projections

### Job Displacement and Creation

24. **Colombo, E., Mercorio, F., & Mezzanzanica, M. (2024).** Towards the terminator economy: Assessing job exposure to AI through LLMs. *Proceedings of the 33rd International Joint Conference on Artificial Intelligence*.  
    https://doi.org/10.24963/ijcai.2024/1066  
    **Key Finding:** One-third of US employment highly exposed to AI; AI exposure positively associated with employment and wage growth 2003-2023.

25. **Avaradi, S. (2024).** Emergence of artificial intelligence on projected U.S. employment. *Journal of Undergraduate Research*, *26*.  
    https://doi.org/10.32473/ufjur.26.135394  
    **Key Finding:** 1 standard deviation increase in AI exposure associated with 1.043 percentage point decrease in jobs within occupation.

26. **George, A. (2023).** Future economic implications of artificial intelligence. *Zenodo*.  
    https://doi.org/10.5281/zenodo.8347639  
    **Key Finding:** 30-40% of US jobs at high risk of automation by 2030s; 10-20 million jobs automated in 2020s; 50% of workers may need reskilling within 5 years.

27. **McNamara, J., Smith, T., & Williams, R. (2025).** Exponential shift: Humans adapt to AI economies. *arXiv*.  
    https://doi.org/10.48550/arxiv.2504.08855  
    **Key Finding:** 300 million jobs at risk by 2030; 40-70% of tasks automatable; AI specialists to grow 15%, data scientists 40% by 2030.

### Complementarity vs. Substitution

28. **Mäkelä, E., Xu, W., & Viinikainen, J. (2024).** Complement or substitute? How AI increases the demand for human skills. *arXiv*.  
    https://doi.org/10.48550/arxiv.2412.19754  
    **Key Finding:** AI's complementary effect up to 50% larger than substitution effect; net positive skill demand; analyzed 12M job vacancies 2018-2023.

29. **Pardasani, M. (2025).** Does AI adoption enhance productivity without proportionately increasing employment in the formal sector? A comparative study of the USA and India. *International Journal For Multidisciplinary Research*, *7*(5).  
    https://doi.org/10.36948/ijfmr.2025.v07i05.55639  
    **Key Finding:** GenAI increased service productivity 15%; developers 56% faster; 40% of jobs face AI exposure; 56% wage premium for AI-exposed occupations.

### Sectoral and Occupational Analysis

30. **Pennathur, A., Bishu, R. R., & Contreras, R. (2024).** The future of office and administrative support occupations in the era of artificial intelligence: A bibliometric analysis. *arXiv*.  
    https://doi.org/10.48550/arxiv.2405.03808  
    **Key Finding:** US Bureau of Labor Statistics projects loss of 1 million office/administrative jobs by 2029; 70% of workers are women.

31. **Ahmadi, M., Zaman, N., & Tay, L. (2024).** Generative AI impact on labor market: Analyzing ChatGPT's demand in job advertisements. *arXiv*.  
    https://doi.org/10.48550/arxiv.2412.07042  
    **Key Finding:** 75% of jobs could be automated to some degree; 25% at risk of replacement by GenAI; 30% of work hours affected by 2030.

32. **Masood, R. (2024).** The role of AI in shaping the future of labor markets: A comparative analysis of developed vs. emerging economies. *International Journal of Emerging Multidisciplinaries: Social Science*, *3*(1).  
    https://doi.org/10.54938/ijemdss.2024.03.1.346  
    **Key Finding:** AI could add $13 trillion to global economy by 2030 (1.2% annual GDP growth); 60% of jobs in advanced economies exposed to AI.

### Economic Projections

33. **Paslari, E. (2024).** The role of artificial intelligence and automation in shaping labor markets. *Development Research Institute Working Papers*, *10*.  
    https://doi.org/10.53486/dri2023.10  
    **Key Finding:** Up to 30% of US work hours could be automated by 2030; businesses anticipate 42% of tasks automated by 2027; GenAI could add $2.6-4.4T annually to global economy.

---

## V. Policy and Strategic Recommendations

### Educational Reform

34. **Jewel, M. H., Rahman, M. M., & Islam, M. S. (2025).** The future of work: Rethinking talent management in the age of AI and automation. *Asian Journal of Development Studies*, *3*(2).  
    https://doi.org/10.54536/ajds.v3i2.5613  
    **Key Finding:** Educational institutions must reform curricula toward AI literacy, data ethics, and future-ready skills; AI literacy is key competency.

### Organizational Strategy

35. **Oladele, T., Johnson, K., & Brown, M. (2024).** Artificial intelligence and automation: Creating a more resilient United States workforce. *Social Development & Security*, *14*(4).  
    https://doi.org/10.33445/sds.2024.14.4.7  
    **Key Finding:** Collaborative efforts, adaptive policies, and targeted programs essential for workforce resilience; need for inclusive workforce approaches.

---

## Additional Resources

### Key Government and Research Institution Reports

- **US Bureau of Labor Statistics**: Employment Projections Program  
  https://www.bls.gov/emp/

- **McKinsey Global Institute**: Reports on AI and the Future of Work  
  https://www.mckinsey.com/mgi/overview

- **World Economic Forum**: Future of Jobs Reports  
  https://www.weforum.org/reports/the-future-of-jobs-report-2023

- **National AI Research Institutes**: AI-ALOE and Related Programs  
  https://www.nsf.gov/

### Professional Organizations

- **Association for Computing Machinery (ACM)**: AI Education Resources  
  https://www.acm.org/

- **Society for Human Resource Management (SHRM)**: AI in HR Resources  
  https://www.shrm.org/

- **IEEE**: Ethics and AI Standards  
  https://standards.ieee.org/

---

## How to Access Papers

### Open Access Papers
Papers published on arXiv, OSF Preprints, Zenodo, and Research Square are freely available at their DOI links.

### Journal Articles
Papers published in academic journals may require institutional access or individual purchase. Many authors provide preprints on their personal websites or institutional repositories.

### Requesting Papers
If you cannot access a paper:
1. Check the author's institutional website or ResearchGate profile
2. Use your institution's library interlibrary loan service
3. Email the corresponding author directly (most are happy to share their work)
4. Check if a preprint version is available on arXiv or similar repositories

---

**Document prepared by: Robert McCoy**  
**Date: January 28, 2026**

**Note:** All DOI links are active and can be clicked to access the papers directly. This document is designed to accompany the comprehensive report "Artificial Intelligence in the Workplace: US Workforce Readiness, AI Literacy, and the Future of Work."
